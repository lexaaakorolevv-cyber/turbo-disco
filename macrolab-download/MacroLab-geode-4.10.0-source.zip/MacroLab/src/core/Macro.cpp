#include "Macro.hpp"

#include "../../vendor/json.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace gdm {
namespace {
using Json = nlohmann::json;

[[noreturn]] void bad(std::string const& reason) {
    throw std::runtime_error("Invalid macro: " + reason);
}

void exactKeys(Json const& value, std::initializer_list<char const*> keys,
               char const* label) {
    if (!value.is_object() || value.size() != keys.size()) bad(std::string(label) + ": unexpected fields");
    for (auto const* key : keys) if (!value.contains(key)) bad(std::string(label) + ": missing " + key);
}

std::uint64_t unsignedNumber(Json const& value, std::uint64_t max, char const* label) {
    // nlohmann may classify small positive JSON numbers as signed integers too.
    if (!value.is_number_integer()) bad(std::string(label) + ": expected integer");
    if (value.is_number_unsigned()) {
        auto result = value.get<std::uint64_t>();
        if (result > max) bad(std::string(label) + ": out of range");
        return result;
    }
    auto result = value.get<std::int64_t>();
    if (result < 0 || static_cast<std::uint64_t>(result) > max) bad(std::string(label) + ": out of range");
    return static_cast<std::uint64_t>(result);
}

std::string stringValue(Json const& value, char const* label) {
    if (!value.is_string()) bad(std::string(label) + ": expected string");
    return value.get<std::string>();
}

bool boolValue(Json const& value, char const* label) {
    if (!value.is_boolean()) bad(std::string(label) + ": expected boolean");
    return value.get<bool>();
}

double finiteValue(Json const& value, char const* label) {
    if (!value.is_number()) bad(std::string(label) + ": expected number");
    auto result = value.get<double>();
    if (!std::isfinite(result) || std::abs(result) > 1e12) bad(std::string(label) + ": non-finite or out of range");
    return result;
}

void textField(std::string const& text, std::size_t max, char const* label, bool empty = false) {
    if ((!empty && text.empty()) || text.size() > max) bad(std::string(label) + ": invalid length");
    if (std::any_of(text.begin(), text.end(), [](unsigned char ch) { return ch < 0x20 || ch == 0x7f; })) {
        bad(std::string(label) + ": control character");
    }
}

void checkState(PlayerState const& state) {
    for (double value : {state.x, state.y, state.vx, state.vy}) {
        if (!std::isfinite(value) || std::abs(value) > 1e12) bad("player state out of range");
    }
}

Json stateJson(PlayerState const& state) {
    return {{"x", state.x}, {"y", state.y}, {"vx", state.vx}, {"vy", state.vy}, {"flags", state.flags}};
}

PlayerState readState(Json const& value) {
    exactKeys(value, {"x", "y", "vx", "vy", "flags"}, "player state");
    return {finiteValue(value.at("x"), "x"), finiteValue(value.at("y"), "y"),
            finiteValue(value.at("vx"), "vx"), finiteValue(value.at("vy"), "vy"),
            static_cast<std::uint32_t>(unsignedNumber(value.at("flags"), UINT32_MAX, "flags"))};
}
} // namespace

std::string levelContentHash(std::string_view levelData) {
    std::uint64_t hash = 14695981039346656037ull;
    for (unsigned char value : levelData) {
        hash ^= value;
        hash *= 1099511628211ull;
    }
    std::ostringstream result;
    result << std::hex << std::setfill('0') << std::setw(16) << hash;
    return result.str();
}

void validateMetadata(Metadata const& meta) {
    textField(meta.gameVersion, 32, "gameVersion");
    textField(meta.geodeVersion, 32, "geodeVersion");
    textField(meta.platform, 32, "platform");
    textField(meta.rngPolicy, 64, "rngPolicy");
    textField(meta.environment, 2048, "environment", true);
    if (meta.levelId < 0) bad("negative levelId");
    if (meta.levelHash.size() != 16 || !std::all_of(meta.levelHash.begin(), meta.levelHash.end(), [](char ch) {
        return (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f');
    })) bad("levelHash must contain 16 lowercase hexadecimal characters");
    if (meta.stepHz != 240) bad("only 240 simulation steps per second are supported");
}

void validate(Macro const& macro) {
    validateMetadata(macro.meta);
    if (macro.endStep > MaxStep) bad("endStep limit exceeded");
    if (macro.events.size() > MaxEvents) bad("event limit exceeded");
    if (macro.samples.size() > MaxSamples) bad("sample limit exceeded");
    std::array<std::array<bool, 3>, 2> held{};
    std::uint64_t last = 0;
    bool first = true;
    for (auto const& event : macro.events) {
        if (event.player < 1 || event.player > 2 || event.button < 1 || event.button > 3) bad("invalid player or button");
        if (event.step > macro.endStep || (!first && event.step < last)) bad("nonmonotonic or out-of-range event");
        if (event.step == macro.endStep && event.down) bad("endStep may contain only final releases");
        auto& state = held[event.player - 1][event.button - 1];
        if (state == event.down) bad("duplicate press or release without press");
        state = event.down;
        first = false;
        last = event.step;
    }
    for (auto const& player : held) for (bool button : player) if (button) bad("unreleased button at macro end");
    first = true;
    last = 0;
    for (auto const& sample : macro.samples) {
        if (sample.step > macro.endStep || (!first && sample.step <= last)) bad("nonmonotonic or out-of-range sample");
        checkState(sample.players[0]);
        checkState(sample.players[1]);
        first = false;
        last = sample.step;
    }
}

void validateCompatibility(Metadata const& recorded, Metadata const& current) {
    validateMetadata(recorded);
    validateMetadata(current);
    auto require = [](bool condition, char const* field) {
        if (!condition) throw std::runtime_error(std::string("Macro is incompatible: ") + field + " differs");
    };
    require(recorded.gameVersion == current.gameVersion, "Geometry Dash version");
    require(recorded.geodeVersion == current.geodeVersion, "Geode version");
    require(recorded.platform == current.platform, "platform");
    require(recorded.levelId == current.levelId, "level ID");
    require(recorded.levelHash == current.levelHash, "level content hash");
    require(recorded.platformer == current.platformer, "platformer mode");
    require(recorded.stepHz == current.stepHz, "simulation rate");
    require(recorded.rngPolicy == current.rngPolicy, "random-state reset policy");
    require(recorded.environment == current.environment, "environment/settings");
}

std::string encode(Macro const& macro) {
    validate(macro);
    auto const& meta = macro.meta;
    Json result = {{"format", "gdm-macro"}, {"schemaVersion", 1},
        {"metadata", {{"gameVersion", meta.gameVersion}, {"geodeVersion", meta.geodeVersion},
        {"platform", meta.platform}, {"levelId", meta.levelId}, {"levelHash", meta.levelHash},
        {"platformer", meta.platformer}, {"stepHz", meta.stepHz}, {"rngPolicy", meta.rngPolicy},
        {"environment", meta.environment}}}, {"endStep", macro.endStep}, {"completed", macro.completed},
        {"events", Json::array()}, {"samples", Json::array()}};
    for (auto const& event : macro.events) result["events"].push_back({{"step", event.step},
        {"player", event.player}, {"button", event.button}, {"down", event.down}});
    for (auto const& sample : macro.samples) result["samples"].push_back({{"step", sample.step},
        {"dual", sample.dual}, {"players", Json::array({stateJson(sample.players[0]), stateJson(sample.players[1])})}});
    auto output = result.dump(2);
    if (output.size() > MaxJsonBytes) bad("encoded JSON exceeds file size limit");
    return output;
}

Macro decode(std::string_view json) {
    if (json.empty() || json.size() > MaxJsonBytes) bad("empty or oversized JSON");
    try {
        // A low nesting bound prevents hostile inputs exhausting parser recursion.
        std::vector<std::unordered_set<std::string>> keys;
        auto result = Json::parse(json.begin(), json.end(), [&keys](int depth, Json::parse_event_t event, Json& value) {
            if (depth > 12) bad("JSON nesting limit exceeded");
            if (event == Json::parse_event_t::object_start) keys.emplace_back();
            if (event == Json::parse_event_t::key && !keys.back().insert(value.get<std::string>()).second) {
                bad("duplicate JSON object key");
            }
            if (event == Json::parse_event_t::object_end) keys.pop_back();
            return true;
        });
        exactKeys(result, {"format", "schemaVersion", "metadata", "endStep", "completed", "events", "samples"}, "root");
        if (stringValue(result.at("format"), "format") != "gdm-macro" ||
            unsignedNumber(result.at("schemaVersion"), 1, "schemaVersion") != 1) bad("unsupported format/version");
        auto const& meta = result.at("metadata");
        exactKeys(meta, {"gameVersion", "geodeVersion", "platform", "levelId", "levelHash", "platformer", "stepHz", "rngPolicy", "environment"}, "metadata");
        Macro macro;
        macro.meta.gameVersion = stringValue(meta.at("gameVersion"), "gameVersion");
        macro.meta.geodeVersion = stringValue(meta.at("geodeVersion"), "geodeVersion");
        macro.meta.platform = stringValue(meta.at("platform"), "platform");
        macro.meta.levelId = static_cast<std::int64_t>(unsignedNumber(meta.at("levelId"), INT64_MAX, "levelId"));
        macro.meta.levelHash = stringValue(meta.at("levelHash"), "levelHash");
        macro.meta.platformer = boolValue(meta.at("platformer"), "platformer");
        macro.meta.stepHz = static_cast<std::uint32_t>(unsignedNumber(meta.at("stepHz"), UINT32_MAX, "stepHz"));
        macro.meta.rngPolicy = stringValue(meta.at("rngPolicy"), "rngPolicy");
        macro.meta.environment = stringValue(meta.at("environment"), "environment");
        macro.endStep = unsignedNumber(result.at("endStep"), MaxStep, "endStep");
        macro.completed = boolValue(result.at("completed"), "completed");
        auto const& events = result.at("events");
        auto const& samples = result.at("samples");
        if (!events.is_array() || events.size() > MaxEvents) bad("events must be a bounded array");
        if (!samples.is_array() || samples.size() > MaxSamples) bad("samples must be a bounded array");
        macro.events.reserve(events.size());
        macro.samples.reserve(samples.size());
        for (auto const& event : events) {
            exactKeys(event, {"step", "player", "button", "down"}, "event");
            macro.events.push_back({unsignedNumber(event.at("step"), MaxStep, "step"),
                static_cast<std::uint8_t>(unsignedNumber(event.at("player"), 2, "player")),
                static_cast<std::uint8_t>(unsignedNumber(event.at("button"), 3, "button")),
                boolValue(event.at("down"), "down")});
        }
        for (auto const& sample : samples) {
            exactKeys(sample, {"step", "dual", "players"}, "sample");
            auto const& players = sample.at("players");
            if (!players.is_array() || players.size() != 2) bad("sample must contain two player states");
            macro.samples.push_back({unsignedNumber(sample.at("step"), MaxStep, "step"),
                {readState(players.at(0)), readState(players.at(1))}, boolValue(sample.at("dual"), "dual")});
        }
        validate(macro);
        return macro;
    } catch (Json::exception const& error) {
        bad(std::string("JSON parse/type error: ") + error.what());
    }
}
} // namespace gdm
