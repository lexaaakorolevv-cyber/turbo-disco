#include "Playback.hpp"

#include <cmath>
#include <sstream>
#include <stdexcept>

namespace gdm {

void Playback::start(Macro const& macro, Metadata const& current) {
    validate(macro);
    validateCompatibility(macro.meta, current);
    m_macro = macro;
    m_eventIndex = 0;
    m_sampleIndex = 0;
    m_lastInputStep.reset();
    m_lastCheckStep.reset();
    m_active = true;
}

std::vector<Event> Playback::eventsAt(std::uint64_t step) {
    if (!m_active) return {};
    if ((m_lastInputStep && step < *m_lastInputStep) ||
        (m_eventIndex < m_macro.events.size() && m_macro.events[m_eventIndex].step < step)) {
        stop();
        throw std::runtime_error("Playback desynchronized: input step skipped or moved backwards");
    }
    m_lastInputStep = step;
    std::vector<Event> events;
    while (m_eventIndex < m_macro.events.size() && m_macro.events[m_eventIndex].step == step) {
        events.push_back(m_macro.events[m_eventIndex++]);
    }
    return events;
}

std::optional<std::string> Playback::check(Sample const& actual, double tolerance) {
    if (!m_active) return std::nullopt;
    if (!std::isfinite(tolerance) || tolerance < 0 || tolerance > 1e6) {
        throw std::runtime_error("Invalid playback comparison tolerance");
    }
    auto mismatch = [this, &actual](std::string const& reason) -> std::optional<std::string> {
        stop();
        return "Playback desynchronized at step " + std::to_string(actual.step) + ": " + reason;
    };
    if (m_lastCheckStep && actual.step < *m_lastCheckStep) return mismatch("simulation moved backwards");
    m_lastCheckStep = actual.step;
    if (m_sampleIndex >= m_macro.samples.size()) return std::nullopt;
    auto const& expected = m_macro.samples[m_sampleIndex];
    if (actual.step < expected.step) return std::nullopt;
    if (actual.step > expected.step) return mismatch("verification checkpoint was skipped");
    if (actual.dual != expected.dual) return mismatch("dual mode differs");
    for (std::size_t player = 0; player < (expected.dual ? 2u : 1u); ++player) {
        auto const& a = actual.players[player];
        auto const& e = expected.players[player];
        if (a.flags != e.flags) return mismatch("player " + std::to_string(player + 1) + " movement/gravity state differs");
        for (auto const& [name, pair] : std::array<std::pair<char const*, std::pair<double, double>>, 4>{{
            {"x", {a.x, e.x}}, {"y", {a.y, e.y}}, {"vx", {a.vx, e.vx}}, {"vy", {a.vy, e.vy}}
        }}) {
            if (!std::isfinite(pair.first) || std::abs(pair.first - pair.second) > tolerance) {
                std::ostringstream message;
                message << "player " << player + 1 << ' ' << name << " differs (expected "
                        << pair.second << ", got " << pair.first << ')';
                return mismatch(message.str());
            }
        }
    }
    ++m_sampleIndex;
    return std::nullopt;
}

bool Playback::ended(std::uint64_t step) const noexcept {
    return m_active && step >= m_macro.endStep && m_eventIndex == m_macro.events.size() &&
        m_sampleIndex == m_macro.samples.size();
}

void Playback::stop() noexcept {
    m_active = false;
}

} // namespace gdm
