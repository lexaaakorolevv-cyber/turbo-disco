#pragma once

#include "Macro.hpp"

namespace gdm {

class Recorder {
public:
    void start(Metadata const& meta);
    void input(std::uint64_t step, std::uint8_t player, std::uint8_t button, bool down);
    void sample(Sample const& state);
    Macro const& finish(std::uint64_t endStep, bool completed);
    Macro const& macro() const noexcept { return m_macro; }
    bool active() const noexcept { return m_active; }

private:
    Macro m_macro;
    std::array<std::array<bool, 3>, 2> m_held{};
    std::uint64_t m_lastStep = 0;
    bool m_active = false;
};

} // namespace gdm
