#include "Recorder.hpp"

#include <cmath>
#include <stdexcept>

namespace gdm {

void Recorder::start(Metadata const& meta) {
    validateMetadata(meta);
    m_macro = {};
    m_macro.meta = meta;
    m_held = {};
    m_lastStep = 0;
    m_active = true;
}

void Recorder::input(std::uint64_t step, std::uint8_t player, std::uint8_t button, bool down) {
    if (!m_active) throw std::runtime_error("Recording is not active");
    if (player < 1 || player > 2 || button < 1 || button > 3) throw std::runtime_error("Invalid input player/button");
    if (step > MaxStep || step < m_lastStep) throw std::runtime_error("Recording input step is out of order/range");
    m_lastStep = step;
    auto& held = m_held[player - 1][button - 1];
    if (held == down) return; // Key-repeat and unheld releases are not actions.
    // Reserve room for every pending button release, so finishing remains possible.
    if (m_macro.events.size() >= MaxEvents - 6) throw std::runtime_error("Recording event limit reached");
    m_macro.events.push_back({step, player, button, down});
    held = down;
}

void Recorder::sample(Sample const& state) {
    if (!m_active) throw std::runtime_error("Recording is not active");
    if (state.step > MaxStep || state.step < m_lastStep ||
        (!m_macro.samples.empty() && state.step <= m_macro.samples.back().step)) {
        throw std::runtime_error("Recording sample step is out of order/range");
    }
    for (auto const& player : state.players) for (double value : {player.x, player.y, player.vx, player.vy}) {
        if (!std::isfinite(value) || std::abs(value) > 1e12) throw std::runtime_error("Recording player state is not finite/in range");
    }
    if (m_macro.samples.size() >= MaxSamples) throw std::runtime_error("Recording sample limit reached");
    m_macro.samples.push_back(state);
    m_lastStep = state.step;
}

Macro const& Recorder::finish(std::uint64_t endStep, bool completed) {
    if (!m_active) throw std::runtime_error("Recording is not active");
    if (endStep < m_lastStep || endStep > MaxStep) throw std::runtime_error("Recording end step is out of range");
    for (auto event = m_macro.events.rbegin(); event != m_macro.events.rend() && event->step == endStep; ++event) {
        if (event->down) throw std::runtime_error("Recording end step must follow its final press");
    }
    for (std::uint8_t player = 1; player <= 2; ++player) {
        for (std::uint8_t button = 1; button <= 3; ++button) {
            if (m_held[player - 1][button - 1]) m_macro.events.push_back({endStep, player, button, false});
        }
    }
    m_macro.endStep = endStep;
    m_macro.completed = completed;
    validate(m_macro);
    m_held = {};
    m_active = false;
    return m_macro;
}

} // namespace gdm
