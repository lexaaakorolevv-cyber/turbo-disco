#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace gdm {

inline constexpr std::size_t MaxJsonBytes = 32 * 1024 * 1024;
inline constexpr std::size_t MaxEvents = 500'000;
inline constexpr std::size_t MaxSamples = 100'000;
inline constexpr std::uint64_t MaxStep = 240ull * 60 * 60 * 24;

struct Event {
    std::uint64_t step = 0;
    std::uint8_t player = 1; // 1 or 2
    std::uint8_t button = 1; // 1: jump, 2: left, 3: right
    bool down = false;
};

struct PlayerState {
    double x = 0;
    double y = 0;
    double vx = 0;
    double vy = 0;
    std::uint32_t flags = 0;
};

struct Sample {
    std::uint64_t step = 0;
    std::array<PlayerState, 2> players{};
    bool dual = false;
};

struct Metadata {
    std::string gameVersion = "2.2074";
    std::string geodeVersion = "4.10.0";
    std::string platform = "win";
    std::int64_t levelId = 0;
    std::string levelHash;
    bool platformer = false;
    std::uint32_t stepHz = 240;
    std::string rngPolicy = "game-reset";
    std::string environment;
};

struct Macro {
    Metadata meta;
    std::vector<Event> events;
    std::vector<Sample> samples;
    std::uint64_t endStep = 0;
    bool completed = false;
};

// FNV-1a64 over the exact levelString bytes supplied by the adapter.
// Integrity marker, not a cryptographic security mechanism.
std::string levelContentHash(std::string_view levelData);
void validateMetadata(Metadata const& meta);
void validate(Macro const& macro);
void validateCompatibility(Metadata const& recorded, Metadata const& current);
std::string encode(Macro const& macro);
Macro decode(std::string_view json);

} // namespace gdm
