#include "Storage.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <fstream>
#include <stdexcept>

namespace gdm {
namespace {
namespace fs = std::filesystem;

void validateName(std::string const& name) {
    if (name.empty() || name.size() > 64 || !std::all_of(name.begin(), name.end(), [](char ch) {
        return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
            (ch >= '0' && ch <= '9') || ch == '-' || ch == '_';
    })) throw std::runtime_error("Macro name must contain 1-64 ASCII letters, digits, '-' or '_'");
    std::string upper = name;
    for (auto& ch : upper) if (ch >= 'a' && ch <= 'z') ch -= 'a' - 'A';
    if (upper == "CON" || upper == "PRN" || upper == "AUX" || upper == "NUL" ||
        (upper.size() == 4 && (upper.starts_with("COM") || upper.starts_with("LPT")) &&
        upper.back() >= '1' && upper.back() <= '9')) {
        throw std::runtime_error("Reserved device name is not allowed");
    }
}

fs::path safePath(fs::path const& path) {
    if (path.empty()) throw std::runtime_error("Empty file path");
    for (auto const& component : path) if (component == "..") throw std::runtime_error("Parent path traversal is not allowed");
    auto absolute = fs::absolute(path).lexically_normal();
    fs::path walked = absolute.root_path();
    auto inspect = [](fs::path const& entry) {
        std::error_code error;
        auto status = fs::symlink_status(entry, error);
        if (error && error != std::errc::no_such_file_or_directory) throw std::runtime_error("Cannot inspect file path: " + error.message());
        if (fs::is_symlink(status)) throw std::runtime_error("Symbolic links are not allowed in macro paths");
    };
    inspect(walked);
    for (auto const& component : absolute.relative_path()) {
        walked /= component;
        inspect(walked);
    }
    return absolute;
}

std::string readBounded(fs::path const& filePath) {
    auto path = safePath(filePath);
    if (!fs::is_regular_file(path)) throw std::runtime_error("Macro path is not a regular file");
    auto bytes = fs::file_size(path);
    if (bytes == 0 || bytes > MaxJsonBytes) throw std::runtime_error("Macro file is empty or exceeds 32 MiB");
    std::ifstream input(path, std::ios::binary);
    if (!input) throw std::runtime_error("Cannot open macro file for reading");
    std::string data(static_cast<std::size_t>(bytes), '\0');
    input.read(data.data(), static_cast<std::streamsize>(data.size()));
    if (input.gcount() != static_cast<std::streamsize>(data.size()) || input.peek() != std::char_traits<char>::eof()) {
        throw std::runtime_error("Macro file changed during read or could not be read completely");
    }
    return data;
}

void writeComplete(fs::path const& filePath, std::string const& data) {
    auto path = safePath(filePath);
    if (!fs::is_directory(path.parent_path())) throw std::runtime_error("Export directory does not exist");
    if (fs::exists(path) && !fs::is_regular_file(path)) throw std::runtime_error("Output path is not a regular file");
    static std::atomic<std::uint64_t> counter = 0;
    auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
    auto suffix = ".tmp-" + std::to_string(stamp) + "-" + std::to_string(counter.fetch_add(1));
    auto temporary = path;
    temporary += suffix;
    temporary = safePath(temporary);
    auto backup = temporary;
    backup += ".backup";
    backup = safePath(backup);
    if (fs::exists(temporary) || fs::exists(backup)) throw std::runtime_error("Temporary macro path already exists");
    try {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        if (!output) throw std::runtime_error("Cannot open temporary macro file");
        output.write(data.data(), static_cast<std::streamsize>(data.size()));
        output.flush();
        if (!output) throw std::runtime_error("Cannot write complete macro file");
        output.close();
        if (!output) throw std::runtime_error("Cannot close macro file");
        safePath(path);
        std::error_code error;
        fs::rename(temporary, path, error);
        if (error) {
            // Windows may refuse rename over an existing file. Preserve the old
            // file until the replacement has been installed, then remove backup.
            if (!fs::is_regular_file(path)) throw std::runtime_error("Cannot install macro file: " + error.message());
            fs::rename(path, backup);
            fs::rename(temporary, path, error);
            if (error) {
                std::error_code restoreError;
                fs::rename(backup, path, restoreError);
                throw std::runtime_error("Cannot install replacement macro file: " + error.message() +
                    (restoreError ? "; old file retained at " + backup.string() : ""));
            }
            fs::remove(backup);
        }
    } catch (...) {
        std::error_code cleanup;
        fs::remove(temporary, cleanup);
        throw;
    }
}
} // namespace

Storage::Storage(std::filesystem::path root) : m_root(safePath(root)) {
    fs::create_directories(m_root);
    safePath(m_root);
    if (!fs::is_directory(m_root)) throw std::runtime_error("Macro storage root is not a directory");
}

fs::path Storage::fileFor(std::string const& name) const {
    validateName(name);
    safePath(m_root);
    return safePath(m_root / (name + ".json"));
}

void Storage::save(std::string const& name, Macro const& macro) const {
    auto path = fileFor(name);
    writeComplete(path, encode(macro));
}

Macro Storage::load(std::string const& name) const {
    return decode(readBounded(fileFor(name)));
}

void Storage::erase(std::string const& name) const {
    auto path = fileFor(name);
    if (!fs::is_regular_file(path)) throw std::runtime_error("Macro does not exist or is not a regular file");
    if (!fs::remove(path)) throw std::runtime_error("Macro could not be deleted");
}

std::vector<std::string> Storage::list() const {
    safePath(m_root);
    std::vector<std::string> result;
    for (auto const& entry : fs::directory_iterator(m_root)) {
        // Ignore links and temporary/unrelated files; load rejects link targets.
        if (entry.is_symlink() || !entry.is_regular_file() || entry.path().extension() != ".json") continue;
        auto name = entry.path().stem().string();
        try {
            validateName(name);
            result.push_back(std::move(name));
        } catch (std::runtime_error const&) {}
    }
    std::sort(result.begin(), result.end());
    return result;
}

void Storage::importFrom(std::filesystem::path const& path, std::string const& name) const {
    auto parsed = decode(readBounded(path));
    save(name, parsed);
}

void Storage::exportTo(std::string const& name, std::filesystem::path const& path) const {
    auto parsed = load(name);
    writeComplete(path, encode(parsed));
}

} // namespace gdm
