#pragma once

#include "Macro.hpp"

#include <filesystem>

namespace gdm {

class Storage {
public:
    explicit Storage(std::filesystem::path root);
    void save(std::string const& name, Macro const& macro) const;
    Macro load(std::string const& name) const;
    void erase(std::string const& name) const;
    std::vector<std::string> list() const;
    void importFrom(std::filesystem::path const& path, std::string const& name) const;
    void exportTo(std::string const& name, std::filesystem::path const& path) const;

private:
    std::filesystem::path m_root;
    std::filesystem::path fileFor(std::string const& name) const;
};

} // namespace gdm
