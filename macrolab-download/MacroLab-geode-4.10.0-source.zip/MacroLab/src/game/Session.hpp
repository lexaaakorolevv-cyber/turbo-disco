#pragma once
#include <Geode/Geode.hpp>
#include "../core/Macro.hpp"
#include "../core/Recorder.hpp"
#include "../core/Playback.hpp"
#include "../core/Storage.hpp"
#include "../search/Search.hpp"
#include <deque>
#include <optional>
#include <memory>
namespace gdm {
enum class Mode { Idle, Recording, Playback, Searching };
enum class Command { Record, Play, Search, Stop };
class Session final {
public:
    static Session& get();
    void attach(PlayLayer* layer);
    void detach(PlayLayer* layer);
    void request(Command command);
    void beginFrame();
    void beforeCommands(GJBaseGameLayer* layer, float dt);
    void afterUpdate();
    bool captureButton(GJBaseGameLayer*, bool down, int button, bool player2);
    void didReset();
    void died();
    void completed();
    bool controlled(GJBaseGameLayer*) const;
    bool automated() const;
    bool quarantined() const;
    bool blockedLevel(GJGameLevel*) const;
    bool active() const;
    bool injecting() const;
    cocos2d::CCDictionary* originalPendingCoins() const;
    std::string status() const;
    void save(std::string const& name);
    void load(std::string const& name);
    void erase(std::string const& name);
    void importFile(std::string const& name);
    void exportFile(std::string const& name);
    std::vector<std::string> macros();
    std::filesystem::path directory() const;
    void openLevel(std::string const& id);
    void exitLevel();
    void stopNow();
    double& accumulator();
    void fail(std::string const& message);
private:
    Session();
    Storage& storage();
    Metadata metadata() const;
    Sample snapshot() const;
    Observation observation() const;
    void start(Command);
    void reset();
    void apply(Event const&);
    void releaseAll();
    void finish(bool complete);
    PlayLayer* m_layer = nullptr;
    Mode m_mode = Mode::Idle;
    bool m_quarantine=false, m_injecting=false, m_resetting=false, m_death=false;
    bool m_completed=false, m_resetRequested=false;
    uint64_t m_step=0;
    double m_accumulator=0;
    uint64_t m_attempt=0;
    std::optional<Command> m_pending;
    std::deque<Event> m_buttons;
    std::array<std::array<bool,3>,2> m_held{};
    std::string m_message="Готово";
    Recorder m_recorder;
    Playback m_playback;
    Search m_search;
    std::optional<Macro> m_macro;
    std::unique_ptr<Storage> m_storage;
    GJGameLevel* m_original=nullptr;
    GJGameLevel* m_private=nullptr;
    bool m_verifying=false;
    std::optional<uint64_t> m_nativePrevious;
    bool m_advanced=false;
    cocos2d::CCDictionary* m_originalPendingCoins=nullptr;
    cocos2d::CCDictionary* m_privatePendingCoins=nullptr;
};
}
