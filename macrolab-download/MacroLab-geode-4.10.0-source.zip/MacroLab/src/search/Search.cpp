#include "Search.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace gdm {
namespace {
using PlayerInput = std::array<bool, 3>;

uint64_t tieKey(uint64_t value) {
    // Deterministic tie-breaking lets the seed diversify equally scored beams.
    value += 0x9e3779b97f4a7c15ull;
    value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ull;
    value = (value ^ (value >> 27)) * 0x94d049bb133111ebull;
    return value ^ (value >> 31);
}

std::string prefixKey(std::vector<Input> const& segments) {
    std::string key;
    key.reserve(segments.size());
    for (auto const& input : segments) {
        unsigned bits = 0;
        for (unsigned p = 0; p != 2; ++p)
            for (unsigned b = 0; b != 3; ++b)
                bits |= unsigned(input[p][b]) << (p * 3 + b);
        key.push_back(char(bits));
    }
    return key;
}

bool finitePlayer(double x, double y, double vx, double vy) {
    return std::isfinite(x) && std::isfinite(y) && std::isfinite(vx) && std::isfinite(vy);
}

bool nearHazard(Observation const& o, bool second) {
    double x = second ? o.x2 : o.x1, y = second ? o.y2 : o.y1;
    double const dx = o.nearestHazardX - x;
    return dx >= -20 && dx <= 100 && std::abs(o.nearestHazardY - y) <= 100;
}

std::vector<PlayerInput> playerActions(bool platformer, Observation const& o, bool second) {
    bool grounded = second ? o.grounded2 : o.grounded1;
    uint32_t mode = second ? o.mode2 : o.mode1;
    double vy = second ? o.vy2 : o.vy1;
    // A preference only: all release/hold alternatives remain in the finite set.
    bool preferJump = (grounded && nearHazard(o, second)) ||
        ((mode == 1 || mode == 3 || mode == 4 || mode == 7) && vy < -1);
    PlayerInput idle{false, false, false}, jump{true, false, false};
    if (!platformer) return preferJump ? std::vector<PlayerInput>{jump, idle}
                                      : std::vector<PlayerInput>{idle, jump};
    PlayerInput right{false, false, true}, rightJump{true, false, true};
    PlayerInput left{false, true, false}, leftJump{true, true, false};
    if (preferJump) return {rightJump, right, leftJump, left, jump, idle};
    return {right, rightJump, left, leftJump, idle, jump};
}
} // namespace

void Search::start(bool platformer, bool dual, SearchConfig config) {
    m_config = config;
    m_platformer = platformer;
    m_dual = dual;
    m_outcome = SearchOutcome::Searching;
    m_attemptActive = false;
    m_attempts = 0;
    m_executed = m_serial = m_totalSteps = 0;
    m_bestProgress = 0;
    m_pending.clear();
    m_survivors.clear();
    m_current = {};
    m_last = {};
    m_tailInput = {};
    m_trace.clear();
    m_solution.clear();
    m_boundaries.clear();
    m_visited.clear();
    // Bounds also limit memory and work done at a single attempt boundary.
    if (config.maxAttempts == 0 || config.maxAttempts > 4096 ||
        config.maxSteps == 0 || config.maxSteps > 240ull * 600 ||
        config.segmentSteps == 0 || config.segmentSteps > 240 ||
        config.beamWidth == 0 || config.beamWidth > 32 ||
        config.maxTotalSteps == 0 || config.maxTotalSteps > 240ull * 3600 ||
        (config.maxSteps + config.segmentSteps - 1) / config.segmentSteps > 12000) {
        terminate(SearchOutcome::InvalidConfiguration);
        return;
    }
    // First try a full baseline rollout; an empty/easy level takes one attempt.
    m_pending.push_back(Node{});
    m_visited.insert(std::string{});
}

std::vector<Input> Search::actions(Observation const& observation) const {
    auto first = playerActions(m_platformer, observation, false);
    auto second = playerActions(m_platformer, observation, true);
    if (!(m_dual || observation.dual)) second = {PlayerInput{}};
    std::vector<Input> result;
    result.reserve(first.size() * second.size());
    // Pair independently: neither player's button is copied into the other.
    for (auto const& a : first)
        for (auto const& b : second) result.push_back(Input{a, b});
    return result;
}

void Search::expand(std::vector<Node> const& parents) {
    // Round-robin branching gives each beam parent its preferred action before
    // one parent can consume the remaining attempt budget with all alternatives.
    std::vector<std::vector<Input>> choices;
    choices.reserve(parents.size());
    size_t count = 0;
    for (auto const& parent : parents) {
        choices.push_back(actions(parent.end));
        count = std::max(count, choices.back().size());
    }
    for (size_t branch = 0; branch < count; ++branch) {
        for (size_t i = 0; i < parents.size(); ++i) {
            if (branch >= choices[i].size()) continue;
            Node candidate = parents[i];
            candidate.segments.push_back(choices[i][branch]);
            if (!m_visited.insert(prefixKey(candidate.segments)).second) continue;
            candidate.serial = tieKey(m_serial++ ^ m_config.seed);
            m_pending.push_back(std::move(candidate));
        }
    }
}

void Search::beginAttempt() {
    if (!running() || m_attemptActive) return;
    if (m_attempts >= m_config.maxAttempts) {
        terminate(SearchOutcome::AttemptLimit);
        return;
    }
    if (m_pending.empty()) advance();
    if (!running() || m_pending.empty()) return;
    m_current = std::move(m_pending.front());
    m_pending.pop_front();
    ++m_attempts;
    m_attemptActive = true;
    m_executed = 0;
    m_last = {};
    m_tailInput = {};
    m_trace.clear();
    m_boundaries.clear();
}

bool Search::supported(Observation const& o) {
    if (o.mode1 > 7 || (o.dual && o.mode2 > 7)) {
        terminate(SearchOutcome::Unsupported);
        return false;
    }
    if (!std::isfinite(o.progress) || !finitePlayer(o.x1, o.y1, o.vx1, o.vy1) ||
        (o.dual && !finitePlayer(o.x2, o.y2, o.vx2, o.vy2))) {
        terminate(SearchOutcome::Unsupported);
        return false;
    }
    // A dual portal changes branching for later segments, even if start(false).
    if (o.dual) m_dual = true;
    return true;
}

Input Search::desired(uint64_t step, Observation const& observation) {
    if (!running() || !m_attemptActive || !supported(observation)) return {};
    if (m_totalSteps >= m_config.maxTotalSteps) {
        terminate(SearchOutcome::TotalStepLimit);
        return {};
    }
    // Repeating/skipping a step would produce a trace the game did not execute.
    if (step != m_trace.size() || step >= m_config.maxSteps) {
        terminate(SearchOutcome::ReplayMismatch);
        return {};
    }
    if (step == 0) m_boundaries.push_back({0, observation});
    Input input{};
    size_t const segment = size_t(step / m_config.segmentSteps);
    if (segment < m_current.segments.size()) input = m_current.segments[segment];
    else {
        if (step % m_config.segmentSteps == 0) {
            m_tailInput = {};
            if (m_platformer) {
                // Full baseline tail: normal movement, never a completion bypass.
                m_tailInput[0][2] = true;
                if (m_dual || observation.dual) m_tailInput[1][2] = true;
            }
        }
        input = m_tailInput;
    }
    m_trace.push_back(input);
    ++m_totalSteps;
    return input;
}

double Search::score(Observation const& o, uint64_t steps) const {
    // Percent is the main objective, with x and survival breaking close ties.
    // Platformer maps that require backtracking can defeat this heuristic.
    double progress = std::clamp(double(o.progress), 0.0, 100.0);
    double x = o.dual ? std::min(o.x1, o.x2) : o.x1;
    return progress * 1000000 + std::clamp(x, -100000.0, 100000.0) * 10 +
        double(steps) * 0.001;
}

void Search::observe(uint64_t step, Observation const& observation) {
    if (!running() || !m_attemptActive || !supported(observation)) return;
    if (step != m_trace.size() || step < m_executed) {
        terminate(SearchOutcome::ReplayMismatch);
        return;
    }
    m_executed = step;
    m_last = observation;
    m_bestProgress = std::max(m_bestProgress, std::clamp(observation.progress, 0.f, 100.f));
    if (!observation.dead && step % m_config.segmentSteps == 0)
        m_boundaries.push_back({step, observation});
    if (observation.dead) closeAttempt(false);
    else if (step >= m_config.maxSteps) terminate(SearchOutcome::StepLimit);
    if (running() && m_totalSteps >= m_config.maxTotalSteps)
        terminate(SearchOutcome::TotalStepLimit);
}

void Search::finishAttempt(bool completed) {
    if (!running() || !m_attemptActive) return;
    if (completed) {
        m_solution = m_trace;
        m_bestProgress = 100;
        terminate(SearchOutcome::Found);
    } else closeAttempt(false);
}

void Search::closeAttempt(bool survived) {
    if (!m_attemptActive) return;
    m_attemptActive = false;
    (void)survived;
    // Failure-directed refinement: retain two safe prefixes before collision,
    // rather than spend an attempt for every segment of a long empty corridor.
    // These are observations and input history only; the game never restores them.
    uint64_t const whole = m_executed ? (m_executed - 1) / m_config.segmentSteps : 0;
    for (uint64_t rewind : {1ull, 2ull}) {
        uint64_t const depth = whole > rewind ? whole - rewind : 0;
        if (depth >= m_boundaries.size()) continue;
        Node safe;
        safe.end = m_boundaries[size_t(depth)].observation;
        safe.score = score(safe.end, depth * m_config.segmentSteps);
        safe.serial = tieKey(m_serial++ ^ m_config.seed);
        safe.segments.reserve(size_t(depth));
        for (uint64_t i = 0; i < depth; ++i)
            safe.segments.push_back(m_trace[size_t(i * m_config.segmentSteps)]);
        auto duplicate = std::find_if(m_survivors.begin(), m_survivors.end(), [&](Node const& n) {
            return n.segments == safe.segments;
        });
        if (duplicate == m_survivors.end()) m_survivors.push_back(std::move(safe));
        // Keep only the best beam incrementally: bounded retained histories.
        std::stable_sort(m_survivors.begin(), m_survivors.end(), [](Node const& a, Node const& b) {
            if (a.score != b.score) return a.score > b.score;
            return a.serial < b.serial;
        });
        if (m_survivors.size() > m_config.beamWidth) m_survivors.resize(m_config.beamWidth);
    }
    if (m_attempts >= m_config.maxAttempts) {
        terminate(SearchOutcome::AttemptLimit);
        return;
    }
    if (m_pending.empty()) advance();
}

void Search::advance() {
    if (!running()) return;
    if (m_survivors.empty()) {
        terminate(SearchOutcome::Exhausted);
        return;
    }
    if (uint64_t(m_survivors.front().segments.size()) * m_config.segmentSteps >= m_config.maxSteps) {
        terminate(SearchOutcome::StepLimit);
        return;
    }
    auto parents = std::move(m_survivors);
    m_survivors.clear();
    expand(parents);
    if (m_pending.empty()) terminate(SearchOutcome::Exhausted);
}

void Search::terminate(SearchOutcome outcome) {
    m_outcome = outcome;
    m_attemptActive = false;
    m_pending.clear();
    m_survivors.clear();
    m_current = {};
    m_trace.clear();
    m_boundaries.clear();
    m_visited.clear();
}

void Search::stop() {
    if (running()) terminate(SearchOutcome::Cancelled);
}
bool Search::running() const { return m_outcome == SearchOutcome::Searching; }
bool Search::needsRestart() const { return running() && !m_attemptActive; }
uint32_t Search::attempt() const { return m_attempts; }
float Search::bestProgress() const { return m_bestProgress; }
SearchOutcome Search::outcome() const { return m_outcome; }
std::vector<Input> const& Search::solution() const { return m_solution; }

std::string Search::status() const {
    std::ostringstream result;
    switch (m_outcome) {
        case SearchOutcome::Idle: return "Поиск не запущен";
        case SearchOutcome::Found: return "Игра подтвердила завершение; требуется проверка воспроизведения";
        case SearchOutcome::Cancelled: return "Поиск остановлен пользователем";
        case SearchOutcome::Exhausted: return "Решение не найдено: исчерпаны сохранённые ветви поиска";
        case SearchOutcome::AttemptLimit: return "Решение не найдено: исчерпан лимит попыток";
        case SearchOutcome::StepLimit: return "Решение не найдено: исчерпан лимит длины попытки";
        case SearchOutcome::Unsupported: return "Поиск остановлен: неизвестный режим движения или некорректное состояние";
        case SearchOutcome::InvalidConfiguration: return "Поиск не запущен: недопустимые ограничения";
        case SearchOutcome::ReplayMismatch: return "Поиск остановлен: нарушен порядок шагов симуляции";
        case SearchOutcome::TotalStepLimit: return "Решение не найдено: исчерпан общий бюджет шагов поиска";
        case SearchOutcome::Searching: break;
    }
    result << "Попытка " << m_attempts << "/" << m_config.maxAttempts
           << "; лучший прогресс " << std::fixed << std::setprecision(1) << m_bestProgress
           << "%; глубина " << m_current.segments.size() * m_config.segmentSteps << " шагов";
    return result.str();
}

} // namespace gdm
