#include "ControlPopup.hpp"
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/binding/FLAlertLayer.hpp>
#include <Geode/binding/PauseLayer.hpp>
#include <Geode/cocos/text_input_node/CCIMEDispatcher.h>
#include <algorithm>
#include <stdexcept>

using namespace geode::prelude;

namespace gdm::ui {
namespace {

bool containsAlert(CCNode* node) {
    if (!node || !node->isVisible()) return false;
    if (typeinfo_cast<FLAlertLayer*>(node)) return true;
    if (auto children = node->getChildren()) {
        for (auto child : CCArrayExt<CCNode*>(children)) {
            if (containsAlert(child)) return true;
        }
    }
    return false;
}

CCLabelBMFont* label(char const* text, float x, float y, float scale, float width = 0.f) {
    auto path = fontPath();
    auto node = width > 0.f
        ? CCLabelBMFont::create(text, path.c_str(), width / scale, kCCTextAlignmentCenter)
        : CCLabelBMFont::create(text, path.c_str());
    if (!node) throw std::runtime_error("UI font could not be loaded");
    node->setScale(scale);
    node->setPosition({x, y});
    return node;
}

template <class Action>
void guarded(Action&& action) {
    try { action(); }
    catch (std::exception const& error) { showError(error.what()); }
}

}

std::string fontPath() {
    // A full filename avoids collisions with fonts belonging to other mods.
    return (Mod::get()->getResourcesDir() / "ui-font.fnt").string();
}

void showError(std::string const& message) {
    // Native alert labels do not contain Russian glyphs; retain its normal OK
    // button and touch/key handling, and draw the body with our bundled font.
    auto alert = FLAlertLayer::create(nullptr, "Macro Lab", " ", "OK", nullptr,
                                      410.f, false, 190.f, .8f);
    if (!alert) return;
    auto size = CCDirector::get()->getWinSize();
    auto path = fontPath();
    auto text = CCLabelBMFont::create(message.c_str(), path.c_str(), 760.f,
                                     kCCTextAlignmentCenter);
    if (text) {
        float scale = .46f;
        auto height = text->getContentSize().height;
        if (height * scale > 110.f) scale = 110.f / height;
        text->setScale(scale);
        text->setPosition(size / 2.f + CCPoint{0.f, 5.f});
        alert->m_mainLayer->addChild(text, 10);
    }
    alert->show();
}

bool hasModalInput() {
    return CCIMEDispatcher::sharedDispatcher()->hasDelegate()
        || containsAlert(CCDirector::get()->getRunningScene());
}

void showControls(PauseLayer* pause) {
    guarded([pause] {
        if (hasModalInput()) return;
        auto popup = ControlPopup::create(pause);
        if (!popup) throw std::runtime_error("Unable to create Macro Lab menu");
        popup->show();
    });
}

ControlPopup* ControlPopup::create(PauseLayer* pause) {
    auto popup = new ControlPopup();
    try {
        if (popup->initAnchored(450.f, 312.f, pause)) {
            popup->autorelease();
            return popup;
        }
    } catch (...) {
        delete popup;
        throw;
    }
    delete popup;
    return nullptr;
}

bool ControlPopup::setup(PauseLayer* pause) {
    m_pause = pause;
    m_noElasticity = true;
    auto path = fontPath();
    setTitle("Лаборатория макросов", path.c_str(), .63f, 17.f);

    m_status = label("", 225.f, 258.f, .29f, 420.f);
    m_status->setColor({190, 230, 255});
    m_mainLayer->addChild(m_status);

    m_levelId = TextInput::create(169.f, "ID (пусто = текущий)", path);
    if (!m_levelId) return false;
    m_levelId->setCommonFilter(CommonFilter::Uint);
    m_levelId->setMaxCharCount(10);
    m_levelId->setPosition({113.f, 210.f});
    m_mainLayer->addChild(m_levelId);

    m_name = TextInput::create(190.f, "Имя макроса", path);
    if (!m_name) return false;
    m_name->setFilter("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-");
    m_name->setMaxCharCount(48);
    m_name->setString("macro");
    m_name->setPosition({130.f, 175.f});
    m_mainLayer->addChild(m_name);

    auto button = [this, &path](char const* caption, float x, float y,
                                int width, SEL_MenuHandler callback) {
        auto sprite = ButtonSprite::create(caption, width, true, path.c_str(),
                                           "GJ_button_04.png", 29.f, .44f);
        if (!sprite) throw std::runtime_error("Unable to create a menu button");
        auto item = CCMenuItemSpriteExtra::create(sprite, this, callback);
        item->setPosition({x, y});
        m_buttonMenu->addChild(item);
    };

    button("Выбрать уровень", 329.f, 210.f, 181, menu_selector(ControlPopup::onLevel));
    button("Выйти из уровня", 329.f, 175.f, 181, menu_selector(ControlPopup::onExit));
    button("Записать", 79.f, 143.f, 127, menu_selector(ControlPopup::onRecord));
    button("Воспроизвести", 225.f, 143.f, 139, menu_selector(ControlPopup::onPlay));
    button("Остановить", 371.f, 143.f, 127, menu_selector(ControlPopup::onStop));
    button("Найти прохождение", 97.f, 105.f, 164, menu_selector(ControlPopup::onSearch));
    button("Сохранить", 251.f, 105.f, 116, menu_selector(ControlPopup::onSave));
    button("Загрузить", 376.f, 105.f, 115, menu_selector(ControlPopup::onLoad));
    button("Удалить", 79.f, 67.f, 127, menu_selector(ControlPopup::onErase));
    button("Импорт", 225.f, 67.f, 127, menu_selector(ControlPopup::onImport));
    button("Экспорт", 371.f, 67.f, 127, menu_selector(ControlPopup::onExport));

    m_names = label("", 225.f, 37.f, .30f, 420.f);
    m_names->setColor({200, 210, 220});
    m_mainLayer->addChild(m_names);
    m_notice = label("F6 меню/выход | F7 запись | F8 повтор | F9 стоп | F10 поиск",
                     225.f, 13.f, .31f);
    m_mainLayer->addChild(m_notice);

    refresh(0.f);
    refreshNames();
    schedule(schedule_selector(ControlPopup::refresh), .25f);
    return true;
}

void ControlPopup::refresh(float) {
    // Cocos scheduling runs on the game thread, including when PauseLayer is open.
    guarded([this] {
        m_status->setString(Session::get().status().c_str());
        auto height = m_status->getContentSize().height;
        m_status->setScale(height > 0.f ? std::min(.29f, 60.f / height) : .29f);
    });
}

void ControlPopup::refreshNames() {
    auto names = Session::get().macros();
    std::string text = "Сохранённые: ";
    if (names.empty()) text += "нет";
    size_t count = std::min(names.size(), size_t{4});
    for (size_t index = 0; index < count; ++index) {
        if (index) text += ", ";
        auto const& name = names[index];
        text += name.size() > 25 ? name.substr(0, 22) + "..." : name;
    }
    if (names.size() > count) text += " (+" + std::to_string(names.size() - count) + ")";
    m_names->setString(text.c_str());
}

void ControlPopup::onClose(CCObject* sender) {
    if (m_closed) return;
    m_closed = true;
    if (m_levelId) m_levelId->defocus();
    if (m_name) m_name->defocus();
    Popup<PauseLayer*>::onClose(sender);
}

void ControlPopup::closeAndResume() {
    // Keep both nodes alive across removeFromParent and the native resume call.
    Ref<ControlPopup> alive(this);
    auto pause = m_pause.lock();
    onClose(nullptr);
    if (pause && pause->getParent()) pause->onResume(nullptr);
}

void ControlPopup::queue(Command command) {
    guarded([this, command] {
        Session::get().request(command);
        closeAndResume();
    });
}

void ControlPopup::onLevel(CCObject*) {
    guarded([this] {
        auto id = m_levelId->getString();
        if (id.empty()) {
            Session::get().openLevel(id);
            m_notice->setString("Выбран текущий открытый уровень");
            return;
        }
        // The actual level lookup is the game's standard online browser; it
        // supplies its normal download/error UI. The user then opens PlayLayer.
        Ref<ControlPopup> alive(this);
        Session::get().openLevel(id);
        onClose(nullptr);
    });
}

void ControlPopup::onSearch(CCObject*) { queue(Command::Search); }
void ControlPopup::onRecord(CCObject*) { queue(Command::Record); }
void ControlPopup::onPlay(CCObject*) { queue(Command::Play); }
void ControlPopup::onStop(CCObject*) { queue(Command::Stop); }

void ControlPopup::onSave(CCObject*) {
    guarded([this] {
        Session::get().save(m_name->getString());
        refreshNames();
        m_notice->setString("Макрос сохранён в JSON");
        refresh(0.f);
    });
}

void ControlPopup::onLoad(CCObject*) {
    guarded([this] {
        Session::get().load(m_name->getString());
        m_notice->setString("Макрос загружен; нажмите «Воспроизвести»");
        refresh(0.f);
    });
}

void ControlPopup::onErase(CCObject*) {
    guarded([this] {
        Session::get().erase(m_name->getString());
        refreshNames();
        m_notice->setString("Файл макроса удалён");
    });
}

void ControlPopup::onImport(CCObject*) {
    guarded([this] {
        Session::get().importFile(m_name->getString());
        refreshNames();
        m_notice->setString("Импортирован import.json из папки сохранений мода");
        refresh(0.f);
    });
}

void ControlPopup::onExport(CCObject*) {
    guarded([this] {
        Session::get().exportFile(m_name->getString());
        m_notice->setString("Экспорт: export.json в папке сохранений мода");
    });
}

void ControlPopup::onExit(CCObject*) {
    guarded([this] {
        Ref<ControlPopup> alive(this);
        // A quarantined completion has no native end screen or pause menu.
        // Exit through PlayLayer's normal quit path without resuming a pause
        // layer that is about to be removed together with the game scene.
        onClose(nullptr);
        Session::get().exitLevel();
    });
}

}
