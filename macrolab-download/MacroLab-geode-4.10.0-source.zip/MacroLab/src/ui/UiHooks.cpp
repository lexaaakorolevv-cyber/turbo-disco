#include "ControlPopup.hpp"
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/UILayer.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <optional>

using namespace geode::prelude;

namespace {
// Keys and signatures below match the pinned Geometry Dash 2.2074 bindings.
std::optional<gdm::Command> commandFor(enumKeyCodes key) {
    switch (key) {
        case KEY_F7: return gdm::Command::Record;
        case KEY_F8: return gdm::Command::Play;
        case KEY_F9: return gdm::Command::Stop;
        case KEY_F10: return gdm::Command::Search;
        default: return std::nullopt;
    }
}

CCMenuItemSpriteExtra* menuButton(CCObject* target, SEL_MenuHandler callback) {
    auto path = gdm::ui::fontPath();
    auto sprite = ButtonSprite::create("Макросы", 92, true, path.c_str(),
                                       "GJ_button_04.png", 28.f, .46f);
    if (!sprite) return nullptr;
    return CCMenuItemSpriteExtra::create(sprite, target, callback);
}
}

class $modify(MacroLabMenu, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        if (auto button = menuButton(this, menu_selector(MacroLabMenu::onMacros))) {
            auto size = CCDirector::get()->getWinSize();
            button->setPosition({size.width - 61.f, size.height - 28.f});
            menu->addChild(button);
            addChild(menu, 100);
        }
        return true;
    }

    void keyDown(enumKeyCodes key) {
        if (key == KEY_F6 && !gdm::ui::hasModalInput()) {
            gdm::ui::showControls();
            return;
        }
        MenuLayer::keyDown(key);
    }

    void onMacros(CCObject*) { gdm::ui::showControls(); }
};

class $modify(MacroLabPause, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        if (auto button = menuButton(this, menu_selector(MacroLabPause::onMacros))) {
            auto size = CCDirector::get()->getWinSize();
            button->setPosition({size.width - 64.f, size.height - 28.f});
            menu->addChild(button);
            addChild(menu, 100);
        }
    }

    void keyDown(enumKeyCodes key) {
        if (key == KEY_F6 && !gdm::ui::hasModalInput()) {
            gdm::ui::showControls(this);
            return;
        }
        PauseLayer::keyDown(key);
    }

    void onMacros(CCObject*) { gdm::ui::showControls(this); }
};

class $modify(MacroLabUI, UILayer) {
    struct Fields {
        CCLabelBMFont* status = nullptr;
    };

    bool init(GJBaseGameLayer* layer) {
        if (!UILayer::init(layer)) return false;
        auto path = gdm::ui::fontPath();
        auto size = CCDirector::get()->getWinSize();
        auto status = CCLabelBMFont::create("", path.c_str(),
                                           (size.width - 30.f) / .34f,
                                           kCCTextAlignmentLeft);
        if (status) {
            status->setAnchorPoint({0.f, 1.f});
            status->setPosition({15.f, size.height - 25.f});
            status->setScale(.34f);
            status->setColor({180, 225, 255});
            addChild(status, 100);
            m_fields->status = status;
            schedule(schedule_selector(MacroLabUI::refreshStatus), .25f);
        }
        return true;
    }

    void refreshStatus(float) {
        if (!m_fields->status) return;
        try {
            m_fields->status->setString(gdm::Session::get().status().c_str());
        } catch (std::exception const& error) {
            unschedule(schedule_selector(MacroLabUI::refreshStatus));
            gdm::ui::showError(error.what());
        }
    }

    void keyDown(enumKeyCodes key) {
        // Text entry and modal windows retain their own key handling.
        if (!gdm::ui::hasModalInput()) {
            if (key == KEY_F6) {
                gdm::ui::showControls();
                return;
            }
            if (auto command = commandFor(key)) {
                try { gdm::Session::get().request(*command); }
                catch (std::exception const& error) { gdm::ui::showError(error.what()); }
                return;
            }
        }
        UILayer::keyDown(key);
    }
};
