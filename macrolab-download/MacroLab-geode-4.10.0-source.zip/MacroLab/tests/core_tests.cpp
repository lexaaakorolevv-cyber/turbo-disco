#include "../src/core/Macro.hpp"
#include "../src/core/Recorder.hpp"
#include "../src/core/Playback.hpp"
#include "../src/core/Storage.hpp"
#include "../vendor/json.hpp"

#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
int assertions = 0;

void require(bool result, char const* message) {
    ++assertions;
    if (!result) throw std::runtime_error(message);
}

void rejected(std::function<void()> const& operation, char const* message) {
    bool threw = false;
    try { operation(); } catch (std::exception const&) { threw = true; }
    require(threw, message);
}

gdm::Metadata metadata() {
    gdm::Metadata meta;
    meta.levelId = 123;
    meta.levelHash = gdm::levelContentHash("kA13,0;1,1,2,100,3,100;");
    meta.environment = "core-test;no-game-state";
    meta.platformer = true;
    return meta;
}

gdm::Macro recorded() {
    gdm::Recorder recorder;
    recorder.start(metadata());
    recorder.input(1, 1, 1, true);
    recorder.input(1, 1, 1, true); // OS key repeat is ignored.
    recorder.input(1, 2, 3, true);
    gdm::Sample sample;
    sample.step = 2;
    sample.dual = true;
    sample.players[0] = {100.5, 50, 2, 3, 1};
    sample.players[1] = {110.5, 60, -2, -3, 257};
    recorder.sample(sample);
    sample.step = 5;
    recorder.sample(sample);
    auto macro = recorder.finish(5, false);
    require(!recorder.active(), "recorder stayed active after finish");
    require(macro.events.size() == 4, "final held releases or repeat filtering failed");
    require(macro.events[2].player == 1 && !macro.events[2].down && macro.events[2].step == 5,
        "first player final release missing");
    require(macro.events[3].player == 2 && macro.events[3].button == 3 && !macro.events[3].down,
        "second player final release missing");
    rejected([&] { recorder.input(6, 1, 1, true); }, "input accepted after finish");
    return macro;
}

void formatTests(gdm::Macro const& macro) {
    auto text = gdm::encode(macro);
    auto read = gdm::decode(text);
    require(gdm::encode(read) == text, "JSON roundtrip differs");
    require(read.samples[0].players[1].flags == 257 && read.events[1].player == 2, "second player data lost");
    require(gdm::levelContentHash("") == "cbf29ce484222325", "FNV empty vector mismatch");
    require(gdm::levelContentHash("hello") == "a430d84680aabd0b", "FNV hello vector mismatch");
    rejected([] { gdm::decode("{broken"); }, "invalid JSON accepted");
    rejected([] { gdm::decode(""); }, "empty JSON accepted");
    rejected([] { gdm::decode(std::string(15, '[') + "0" + std::string(15, ']')); }, "deep JSON accepted");
    auto duplicate = text;
    auto at = duplicate.find("\"format\": \"gdm-macro\"");
    duplicate.replace(at, 21, "\"format\": \"gdm-macro\", \"format\": \"gdm-macro\"");
    rejected([&] { gdm::decode(duplicate); }, "duplicate JSON key accepted");
    auto json = nlohmann::json::parse(text);
    json["schemaVersion"] = 2;
    rejected([&] { gdm::decode(json.dump()); }, "unknown schema accepted");
    json = nlohmann::json::parse(text);
    json["metadata"]["unknown"] = true;
    rejected([&] { gdm::decode(json.dump()); }, "unknown field accepted");
    json = nlohmann::json::parse(text);
    json["events"][0]["step"] = -1;
    rejected([&] { gdm::decode(json.dump()); }, "negative event step accepted");
    json = nlohmann::json::parse(text);
    json["events"][0]["player"] = 256;
    rejected([&] { gdm::decode(json.dump()); }, "wrapped uint8 player accepted");
    json = nlohmann::json::parse(text);
    json["events"][0]["down"] = 1;
    rejected([&] { gdm::decode(json.dump()); }, "nonboolean event accepted");
    auto bad = macro;
    bad.events[1].step = 0;
    rejected([&] { gdm::validate(bad); }, "nonmonotonic events accepted");
    bad = macro;
    bad.events.pop_back();
    rejected([&] { gdm::validate(bad); }, "stuck held input accepted");
    bad = macro;
    bad.events[0].down = false;
    rejected([&] { gdm::validate(bad); }, "unheld release accepted");
    bad = macro;
    bad.samples.push_back(bad.samples.front());
    rejected([&] { gdm::validate(bad); }, "duplicate sample step accepted");
    bad = macro;
    bad.samples[0].players[0].x = std::numeric_limits<double>::quiet_NaN();
    rejected([&] { gdm::encode(bad); }, "non-finite player state accepted");
    bad = macro;
    bad.endStep = 0;
    rejected([&] { gdm::validate(bad); }, "events beyond endStep accepted");
    bad = macro;
    bad.events.push_back({bad.endStep, 1, 1, true});
    bad.events.push_back({bad.endStep, 1, 1, false});
    rejected([&] { gdm::validate(bad); }, "press accepted at release-only endStep");
    auto current = metadata();
    gdm::validateCompatibility(macro.meta, current);
    current.gameVersion = "2.208";
    rejected([&] { gdm::validateCompatibility(macro.meta, current); }, "game mismatch accepted");
    current = metadata(); current.geodeVersion = "5.0.0";
    rejected([&] { gdm::validateCompatibility(macro.meta, current); }, "Geode mismatch accepted");
    current = metadata(); current.levelHash = gdm::levelContentHash("changed");
    rejected([&] { gdm::validateCompatibility(macro.meta, current); }, "level hash mismatch accepted");
    current = metadata(); current.platformer = false;
    rejected([&] { gdm::validateCompatibility(macro.meta, current); }, "platformer mismatch accepted");
    current = metadata(); current.environment += ";changed-settings";
    rejected([&] { gdm::validateCompatibility(macro.meta, current); }, "environment mismatch accepted");
    current = metadata(); current.stepHz = 60;
    rejected([&] { gdm::validateMetadata(current); }, "unsupported timestep accepted");
}

void playbackTests(gdm::Macro const& macro) {
    gdm::Playback playback;
    playback.start(macro, metadata());
    require(playback.eventsAt(0).empty(), "unexpected event at step zero");
    auto events = playback.eventsAt(1);
    require(events.size() == 2 && events[1].player == 2, "dual input not returned");
    require(playback.eventsAt(1).empty(), "events replayed twice in one step");
    require(!playback.check(macro.samples[0], 0.001), "matching sample desynchronized");
    require(playback.eventsAt(5).size() == 2, "final releases missing in playback");
    require(!playback.ended(5), "playback ended before final verification checkpoint");
    require(!playback.check(macro.samples[1], 0.001), "endpoint sample desynchronized");
    require(playback.ended(5), "playback did not end after events and samples");
    playback.stop();
    require(!playback.active() && playback.eventsAt(6).empty(), "stop failed");
    playback.start(macro, metadata());
    rejected([&] { playback.eventsAt(2); }, "skipped input did not fail");
    require(!playback.active(), "failed playback stayed active");
    playback.start(macro, metadata());
    auto state = macro.samples[0]; state.players[1].y += 1;
    auto error = playback.check(state, 0.1);
    require(error && error->find("player 2") != std::string::npos, "dual-player desync not detected");
    require(!playback.active(), "desync did not stop playback");
    playback.start(macro, metadata());
    state = macro.samples[0]; state.dual = false;
    require(playback.check(state).has_value(), "dual state desync not detected");
    playback.start(macro, metadata());
    state = macro.samples[0]; state.players[0].flags ^= 256;
    require(playback.check(state).has_value(), "gravity/mode desync not detected");
    playback.start(macro, metadata());
    state = macro.samples[0]; ++state.step;
    require(playback.check(state).has_value(), "skipped checkpoint not detected");
    playback.start(macro, metadata());
    state = macro.samples[0]; state.players[0].x = std::numeric_limits<double>::infinity();
    require(playback.check(state).has_value(), "non-finite runtime state not detected");
    playback.start(macro, metadata());
    rejected([&] { playback.check(macro.samples[0], -1); }, "invalid tolerance accepted");
}

void recorderTests() {
    gdm::Recorder recorder;
    rejected([&] { recorder.finish(0, false); }, "finish accepted without start");
    recorder.start(metadata());
    recorder.input(3, 1, 1, true);
    rejected([&] { recorder.input(2, 1, 1, false); }, "recorder accepted backwards input");
    rejected([&] { recorder.input(3, 0, 1, true); }, "recorder accepted invalid player");
    rejected([&] { recorder.input(3, 1, 0, true); }, "recorder accepted invalid button");
    rejected([&] { recorder.finish(2, false); }, "recorder accepted backwards finish");
    rejected([&] { recorder.finish(3, true); }, "recorder accepted press at endpoint");
    auto macro = recorder.finish(4, true);
    require(macro.completed && macro.events.back().step == 4 && !macro.events.back().down,
        "final release failed");
    recorder.start(metadata());
    require(recorder.macro().events.empty(), "new recording did not reset previous events");
    recorder.input(0, 1, 1, false);
    require(recorder.finish(0, false).events.empty(), "unheld manual release recorded");
}

void storageTests(gdm::Macro const& macro) {
    namespace fs = std::filesystem;
    auto temporary = fs::temp_directory_path() / ("gdm-core-tests-" +
        std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    fs::create_directories(temporary);
    struct Cleanup { fs::path path; ~Cleanup() { std::error_code error; fs::remove_all(path, error); } } cleanup{temporary};
    gdm::Storage storage(temporary / "macros");
    storage.save("dual", macro);
    require(storage.list() == std::vector<std::string>{"dual"}, "storage listing incorrect");
    require(gdm::encode(storage.load("dual")) == gdm::encode(macro), "storage roundtrip mismatch");
    storage.save("dual", macro); // Existing files can be replaced.
    storage.exportTo("dual", temporary / "export.json");
    storage.importFrom(temporary / "export.json", "imported");
    require(storage.list().size() == 2, "import/export did not create macro");
    for (auto const* name : {"../escape", "x/y", "x\\y", "", "CON", "nul", "name.json"}) {
        rejected([&] { storage.save(name, macro); }, "unsafe macro name accepted");
    }
    rejected([&] { storage.importFrom(temporary / "macros" / ".." / "export.json", "unsafe"); },
        "import traversal accepted");
    { std::ofstream file(temporary / "bad.json"); file << "{broken"; }
    rejected([&] { storage.importFrom(temporary / "bad.json", "bad"); }, "corrupt import accepted");
    require(!fs::exists(temporary / "macros" / "bad.json"), "corrupt import left saved macro");
    { std::ofstream file(temporary / "huge.json"); file << "x"; }
    fs::resize_file(temporary / "huge.json", gdm::MaxJsonBytes + 1);
    rejected([&] { storage.importFrom(temporary / "huge.json", "huge"); }, "oversized file accepted");
    std::error_code error;
    fs::create_symlink(temporary / "export.json", temporary / "macros" / "linked.json", error);
    if (!error) {
        rejected([&] { storage.load("linked"); }, "symlink load accepted");
        rejected([&] { storage.save("linked", macro); }, "symlink save accepted");
        rejected([&] { storage.erase("linked"); }, "symlink erase accepted");
        rejected([&] { storage.exportTo("dual", temporary / "macros" / "linked.json"); }, "symlink export accepted");
        require(storage.list().size() == 2, "symlink appeared in listing");
        fs::create_directory_symlink(temporary / "macros", temporary / "linkdir");
        rejected([&] { gdm::Storage linked(temporary / "linkdir"); }, "symlink storage root accepted");
    } else {
        std::cout << "Symlink tests skipped: " << error.message() << '\n';
    }
    storage.erase("dual");
    require(storage.list() == std::vector<std::string>{"imported"}, "erase did not remove macro");
    rejected([&] { storage.load("missing"); }, "missing macro accepted");
    rejected([&] { storage.erase("missing"); }, "erase silently accepted missing macro");
}
} // namespace

int main() {
    try {
        auto macro = recorded();
        formatTests(macro);
        playbackTests(macro);
        recorderTests();
        storageTests(macro);
        std::cout << "core_tests: " << assertions << " assertions passed; no Geometry Dash runtime was tested\n";
        return 0;
    } catch (std::exception const& error) {
        std::cerr << "core_tests FAILED: " << error.what() << '\n';
        return 1;
    }
}
