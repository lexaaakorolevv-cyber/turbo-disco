#include "search/Search.hpp"

#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, char const* message) {
    if (!condition) throw std::runtime_error(message);
}

gdm::SearchConfig smallConfig() {
    gdm::SearchConfig config;
    config.maxAttempts = 128;
    config.maxSteps = 30;
    config.segmentSteps = 2;
    config.beamWidth = 8;
    config.maxTotalSteps = 2000;
    return config;
}

// Deliberately unlike a button-driven mock of the implementation: this is a
// tiny physical world with a low ceiling followed by a floor obstacle.
// Jumping immediately kills the cube; jumping after the ceiling clears it.
struct CubeWorld {
    unsigned x = 0;
    unsigned jump[2]{};
    bool dual = false, dynamicDual = false, dead = false;
    bool impossible = false;
    unsigned resets = 0;

    void reset() { x = 0; jump[0] = jump[1] = 0; dead = false; ++resets; }
    bool dualActive() const { return dual || (dynamicDual && x >= 2); }
    gdm::Observation observation() const {
        gdm::Observation o;
        o.x1 = o.x2 = x;
        o.y1 = jump[0]; o.y2 = jump[1];
        o.vx1 = o.vx2 = 1;
        o.grounded1 = !jump[0]; o.grounded2 = !jump[1];
        o.dead = dead; o.dual = dualActive();
        o.progress = float(x) / 10 * 100;
        o.nearestHazardX = 5; o.nearestHazardY = 0;
        return o;
    }
    void simulate(gdm::Input const& input) {
        for (unsigned p = 0; p != 2; ++p) {
            if (input[p][0] && jump[p] == 0) jump[p] = 4;
            if (jump[p]) --jump[p];
        }
        ++x;
        if (x == 2 && jump[0]) dead = true;
        if (x == 5 && !jump[0]) dead = true;
        if (dualActive() && x == 3 && jump[1]) dead = true;
        if (dualActive() && x == 7 && !jump[1]) dead = true;
        if (impossible && x == 1) dead = true;
    }
    bool completed() const { return x == 10 && !dead; }
};

void run(gdm::Search& search, CubeWorld& world) {
    uint64_t step = 0;
    unsigned watchdog = 0;
    while (search.running()) {
        require(++watchdog < 10000, "search loop did not terminate");
        if (search.needsRestart()) {
            world.reset();
            search.beginAttempt();
            step = 0;
            if (!search.running()) break;
        }
        auto input = search.desired(step, world.observation());
        if (!search.running()) break;
        world.simulate(input);
        ++step;
        if (world.completed()) search.finishAttempt(true);
        else search.observe(step, world.observation());
    }
}

void delayedJumpIsFoundAndReplayed() {
    gdm::Search search;
    CubeWorld world;
    search.start(false, false, smallConfig());
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Found, "did not solve ceiling/obstacle world");
    require(world.resets > 1, "search must retry real reset rather than restore state");
    require(search.solution().size() == 10, "successful input trace has wrong length");
    require(!search.solution()[0][0][0], "solution jumped into low ceiling");
    bool jumped = false;
    world.reset();
    for (auto const& input : search.solution()) {
        jumped |= input[0][0];
        world.simulate(input);
        require(!world.dead, "successful input trace does not replay");
    }
    require(jumped && world.completed(), "replay did not actually clear obstacle and finish");
}

void bothPlayersHaveIndependentBranches(bool dynamicDual) {
    gdm::Search search;
    CubeWorld world;
    world.dual = !dynamicDual;
    world.dynamicDual = dynamicDual;
    auto config = smallConfig();
    config.maxAttempts = 512;
    config.maxTotalSteps = 10000;
    search.start(false, world.dual, config);
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Found, "dual world was not solved");
    bool differs = false, secondJumped = false;
    world.reset();
    for (auto const& input : search.solution()) {
        differs |= input[0][0] != input[1][0];
        secondJumped |= input[1][0];
        world.simulate(input);
        require(!world.dead, "dual solution did not replay");
    }
    require(differs && secondJumped && world.completed(), "second-player independent branches missing");
}

void failureCancellationAndLimits() {
    gdm::Search search;
    CubeWorld world;
    world.impossible = true;
    search.start(false, false, smallConfig());
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Exhausted, "impossible world did not exhaust");
    require(search.solution().empty(), "failure exposed a solution");
    search.start(false, false, smallConfig());
    search.beginAttempt();
    search.stop();
    require(!search.running() && !search.needsRestart(), "cancel left search running");
    require(search.outcome() == gdm::SearchOutcome::Cancelled, "cancel reason lost");

    auto config = smallConfig(); config.maxAttempts = 1;
    world.impossible = false;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::AttemptLimit, "attempt limit ignored");
    config = smallConfig(); config.maxTotalSteps = 1;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::TotalStepLimit, "total duration limit ignored");
    config = smallConfig(); config.maxSteps = 2;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::StepLimit, "attempt length limit ignored");
    config = smallConfig(); config.segmentSteps = 0;
    search.start(false, false, config);
    require(search.outcome() == gdm::SearchOutcome::InvalidConfiguration, "bad config accepted");
}

void unknownModesAndStepOrderAreRejected() {
    gdm::Search search;
    search.start(false, false, smallConfig()); search.beginAttempt();
    gdm::Observation observation; observation.mode1 = 42;
    search.desired(0, observation);
    require(search.outcome() == gdm::SearchOutcome::Unsupported, "unknown mode accepted");
    search.start(false, false, smallConfig()); search.beginAttempt();
    search.desired(1, {});
    require(search.outcome() == gdm::SearchOutcome::ReplayMismatch, "skipped simulation step accepted");
}

// A platformer must actually press right; no hidden automatic x movement.
void platformerMovementIsEnumerated() {
    gdm::Search search;
    auto config = smallConfig();
    search.start(true, false, config);
    uint64_t step = 0;
    double x = 0;
    while (search.running()) {
        if (search.needsRestart()) { x = 0; step = 0; search.beginAttempt(); }
        gdm::Observation o; o.x1 = x; o.grounded1 = true; o.progress = float(x * 10);
        auto input = search.desired(step, o);
        if (!search.running()) break;
        x += int(input[0][2]) - int(input[0][1]);
        ++step;
        if (x >= 4) search.finishAttempt(true);
        else { o.x1 = x; o.progress = float(x * 10); search.observe(step, o); }
    }
    require(search.outcome() == gdm::SearchOutcome::Found, "platformer right movement not searched");
    for (auto const& input : search.solution())
        require(!(input[0][1] && input[0][2]), "search generated conflicting directional holds");
}

// A complete ten-second corridor must not consume a retry for every twelve
// simulation ticks. A late obstacle must be refined near the actual collision.
void longRolloutsAndLateObstacle() {
    for (bool obstacle : {false, true}) {
        gdm::Search search;
        search.start(false, false, {});
        uint64_t step = 0;
        unsigned x = 0, jumping = 0, resets = 0;
        bool dead = false;
        unsigned watchdog = 0;
        while (search.running()) {
            require(++watchdog < 20000, "long rollout did not terminate");
            if (search.needsRestart()) {
                x = jumping = 0; dead = false; step = 0; ++resets;
                search.beginAttempt();
            }
            gdm::Observation o;
            o.x1 = x; o.y1 = jumping; o.vx1 = 1; o.grounded1 = !jumping;
            o.progress = float(x) / 2400 * 100;
            if (obstacle) { o.nearestHazardX = 1001; o.nearestHazardY = 0; }
            auto input = search.desired(step, o);
            if (!search.running()) break;
            if (input[0][0] && !jumping) jumping = 40;
            if (jumping) --jumping;
            ++x; ++step;
            dead = obstacle && x == 1001 && !jumping;
            if (x == 2400 && !dead) search.finishAttempt(true);
            else {
                o.x1 = x; o.y1 = jumping; o.grounded1 = !jumping;
                o.progress = float(x) / 2400 * 100; o.dead = dead;
                search.observe(step, o);
            }
        }
        require(search.outcome() == gdm::SearchOutcome::Found, "late/empty ten-second level failed");
        require(search.solution().size() == 2400, "long solution trace truncated");
        require(resets <= (obstacle ? 8u : 1u), "search still retries every segment of empty corridor");
        require(search.bestProgress() == 100, "completion progress not reported");
        if (obstacle) {
            x = jumping = 0;
            for (auto const& input : search.solution()) {
                if (input[0][0] && !jumping) jumping = 40;
                if (jumping) --jumping;
                ++x;
                require(x != 1001 || jumping, "late-obstacle solution did not replay");
            }
            require(x == 2400, "late-obstacle replay did not reach actual end");
        }
    }
}
} // namespace

int main() {
    try {
        delayedJumpIsFoundAndReplayed();
        bothPlayersHaveIndependentBranches(false);
        bothPlayersHaveIndependentBranches(true);
        failureCancellationAndLimits();
        unknownModesAndStepOrderAreRejected();
        platformerMovementIsEnumerated();
        longRolloutsAndLateObstacle();
        std::cout << "search tests passed\n";
        return EXIT_SUCCESS;
    } catch (std::exception const& e) {
        std::cerr << "search test failure: " << e.what() << '\n';
        return EXIT_FAILURE;
    }
}
