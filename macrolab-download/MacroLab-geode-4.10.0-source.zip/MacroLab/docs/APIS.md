# Проверка API и границы подтверждённого

Цель адаптера: **Geometry Dash 2.2074, Windows x64, Geode SDK 4.10.0**.
Это фиксированная проверенная по исходникам комбинация, а не утверждение о
последних версиях Geode или Geometry Dash на дату установки.

## Первичные источники

* [Geode v4.10.0, commit f8b42defff2edad021e5a050811df63cc4d4553e](https://github.com/geode-sdk/geode/tree/f8b42defff2edad021e5a050811df63cc4d4553e).
  [CMakeLists.txt:200–208](https://github.com/geode-sdk/geode/blob/f8b42defff2edad021e5a050811df63cc4d4553e/CMakeLists.txt#L200)
  задаёт GD 2.2074 для Windows, macOS, iOS и Android. Наш адаптер ограничен Windows.
  [VERSION](https://github.com/geode-sdk/geode/blob/f8b42defff2edad021e5a050811df63cc4d4553e/VERSION) — `4.10.0`.
* [Bindings commit f8aec5d1f3df76d840dfd2609f02cef30dc6efdf](https://github.com/geode-sdk/bindings/tree/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf).
  Файл [bindings/2.2074/GeometryDash.bro](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/2.2074/GeometryDash.bro)
  содержит все перечисленные ниже сигнатуры, поля и адреса.
  Наш CMake фиксирует этот commit: сам SDK 4.10.0 по умолчанию скачивает движущийся `main`.
* [Geode Loader.hpp](https://github.com/geode-sdk/geode/blob/f8b42defff2edad021e5a050811df63cc4d4553e/loader/include/Geode/loader/Loader.hpp#L153)
  предоставляет `Loader::queueInMainThread(ScheduledFunction&&)` и вспомогательную
  `geode::queueInMainThread(...)`. Игровые объекты в этом проекте используются
  непосредственно в callback игрового потока; поиск не переносит их в worker.

## Реальные сигнатуры игровых хуков

Все адреса в этой таблице относительные, из поля `win` указанного `.bro`.
Код использует сгенерированные Geode хуки, а не вручную прибавляет адреса.

| Класс | Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- | --- |
| GJBaseGameLayer | `virtual void update(float dt)` | `0x232100` | 13785 |
| GJBaseGameLayer | `void processCommands(float dt)` | `0x234170` | 14730 |
| GJBaseGameLayer | `void handleButton(bool down, int button, bool isPlayer1)` | `0x22e190` | 14483 |
| GJBaseGameLayer | `float getModifiedDelta(float dt)` | `0x232060` | 14347 |
| PlayLayer | `bool init(GJGameLevel*, bool useReplay, bool dontCreateObjects)` | `0x38ec70` | 28314 |
| PlayLayer | `void resetLevel()` | `0x3a1f90` | 28392 |
| PlayLayer | `void resetLevelFromStart()` | `0x3a1df0` | 28393 |
| PlayLayer | `void onQuit()` | `0x3a3db0` | 28367 |
| PlayLayer | `virtual void onExit()` | `0x3a41c0` | 28188 |
| PlayLayer | `void levelComplete()` | `0x390c30` | 28318 |
| PlayLayer | `virtual void destroyPlayer(PlayerObject*, GameObject*)` | `0x39caf0` | 28200 |
| PlayLayer | `void updateAttempts()` | `0x3a2c70` | 28499 |
| PlayLayer | `void commitJumps()` | `0x3a2eb0` | 28255 |
| PlayLayer | `void updateProgressbar()` | `0x39b4f0` | 28535 |
| PlayLayer | `virtual void postUpdate(float dt)` | `0x39da60` | 28189 |
| PlayLayer | `virtual void updateAttemptTime(float)` | `0x39e0f0` | 28193 |
| PlayLayer | `float getCurrentPercent()` | `0x39ca70` | 28275 |

### Номер игрока и кнопки

Имя `isPlayer1` у `handleButton` в bindings вводит в заблуждение. В GD 2.2074
используемая цепочка подтверждает **false = P1, true = P2**:

1. `EditorUI::playerTouchBegan`/`playerTouchEnded` (строки 7058–7088) передают
   `queueButton(..., false)` для `m_playerTouchID1` и `true` для `m_playerTouchID2`.
2. `GJBaseGameLayer::queueButton(int, bool, bool isPlayer2)` (14756) сохраняет
   значение в `PlayerButtonCommand::m_isPlayer2`.
3. Встроенный `GJBaseGameLayer::updateReplay` (15568–15570) передаёт это же поле
   третьим аргументом `handleButton`.

Поэтому адаптер называет этот аргумент `player2`; JSON хранит явные номера 1/2.
[Enums.hpp:192](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/include/Geode/Enums.hpp#L192)
задаёт `PlayerButton::Jump = 1`, `Left = 2`, `Right = 3`.

Подтверждённые поля: `GJBaseGameLayer::m_player1`, `m_player2`, `m_objects`,
`m_level`, `m_levelSettings`, `m_isPlatformer`, `m_isTestMode`, `m_gameState`,
`m_extraDelta`, `m_resumeTimer`, `m_currentStep`, очереди кнопок;
`GJGameState::m_levelTime`, `m_currentProgress`, `m_isDualMode`, `m_timeWarp`;
`PlayerObject::m_yVelocity` (`double`), `m_playerSpeed` (`float`), `m_isDead`,
`m_isOnGround`, `m_isUpsideDown`, `m_isShip`, `m_isBird`, `m_isBall`, `m_isDart`,
`m_isRobot`, `m_isSpider`, `m_isSwing`, `m_isSideways`, `m_isDashing`.
Это реальные поля, но их наличие само по себе не доказывает детерминизм движка.

## Подтверждённые адресуемые точки блокировки статистики

`src/game/StatsHooks.cpp` использует только методы с адресами Windows:

| Класс | Сигнатура | Windows |
| --- | --- | --- |
| GJGameLevel | `void savePercentage(int, bool, int, int, bool)` | `0x169db0` |
| GJGameLevel | `void storeNewLocalScore(int, int)` | `0x16a690` |
| GameStatsManager | `void encodeDataTo(DS_Dictionary*)` | `0x1eedd0` |
| GameStatsManager | `void incrementStat(char const*, int)` | `0x1d1500` |
| GameStatsManager | `void setStat(char const*, int)` | `0x1d2300` |
| GameStatsManager | `void incrementChallenge(GJChallengeType, int)` | `0x1df0f0` |
| GameStatsManager | `void completedLevel(GJGameLevel*)` | `0x1db3e0` |
| GameStatsManager | `void completedStarLevel(GJGameLevel*)` | `0x1db7a0` |
| GameStatsManager | `void completedDemonLevel(GJGameLevel*)` | `0x1db530` |
| GameStatsManager | `GJRewardItem* completedDailyLevel(GJGameLevel*)` | `0x1dfe10` |
| GameStatsManager | `void completedMapPack(GJMapPack*)` | `0x1dbe30` |
| GameStatsManager | `void awardCurrencyForLevel(GJGameLevel*)` | `0x1dd990` |
| GameStatsManager | `void awardDiamondsForLevel(GJGameLevel*)` | `0x1de170` |
| GameStatsManager | `bool awardSecretKey()` | `0x1ee660` |
| GameStatsManager | `void storeSecretCoin(char const*)` | `0x1dd020` |
| GameStatsManager | `void storeUserCoin(char const*)` | `0x1dcdd0` |
| GameStatsManager | `void registerRewardsFromItem(GJRewardItem*)` | `0x1ee170` |
| GameStatsManager | `void checkAchievement(char const*)` | `0x1d2470` |
| GameStatsManager | `void checkCoinAchievement(GJGameLevel*)` | `0x1da830` |
| GameLevelManager | `void saveLevel(GJGameLevel*)` | `0x146d40` |
| GameLevelManager | `void updateUserScore()` | `0x153790` |
| GameLevelManager | `void uploadLevel(GJGameLevel*)` | `0x14a6c0` |

Блокировка сохраняется после остановки макроса до выхода из `PlayLayer`, включая
нативный `onQuit`. `GJGameLevel` проверяется по адресу оригинала или временной
копии; глобальные статистика/награды/отправка score блокируются на время карантина.
`completedDailyLevel` при блокировке возвращает `nullptr`, `awardSecretKey` — `false`.

На Windows **не имеют самостоятельного адреса**: `GJGameLevel::saveNewScore`,
`GameStatsManager::storePendingUserCoin`, одноаргументный `incrementStat`,
`checkCoinsForLevel`. Они помечены `win inline`, поэтому не используются как
хуки. Inline `saveNewScore` сначала меняет `m_bestTime`/`m_bestPoints` и только
затем вызывает `storeNewLocalScore`: одного хука сохранения недостаточно для
защиты полей. Поэтому нужна временная копия уровня. `m_dontSave` — реальное поле,
но считать его единственной защитой без изучения нативных вызывающих функций нельзя.

Bindings подтверждают существование `m_isTestMode`, но не документируют все
ветки статистики, которые оно отключает. Это дополнительная защита, а не
доказательство полной изоляции. Достижения и изменения от сторонних модов,
которые обходят эти API, требуют отдельной проверки; Linux core-тесты не
заменяют проверки сохранений/статистики в Windows Geometry Dash.

Дополнительно адаптер изолирует `GameStatsManager::m_pendingUserCoins` на весь
карантин. Адресуемый `encodeDataTo` при сохранении временно подставляет исходный
словарь; при выходе исходный указатель восстанавливается. `saveLevel` отдельно
отвергает оригинал/временную копию во время карантина. Файловое хранилище создаётся
лениво, поэтому ошибка каталога макросов не мешает открыть обычный уровень.

`Mod::getResourcesDir`, `Loader::getGameVersion`, `Loader::getVersion`,
`VersionInfo::toNonVString`, `CCDictionary::copy` также проверены по SDK headers.
Копия уровня сериализуется через `DS_Dictionary`/`encodeWithCoder` и
`GJGameLevel::createWithCoder`; `m_dontSave` выставлен явно. Эти операции не
восстанавливают физическое состояние игрока.

## Что известно о шаге симуляции

Сигнатуры `update`, `getModifiedDelta`, `processCommands` подтверждены, но
`.bro` не содержит нативную реализацию `GJBaseGameLayer::update`. Из bindings
нельзя вывести число `processCommands` на один `update`, порядок обработки
всех физических действий или поведение при resume/timewarp.

Для дополнительной проверки изучен открытый мод
[xdBot, commit 16ef8e86d3a295119583a1c236be7a9aab7568e4](https://github.com/zilko/xdBot/tree/16ef8e86d3a295119583a1c236be7a9aab7568e4).
Его `mod.json` задаёт Geode 4.4.0 и GD 2.2074. Это вторичный практический
источник, не официальная спецификация движка; код оттуда в проект не копировался.

* [src/hacks/tps_bypass.cpp](https://github.com/zilko/xdBot/blob/16ef8e86d3a295119583a1c236be7a9aab7568e4/src/hacks/tps_bypass.cpp)
  при TPS=240 оставляет нативные `update` и `getModifiedDelta`. Для других TPS
  учитывает `m_resumeTimer`, `m_extraDelta`, `m_gameState.m_timeWarp`.
* [src/global.cpp:160](https://github.com/zilko/xdBot/blob/16ef8e86d3a295119583a1c236be7a9aab7568e4/src/global.cpp#L160)
  определяет номер шага через `int(m_gameState.m_levelTime * TPS) + 1`.
* [src/main.cpp:199](https://github.com/zilko/xdBot/blob/16ef8e86d3a295119583a1c236be7a9aab7568e4/src/main.cpp#L199)
  допускает повторные `processCommands` с одним номером шага, проверяет
  `previousFrame`, вызывает нативный `processCommands` до вставки replay-input.

Следствие: нельзя объявлять каждый вызов `processCommands` отдельным физическим
шагом лишь на основании названия функции. Фиксированные вызовы `update(1/240)`
с ограниченным бюджетом — стратегия адаптера, которая должна проверяться
в самой игре. Проверочный replay и обнаружение рассинхронизации обязательны;
при несовпадении параметров/границы шага сессия должна прерываться.

Текущий адаптер вызывает fixed-update с `1/240` и внедряет действия **после**
нативного `processCommands`. Он использует native `m_gameState.m_unkUint2`,
который inline `updateReplay` сравнивает с `PlayerButtonCommand::m_step`.
Повторные значения/нулевые resume-вызовы не добавляют шаг; скачок больше единицы
прерывает сессию. Событие нативного достижения конца учитывается до отдельной
cocos-анимации. Это стратегия адаптера; подтверждение фактической частоты и
стабильности всех native substeps остаётся частью игрового smoke test.

## Не доказано этим аудитом

* Загрузка DLL в настоящем GD, корректный бинарный ABI и совместимость с другими модами.
* Равенство состояния после reset для случайных триггеров, музыки, startpos,
  practice checkpoints, всех timewarp/платформенных механик.
* Полное прохождение любых уровней ограниченным поиском.
* Отсутствие всех возможных прямых записей глобальных словарей вне перехваченных
  методов. Нужна проверка исходных и итоговых сохранений игры по инструкции README.

Статическая сверка API и portable core-тесты отделены от игровых проверок.
Готовность для игровой установки зависит от последних.
