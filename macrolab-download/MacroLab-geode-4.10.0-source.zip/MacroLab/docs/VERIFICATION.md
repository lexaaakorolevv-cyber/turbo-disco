# Что фактически проверено

Проверка выполнена 13 октября 2026 года. Исходники мода проверены по официальному Geode SDK **4.10.0** и Windows x64 bindings для Geometry Dash **2.2074**. Готовая DLL или пакет `.geode` здесь не собирались; Geometry Dash не запускался.

## Исходники SDK и bindings

- Geode: официальный тег `v4.10.0`, commit `f8b42defff2edad021e5a050811df63cc4d4553e`.
- Bindings: commit `f8aec5d1f3df76d840dfd2609f02cef30dc6efdf`, каталог `bindings/2.2074`.
- Настоящие заголовки `Geode/binding` и `Geode/modify` сгенерированы официальным Linux Codegen с аргументом **Win64**. Сверка включает регистрацию `$modify` по этим заголовкам, а не только чтение названий методов.
- Заголовки зависимостей соответствуют CMake SDK: fmt 11.1.4, geode-sdk/json 3.2.2, result 1.3.3, TulipHook 3.1.6.

## Выполненные проверки

| Проверка | Результат | Что подтверждает |
|---|---|---|
| Portable CMake configure и сборка | Успешно | Реальный проект с `MACROLAB_CORE_ONLY=ON`, GNU C++ 14.2, C++20, Release |
| CTest | **2/2 успешно** | Suites `macro_core` и `search_core` |
| `core_tests` | **81 проверка успешно** | JSON, совместимость, запись/отпускания, playback checks, файловые операции и обработка повреждённых данных |
| `search_tests` | Успешно | Ограниченный поиск и повтор последовательностей в отдельных синтетических моделях, бюджеты, отмена, platformer/dual |
| Прямая проверка всех исходных `.cpp` по Geode API | **10/10 успешно** | Синтаксис C++, типы, существование сигнатур, создание Geode hooks/templates; заглушки игровых API и модулей не использовались |
| CMake `FetchContent` для закреплённых bindings | Успешно | Нужный commit загружается; `SOURCE_SUBDIR fetch-only` пропускает преждевременный запуск CMake bindings |
| Раскладка ресурсов | Подтверждена исходниками CLI и Loader | Файлы шрифта доступны по basename внутри каталога ресурсов мода |

Проверенные единицы компиляции:

```text
src/core/Macro.cpp
src/core/Recorder.cpp
src/core/Playback.cpp
src/core/Storage.cpp
src/search/Search.cpp
src/game/Session.cpp
src/game/GameHooks.cpp
src/game/StatsHooks.cpp
src/ui/ControlPopup.cpp
src/ui/UiHooks.cpp
```

Для проверки API использован Clang **19.1.7**, `-std=c++23 -fsyntax-only -fms-extensions`, target `x86_64-w64-windows-gnu`, настоящие Windows headers MinGW и сгенерированные Win64 bindings. После последнего изменения reset-хука и метаданных повторно проверены все десять файлов. В игровых единицах компиляции остались предупреждения заголовков SDK о повторном `inline` и устаревших 3DNow intrinsics; ошибок нет.

Эта проверка **не подтверждает Windows MSVC ABI и линковку**. MinGW используется только как источник Windows headers для проверки синтаксиса и API. Релизный мод должен собираться поддерживаемым Windows x64 toolchain, как описано в README.

Для повторения portable tests:

```sh
cmake -S . -B build-core -DMACROLAB_CORE_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core --parallel
ctest --test-dir build-core --output-on-failure
```

## Дополнительная сверка сборочных механизмов

Geode SDK 4.10.0 требует **CMake 3.25 или новее**. Поведение `SOURCE_SUBDIR` подтверждено [документацией CMake](https://cmake.org/cmake/help/latest/module/FetchContent.html#command:fetchcontent_makeavailable) и отдельным configure с настоящим закреплённым репозиторием bindings. Полный configure/линковка Windows-мода в этой среде не выполнялись.

Команда загрузки платформенных библиотек сверена по [официальному CLI `src/sdk.rs`](https://github.com/geode-sdk/cli/blob/f5d228da3891d1f1230b0f4a9442d644bb553d60/src/sdk.rs):

```bat
set "GEODE_SDK=C:\dev\geode-4.10.0"
geode config setup
geode sdk update 4.10.0
geode sdk install-binaries --platform win --version 4.10.0
```

`geode config setup` требуется при отсутствии игрового профиля CLI. Путь SDK берётся из `GEODE_SDK`; версия устанавливается в `bin/4.10.0`. `sdk update 4.10.0` также снимает возможный ранее сохранённый режим nightly. Эти команды сверены по исходникам; установка Windows SDK-библиотек в данной Linux-среде не запускалась.

[CLI `src/package.rs`](https://github.com/geode-sdk/cli/blob/f5d228da3891d1f1230b0f4a9442d644bb553d60/src/package.rs) копирует `resources.files` по `file_name()` в `resources/<mod ID>/`. Поэтому `resources/ui-font.fnt` и `resources/ui-font.png` окажутся в `resources/local.macrolab/` под именами `ui-font.fnt` и `ui-font.png`. [Geode `Mod::getResourcesDir()`](https://github.com/geode-sdk/geode/blob/v4.10.0/loader/src/loader/Mod.cpp) возвращает соответствующий runtime-каталог. Имя страницы `file="ui-font.png"` в FNT согласовано с этой раскладкой. Это сверка механизма упаковки; готовый пакет здесь не создавался.

## Что ещё не проверено

Не выполнены MSVC-сборка/линковка, упаковка `.geode`, загрузка DLL в игре, настоящая запись и replay, реальный успешный поиск, отзывчивость UI на игровых уровнях, lifetime/ownership игровых объектов и численная проверка сохранений, наград и сетевых запросов. Синтетические tests не подтверждают физику Geometry Dash или поддержку всех механик.

Матрица обязательной игровой проверки приведена в [README](../README.md#проверка-в-настоящей-игре). До её выполнения проект следует считать проверенным исходным прототипом, а не проверенной игровой сборкой.
