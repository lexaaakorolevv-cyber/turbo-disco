#include "Session.hpp"
#include <Geode/modify/GJGameLevel.hpp>
#include <Geode/modify/GameStatsManager.hpp>
#include <Geode/modify/GameLevelManager.hpp>

using namespace geode::prelude;

// Only addressed Windows 2.2081 bindings are hooked here. In particular,
// storePendingUserCoin is inline on Windows and must not be
// treated as hookable entry points. Session additionally substitutes a private
// GJGameLevel so native direct field writes do not affect the saved level.
namespace {
bool quarantine() { return gdm::Session::get().quarantined(); }
bool blocked(GJGameLevel* level) { return gdm::Session::get().blockedLevel(level); }
}

class $modify(MacroLabLevelStats, GJGameLevel) {
    void saveNewScore(int value,int type,int ticks,int clicks,int coins,gd::string inputs,bool save){
        if(!blocked(this))GJGameLevel::saveNewScore(value,type,ticks,clicks,coins,inputs,save);
    }
    void savePercentage(int percent, bool practice, int clicks, int attempts, bool valid) {
        if (!blocked(this)) GJGameLevel::savePercentage(percent, practice, clicks, attempts, valid);
    }
    void storeNewLocalScore(int value, int type) {
        if (!blocked(this)) GJGameLevel::storeNewLocalScore(value, type);
    }
};

class $modify(MacroLabGlobalStats, GameStatsManager) {
    void markLevelAsCompletedAndClaimed(GJGameLevel* level){
        if(!quarantine())GameStatsManager::markLevelAsCompletedAndClaimed(level);
    }
    void encodeDataTo(DS_Dictionary* dict) {
        auto original=gdm::Session::get().originalPendingCoins();
        if(!quarantine()||!original){GameStatsManager::encodeDataTo(dict);return;}
        // A save/backup during a trial must serialize the real pending coins.
        struct Restore {
            GameStatsManager* manager;
            cocos2d::CCDictionary* trial;
            ~Restore(){manager->m_pendingUserCoins=trial;}
        } restore{this,m_pendingUserCoins};
        m_pendingUserCoins=original;
        GameStatsManager::encodeDataTo(dict);
    }
    void incrementStat(char const* key, int amount) {
        if (!quarantine()) GameStatsManager::incrementStat(key, amount);
    }
    void setStat(char const* key, int value) {
        if (!quarantine()) GameStatsManager::setStat(key, value);
    }
    void incrementChallenge(GJChallengeType type, int amount) {
        if (!quarantine()) GameStatsManager::incrementChallenge(type, amount);
    }
    void completedLevel(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::completedLevel(level);
    }
    void completedStarLevel(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::completedStarLevel(level);
    }
    void completedDemonLevel(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::completedDemonLevel(level);
    }
    GJRewardItem* completedDailyLevel(GJGameLevel* level) {
        if (quarantine()) return nullptr;
        return GameStatsManager::completedDailyLevel(level);
    }
    void completedMapPack(GJMapPack* pack) {
        if (!quarantine()) GameStatsManager::completedMapPack(pack);
    }
    void awardCurrencyForLevel(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::awardCurrencyForLevel(level);
    }
    void awardDiamondsForLevel(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::awardDiamondsForLevel(level);
    }
    bool awardSecretKey() {
        if (quarantine()) return false;
        return GameStatsManager::awardSecretKey();
    }
    void storeSecretCoin(char const* key) {
        if (!quarantine()) GameStatsManager::storeSecretCoin(key);
    }
    void storeUserCoin(char const* key) {
        if (!quarantine()) GameStatsManager::storeUserCoin(key);
    }
    void registerRewardsFromItem(GJRewardItem* item) {
        if (!quarantine()) GameStatsManager::registerRewardsFromItem(item);
    }
    void checkAchievement(char const* key) {
        if (!quarantine()) GameStatsManager::checkAchievement(key);
    }
    void checkCoinAchievement(GJGameLevel* level) {
        if (!quarantine()) GameStatsManager::checkCoinAchievement(level);
    }
};

class $modify(MacroLabNetworkStats, GameLevelManager) {
    void saveLevel(GJGameLevel* level) {
        if(!blocked(level))GameLevelManager::saveLevel(level);
    }
    void updateUserScore() {
        if (!quarantine()) GameLevelManager::updateUserScore();
    }
    void uploadLevel(GJGameLevel* level) {
        if (!blocked(level)) GameLevelManager::uploadLevel(level);
    }
};
