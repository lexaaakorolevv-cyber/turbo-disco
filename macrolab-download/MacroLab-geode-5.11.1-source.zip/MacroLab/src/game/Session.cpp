#include "Session.hpp"
#include "../core/LevelBinding.hpp"
#include <Geode/binding/LevelBrowserLayer.hpp>
#include <Geode/binding/GJSearchObject.hpp>
#include <Geode/cocos/robtop/xml/DS_Dictionary.h>
#include <cmath>
#include <limits>
#include <sstream>
#include <iomanip>
#include <thread>
using namespace geode::prelude;
namespace gdm {
namespace {
// No SDK objects are passed to a worker; this controller runs exclusively in game callbacks.
void requireThread() {
    // First call is from MenuLayer/PlayLayer init, not DLL static initialization.
    static std::thread::id const gameThread=std::this_thread::get_id();
    if (std::this_thread::get_id()!=gameThread) throw std::runtime_error("Операция вызвана вне игрового потока");
}
struct FlagScope {
    bool& flag; bool previous;
    explicit FlagScope(bool& value):flag(value),previous(value){flag=true;}
    ~FlagScope(){flag=previous;}
};
uint32_t movementMode(PlayerObject* p) {
    if(!p)return 0;
    if(p->m_isShip)return 1; if(p->m_isBall)return 2; if(p->m_isBird)return 3;
    if(p->m_isDart)return 4; if(p->m_isRobot)return 5; if(p->m_isSpider)return 6;
    if(p->m_isSwing)return 7; return 0;
}
PlayerState state(PlayerObject* p) {
    if(!p)return {};
    auto pos=p->getPosition();
    return {pos.x,pos.y,p->getCurrentXVelocity(),p->m_yVelocity,
        movementMode(p) | (uint32_t(p->m_isUpsideDown)<<4) | (uint32_t(p->m_isOnGround)<<5)
        | (uint32_t(p->m_isDead)<<6) | (uint32_t(p->m_isDashing)<<7)
        | (uint32_t(p->m_isSideways)<<8)};
}

// Inspect only live Cocos nodes. GameManager may contain a PlayLayer created
// off-scene; never dereference that cached pointer to establish availability.
void collectPlayLayers(CCNode* node, unsigned depth, unsigned& budget,
                       std::vector<LevelCandidate>& candidates) {
    if(!node || depth>8 || !budget || candidates.size()>=4)return;
    --budget;
    if(auto play=typeinfo_cast<PlayLayer*>(node)){
        bool const ready=play->m_level && play->m_levelSettings && play->m_player1
            && (!play->m_gameState.m_isDualMode || play->m_player2);
        candidates.push_back({play,play->isRunning(),ready});
        return; // Never traverse a level's thousands of object/sprite children.
    }
    if(auto children=node->getChildren()){
        for(unsigned i=0;i<children->count() && budget && candidates.size()<4;++i)
            collectPlayLayers(static_cast<CCNode*>(children->objectAtIndex(i)),depth+1,budget,candidates);
    }
}
}
Session& Session::get(){static Session session; return session;}
Session::Session()=default;
void Session::clearTransient(){
    m_mode=Mode::Idle;m_pending.reset();m_buttons.clear();m_held={};m_clock.reset();
    m_resetRequested=false;m_resetting=false;m_injecting=false;m_death=false;
    m_completed=false;m_verifying=false;m_advanced=false;m_pauseNoted=false;
    m_accumulator=0;m_step=0;m_attempt=0;m_search.stop();m_playback.stop();
    m_preparingSearch=false;m_analyzer.clear();m_planner.reset();
    m_plannedStep=std::numeric_limits<uint64_t>::max();m_planned={};
}
void Session::setSearchPreset(SearchPreset preset){
    requireThread();if(active())throw std::runtime_error("Остановите поиск перед сменой профиля");
    m_preset=preset;
}
SearchPreset Session::searchPreset()const{return m_preset;}
SearchConfig Session::searchConfig()const{
    SearchConfig c;
    if(m_preset==SearchPreset::Quick){c.maxAttempts=64;c.segmentSteps=12;c.beamWidth=4;c.maxTotalSteps=240*120;}
    else if(m_preset==SearchPreset::Precise){c.maxAttempts=1024;c.segmentSteps=1;c.beamWidth=16;c.maxTotalSteps=240*1200;}
    else{c.maxAttempts=256;c.segmentSteps=6;c.beamWidth=8;c.maxTotalSteps=240*600;}
    return c;
}
void Session::requestStop(){requireThread();try{start(Command::Stop);}catch(std::exception const& e){fail(e.what());}}

Storage& Session::storage(){
    if(!m_storage)m_storage=std::make_unique<Storage>(directory());
    return *m_storage;
}
void Session::attach(PlayLayer* layer) {
    requireThread();
    if(!layer || layer==m_layer)return;
    if(m_layer && m_layer!=layer)detach(m_layer);
    clearTransient();m_layer=layer; m_quarantine=false;
    m_step=0; m_attempt=0; m_message="Уровень открыт";
}
bool Session::synchronizeCurrentLevel(GJBaseGameLayer* hint) {
    requireThread();
    auto scene=CCDirector::get()->getRunningScene();
    // An outgoing level remains running during a fade. Only the incoming
    // scene can supply a new command target.
    if(auto transition=typeinfo_cast<CCTransitionScene*>(scene))scene=transition->m_pInScene;
    unsigned budget=512;
    std::vector<LevelCandidate> candidates;
    candidates.reserve(4);collectPlayLayers(scene,0,budget,candidates);
    auto exiting=m_exitingLayer.lock();
    void const* preferred=hint ? static_cast<void const*>(hint) : static_cast<void const*>(PlayLayer::get());
    auto decision=resolveLevelBinding(m_layer,exiting.data(),m_quarantine,candidates,preferred);
    if(decision.action==BindingAction::Unavailable)return false;
    if(decision.action==BindingAction::Attach){
        attach(static_cast<PlayLayer*>(const_cast<void*>(decision.token)));
        log::info("Macro Lab: attached to the live gameplay scene");
    }
    return true;
}
void Session::beginExit(PlayLayer* layer) {
    requireThread();
    if(layer==m_layer)m_exitingLayer=layer;
}
void Session::detach(PlayLayer* layer) {
    requireThread(); if(layer!=m_layer)return;
    if(active())finish(false);
    // Inputs were released synchronously before native onQuit/onExit.
    // Keep the original native retain untouched. The temporary level has its own retain.
    if(m_original){
        layer->m_level=m_original;
        if(layer->m_levelSettings)layer->m_levelSettings->m_level=m_original;
    }
    if(m_private)m_private->release();
    if(m_originalPendingCoins){
        GameStatsManager::get()->m_pendingUserCoins=m_originalPendingCoins;
        m_privatePendingCoins->release();
        m_privatePendingCoins=nullptr;m_originalPendingCoins=nullptr;
    }
    m_private=nullptr; m_original=nullptr; m_layer=nullptr; m_quarantine=false;
    clearTransient();
}
bool Session::active()const{return m_mode!=Mode::Idle;}
bool Session::preparingSearch()const{return m_preparingSearch;}
std::string Session::macroName()const{return m_macroName;}
bool Session::controlled(GJBaseGameLayer* l)const{return l==m_layer;}
bool Session::automated()const{return m_mode==Mode::Searching||m_mode==Mode::Playback;}
bool Session::quarantined()const{return m_layer&&m_quarantine;}
bool Session::blockedLevel(GJGameLevel* l)const{return quarantined()&&(l==m_original||l==m_private);}
bool Session::injecting()const{return m_injecting;}
CCDictionary* Session::originalPendingCoins()const{return m_originalPendingCoins;}
double& Session::accumulator(){return m_accumulator;}
Metadata Session::metadata()const {
    if(!m_layer||!m_layer->m_level)throw std::runtime_error("Сначала откройте уровень и начните игру");
    Metadata meta;
    meta.gameVersion=Loader::get()->getGameVersion();
    meta.geodeVersion=Loader::get()->getVersion().toNonVString();
    if(meta.gameVersion!="2.2081" || meta.geodeVersion!="5.11.1")
        throw std::runtime_error("Адаптер требует Geometry Dash 2.2081 и Geode 5.11.1");
    meta.levelId=m_layer->m_level->m_levelID.value();
    auto const& str=m_layer->m_level->m_levelString;
    meta.levelHash=levelContentHash(std::string_view(str.data(),str.size()));
    meta.platformer=m_layer->m_isPlatformer;
    meta.environment="native-fixed-update-v2;commandIndex;full-ticks;240Hz;no-practice;no-startpos;LDM="
        +std::to_string(m_layer->m_level->m_lowDetailModeToggled)
        +";twoPlayer="+std::to_string(m_layer->m_levelSettings->m_twoPlayerMode);
    std::vector<std::string> loaded;
    for(auto mod:Loader::get()->getAllMods())
        if(mod->isLoaded())loaded.push_back(mod->getID()+"@"+mod->getVersion().toNonVString());
    std::sort(loaded.begin(),loaded.end());
    std::string mods;
    for(auto const& mod:loaded)mods+=mod+"\n";
    meta.environment+=";mods-fnv1a64="+levelContentHash(mods);
    return meta;
}
Sample Session::snapshot()const {
    return {m_step,{state(m_layer->m_player1),state(m_layer->m_player2)},m_layer->m_gameState.m_isDualMode};
}
Observation Session::observation() {
    if(!m_layer->m_player1 || (m_layer->m_gameState.m_isDualMode && !m_layer->m_player2))
        throw std::runtime_error("Игрок уровня ещё не готов; поиск остановлен");
    Observation o{}; auto a=state(m_layer->m_player1),b=state(m_layer->m_player2);
    o.x1=a.x;o.y1=a.y;o.vx1=a.vx;o.vy1=a.vy;
    o.x2=b.x;o.y2=b.y;o.vx2=b.vx;o.vy2=b.vy;
    o.mode1=movementMode(m_layer->m_player1);o.mode2=movementMode(m_layer->m_player2);
    o.dual=m_layer->m_gameState.m_isDualMode;
    o.grounded1=m_layer->m_player1->m_isOnGround;o.grounded2=m_layer->m_player2 && m_layer->m_player2->m_isOnGround;
    o.upsideDown1=m_layer->m_player1->m_isUpsideDown;o.upsideDown2=m_layer->m_player2 && m_layer->m_player2->m_isUpsideDown;
    o.dead=m_death||m_layer->m_player1->m_isDead||(o.dual&&m_layer->m_player2->m_isDead);
    o.progress=std::clamp(m_layer->getCurrentPercent(),0.f,100.f);
    o.nearestHazardX=std::numeric_limits<double>::infinity();o.nearestHazardY=0;
    o.nearestHazardX2=std::numeric_limits<double>::infinity();o.nearestHazardY2=0;
    // Current collision list is bounded by the game's broad phase, not the entire level.
    size_t const count=std::min<size_t>(m_layer->m_hazardCollisionObjects.size(),
        std::min<int>(std::max(0,m_layer->m_hazardCollisionObjectsCount),512));
    for(size_t i=0;i<count;++i){
        auto object=m_layer->m_hazardCollisionObjects[i];if(!object)continue;
        auto pos=object->getPosition();
        if(pos.x>=a.x-15 && std::abs(pos.y-a.y)<100 && pos.x<o.nearestHazardX){o.nearestHazardX=pos.x;o.nearestHazardY=pos.y;}
        if(pos.x>=b.x-15 && std::abs(pos.y-b.y)<100 && pos.x<o.nearestHazardX2){o.nearestHazardX2=pos.x;o.nearestHazardY2=pos.y;}
    }
    if(m_mode==Mode::Searching && !m_preparingSearch && m_analyzer.ready()){
        // Several callbacks can observe one native full-tick boundary. Advance
        // the planner and its pulse/learning state exactly once per macro step.
        if(m_plannedStep!=m_step){
            auto scenes=m_analyzer.sample(m_layer,m_step);
            m_planned=m_planner.plan(o,scenes,m_layer->m_isPlatformer);
            m_plannedStep=m_step;
        }
        o.planned=m_planned;o.analyzed={true,o.dual};
    }
    return o;
}
void Session::request(Command cmd){
    requireThread();
    if(cmd==Command::Stop){requestStop();return;}
    if(!synchronizeCurrentLevel())throw std::runtime_error("Не найден запущенный уровень. Нажмите «Играть», затем откройте F6");
    if(cmd==Command::Play&&!m_macro)throw std::runtime_error("Макрос не загружен");
    m_pending=cmd;
}
void Session::beginFrame(){
    requireThread();
    if(m_pending){auto cmd=*m_pending;m_pending.reset();start(cmd);}
    if(m_preparingSearch){
        if(m_layer->m_isPaused || !m_analyzer.advance(1024))return;
        // Cocos animations may advance while the UI is analysing. Start the
        // actual trial from a fresh native reset, never from a frozen mid-run.
        reset();m_preparingSearch=false;
        auto meta=metadata();
        m_search.start(meta.platformer,m_layer->m_gameState.m_isDualMode,searchConfig());
        m_search.beginAttempt();m_attempt=m_search.attempt();m_recorder.start(meta);
        m_message="Анализ завершён; поиск действий и запись макроса";
    }
    if(m_resetRequested&&active()){
        m_resetRequested=false;reset();
        if(m_mode==Mode::Searching){m_search.beginAttempt();m_attempt=m_search.attempt();m_recorder.start(metadata());}
    }
    if(active()&&m_layer&&!m_layer->m_isPaused){
        // Quantize human inputs before vanilla splits a tick by its wall-clock
        // timestamp. Record and replay therefore use the same full-tick policy.
        for(auto const& button:m_layer->m_queuedButtons){
            if(m_mode!=Mode::Recording)continue;
            if(m_buttons.size()>=4096)throw std::runtime_error("Слишком много событий ввода");
            int b=static_cast<int>(button.m_button);
            if(b>=1&&b<=3)m_buttons.push_back({m_step,uint8_t(button.m_isPlayer2?2:1),uint8_t(b),button.m_isPush});
        }
        m_layer->m_queuedButtons.clear();
    }
}
void Session::start(Command cmd){
    if(cmd==Command::Stop){
        if(active())finish(false);
        m_search.stop();m_playback.stop();releaseAll();m_pending.reset();
        m_preparingSearch=false;m_analyzer.clear();m_planner.reset();
        m_verifying=false;m_resetRequested=false;m_message=quarantined()?"Остановлено; статистика заблокирована до выхода из уровня":"Остановлено";return;
    }
    auto meta=metadata();
    if(m_layer->m_isPracticeMode)throw std::runtime_error("Выйдите из practice mode; макрос должен начинаться с начала уровня");
    if(m_layer->m_startPosObject)throw std::runtime_error("StartPos не поддерживается; откройте уровень с обычного начала");
    if(m_layer->m_isIgnoreDamageEnabled)throw std::runtime_error("Отключите ignore damage перед записью или поиском");
    if(cmd==Command::Play){
        if(!m_macro)throw std::runtime_error("Макрос не загружен");
        validateCompatibility(m_macro->meta,meta);
        if(m_macro->samples.empty()||m_macro->samples.front().step!=0||m_macro->samples.back().step!=m_macro->endStep)
            throw std::runtime_error("У макроса нет начального или конечного снимка; воспроизводимость нельзя проверить");
    }
    if(active())finish(false);
    releaseAll();
    m_preparingSearch=false;
    if(!m_quarantine){
        // A private level keeps direct writes (attempts, jumps, clicks, percent, time)
        // away from the level owned by GameLevelManager. It is never saved or uploaded.
        DS_Dictionary dict;
        m_layer->m_level->encodeWithCoder(&dict);
        auto stats=GameStatsManager::get();
        auto coins=static_cast<CCDictionary*>(stats->m_pendingUserCoins->copy());
        if(!coins)throw std::runtime_error("Не удалось изолировать ожидающие монеты");
        auto copy=GJGameLevel::createWithCoder(&dict);
        if(!copy){coins->release();throw std::runtime_error("Не удалось создать изолированную копию уровня");}
        auto const& originalString=m_layer->m_level->m_levelString;
        copy->m_levelString=originalString;
        copy->m_levelID=m_layer->m_level->m_levelID.value();
        copy->m_dontSave=true;
        copy->retain();m_private=copy;m_original=m_layer->m_level;
        m_originalPendingCoins=stats->m_pendingUserCoins;m_privatePendingCoins=coins;
        stats->m_pendingUserCoins=coins;
        m_layer->m_level=copy;m_layer->m_levelSettings->m_level=copy;
        m_quarantine=true;
    }
    m_layer->m_isTestMode=true;
    m_layer->m_useReplay=false;
    m_attempt=0;m_accumulator=0;m_step=0;
    if(cmd==Command::Record){m_mode=Mode::Recording;m_recorder.start(meta);m_message="Запись ручной игры";m_verifying=false;}
    if(cmd==Command::Play){m_mode=Mode::Playback;m_playback.start(*m_macro,meta);m_message=m_verifying?"Проверка найденного макроса":"Воспроизведение";}
    if(cmd==Command::Search){
        m_mode=Mode::Searching;
        m_message="Анализ объектов уровня";m_verifying=false;
    }
    reset();
    if(m_mode==Mode::Searching){
        m_search.stop();m_analyzer.begin(m_layer);m_preparingSearch=true;m_attempt=0;
    }
    if(m_mode==Mode::Playback && m_macro->endStep==0)afterUpdate();
}
void Session::reset(){
    releaseAll();m_buttons.clear();FlagScope resetting(m_resetting);
    m_layer->m_useReplay=false;
    m_layer->m_queuedButtons.clear();m_layer->m_queuedReplayButtons.clear();m_layer->m_queuedRecordedButtons.clear();
    m_layer->removeAllCheckpoints();
    m_layer->resetLevelFromStart();
    m_layer->m_queuedButtons.clear();
    m_layer->m_isTestMode=true;
    m_death=false;m_completed=false;m_step=0;m_accumulator=0;++m_attempt;
    m_clock.reset();m_advanced=false;m_pauseNoted=false;
    m_planner.reset();m_analyzer.resetMotion();
    m_plannedStep=std::numeric_limits<uint64_t>::max();m_planned={};
}
void Session::didReset(){
    if(m_resetting||!active())return;
    // Called before native reset, while the old attempt's player state is available.
    // An unsolicited retry/reset must not append a new attempt to one macro.
    if(m_mode==Mode::Searching){
        m_search.finishAttempt(false);m_death=true;m_resetRequested=true;
    }
    else fail("Уровень перезапущен во время сессии; макрос остановлен");
}
bool Session::captureButton(GJBaseGameLayer* l,bool down,int button,bool player2){
    if(!controlled(l)||!active()||m_injecting||m_resetting)return false;
    if(button<1||button>3)return false;
    if(m_layer->m_isPaused){pauseInputs();return true;}
    if(m_mode==Mode::Recording){
        if(m_buttons.size()>=4096){fail("Слишком много событий ввода");return true;}
        m_buttons.push_back({m_step,uint8_t(player2?2:1),uint8_t(button),down});
    }
    return true;
}
void Session::apply(Event const& e){
    FlagScope injecting(m_injecting);
    // Bindings misname this flag 'isPlayer1'. EditorUI::queueButton and
    // GJBaseGameLayer::updateReplay establish false=P1, true=P2 in the selected GD bindings.
    if(e.player==2 && !m_layer->m_player2){
        if(e.down)throw std::runtime_error("Второй игрок недоступен; макрос остановлен");
    }else m_layer->handleButton(e.down,e.button,e.player==2);
    m_held[e.player-1][e.button-1]=e.down;
    if(m_mode==Mode::Recording||m_mode==Mode::Searching)m_recorder.input(e.step,e.player,e.button,e.down);
}
void Session::releaseAll(){
    if(!m_layer)return;
    FlagScope injecting(m_injecting);
    for(int p=0;p<2;++p)for(int b=0;b<3;++b){
        // Release even unobserved native inputs held before the session starts.
        if(p==0 || m_layer->m_player2)m_layer->handleButton(false,b+1,p==1);
        m_held[p][b]=false;
    }
    m_buttons.clear();
}
void Session::pauseInputs(){
    if(!m_layer||!active()||m_pauseNoted)return;
    m_pauseNoted=true;m_buttons.clear();m_layer->m_queuedButtons.clear();
    // Releases become recorded actions on the next full tick, not unrecorded
    // player-state changes while the simulator is paused.
    if(m_mode==Mode::Recording)
        for(int p=0;p<2;++p)for(int b=0;b<3;++b)
            if(m_held[p][b])m_buttons.push_back({m_step,uint8_t(p+1),uint8_t(b+1),false});
}
void Session::beforeCommands(GJBaseGameLayer* l,float dt,bool halfTick){
    if(!controlled(l)||!active()||m_preparingSearch||m_resetting||m_resetRequested||m_death||m_completed)return;
    if(m_layer->m_isPaused){pauseInputs();return;}
    m_pauseNoted=false;
    auto boundary=m_clock.accept(m_layer->m_gameState.m_commandIndex,dt,halfTick);
    if(boundary!=TickBoundary::Advance)return;
    // If vanilla executes several full ticks in one update, observe the prior
    // tick before planning its successor, instead of skipping search feedback.
    if(m_mode==Mode::Searching&&m_advanced){
        m_advanced=false;m_search.observe(m_step,observation());
        if(!m_search.running()||m_search.needsRestart())return;
    }
    m_advanced=true;
    if(m_step>240ull*600)throw std::runtime_error("Достигнут предел записи: 10 минут");
    auto sample=snapshot();
    if(m_mode==Mode::Recording||m_mode==Mode::Searching){
        if(m_step%60==0)m_recorder.sample(sample);
    }else{
        if(auto error=m_playback.check(sample,0.5))throw std::runtime_error("Рассинхронизация: "+*error);
    }
    if(m_mode==Mode::Recording){
        auto queued=std::move(m_buttons);m_buttons.clear();
        for(auto e:queued){e.step=m_step;apply(e);}
    }else if(m_mode==Mode::Playback){
        for(auto const& e:m_playback.eventsAt(m_step))apply(e);
    }else{
        auto input=m_search.desired(m_step,observation());
        // Retry prefixes can override the forecast. Pulse and orb state must
        // follow the input actually sent to the game, not the recommendation.
        m_planner.applied(input);
        for(int p=0;p<2;++p)for(int b=0;b<3;++b)
            if(input[p][b]!=m_held[p][b])apply({m_step,uint8_t(p+1),uint8_t(b+1),input[p][b]});
    }
    ++m_step;
}
void Session::afterUpdate(){
    if(!active()||m_preparingSearch)return;
    // EndPortalObject sets this flag only when the live player really reaches the end.
    // Stop gameplay input before the separately scheduled cocos end animation.
    if(m_layer->m_levelEndAnimationStarted)m_completed=true;
    if(m_mode==Mode::Playback && m_step>=m_macro->endStep){
        if(m_step!=m_macro->endStep){fail("Рассинхронизация: пропущен конец макроса");return;}
        for(auto const& e:m_playback.terminalEvents(snapshot(),0.5)){
            if(e.down){fail("Некорректное нажатие после конца макроса");return;}
            apply(e);
        }
        if(!m_macro->completed){finish(false);m_message="Воспроизведение неполной записи закончено";return;}
        if(!m_completed){fail("Рассинхронизация: макрос закончился, уровень не завершён");return;}
    }
    if(m_completed){
        if(m_mode==Mode::Searching){
            m_search.finishAttempt(true);finish(true);m_verifying=true;
            m_pending=Command::Play;m_message="Найдено; ожидается проверочное воспроизведение";
        }else if(m_mode==Mode::Playback){
            if(!m_macro->completed||m_step!=m_macro->endStep){fail("Рассинхронизация: завершение на другом шаге");return;}
            bool verified=m_verifying;finish(true);m_verifying=false;
            if(verified){
                auto name="solution-"+std::to_string(m_macro->meta.levelId)+"-"+m_macro->meta.levelHash.substr(0,8);
                save(name);m_message="Готово: "+name+".json; проверено воспроизведение";
            }
            else m_message="Макрос воспроизведён до завершения";
        }else finish(true);
        return;
    }
    if(m_mode==Mode::Searching){
        auto o=observation();
        if(m_advanced){m_search.observe(m_step,o);m_advanced=false;}
        if(m_death)m_search.finishAttempt(false);
        if(!m_search.running()){
            auto reason=m_search.status();finish(false);m_message=reason;
        }else if(m_search.needsRestart()){
            releaseAll();m_resetRequested=true;
        }
    }else if(m_death){
        if(m_mode==Mode::Playback)fail("Рассинхронизация: игрок погиб до конца макроса");
        else finish(false);
    }
}
void Session::died(){if(active())m_death=true;}
void Session::completed(){if(active())m_completed=true;}
void Session::finish(bool complete){
    if(m_mode==Mode::Recording||m_mode==Mode::Searching){
        if(m_recorder.active()){
            auto const& samples=m_recorder.macro().samples;
            if(samples.empty()||samples.back().step<m_step)m_recorder.sample(snapshot());
            m_recorder.finish(m_step,complete);
        }
        // Failed search attempts must not overwrite a previously loaded/recorded macro.
        if(m_mode==Mode::Recording||complete){m_macro=m_recorder.macro();m_macroName.clear();}
    }
    m_playback.stop();m_mode=Mode::Idle;releaseAll();m_accumulator=0;m_resetRequested=false;m_preparingSearch=false;
    m_message=complete?"Уровень завершён. F6: воспроизвести или выйти":"Запись остановлена";
}
void Session::fail(std::string const& message){
    try{if(active())finish(false);}catch(std::exception const& error){
        log::warn("Macro Lab could not finalize recording: {}",error.what());m_mode=Mode::Idle;
    }
    m_search.stop();m_playback.stop();m_verifying=false;
    m_preparingSearch=false;m_analyzer.clear();m_planner.reset();
    m_pending.reset();m_resetRequested=false;releaseAll();m_message=message;
    log::warn("Macro Lab: {}",message);
}
std::string Session::hudStatus()const {
    static char const* labels[]={"Ожидание","Запись","Повтор","Поиск"};
    std::ostringstream s;
    s<<(m_preparingSearch?"Анализ":m_verifying?"Проверка макроса":labels[int(m_mode)])<<" | попытка "<<m_attempt;
    if(m_layer)s<<" | "<<std::fixed<<std::setprecision(1)<<m_layer->getCurrentPercent()<<"%";
    s<<"\n"<<(m_macro?"Макрос: "+std::to_string(m_macro->events.size())+" событий":"Макрос отсутствует");
    if(quarantined())s<<" | офлайн";
    if(m_preparingSearch)s<<"\n"<<m_analyzer.status();
    else if(m_mode==Mode::Searching)s<<"\n"<<m_search.status()<<"\n"<<m_planner.status();
    if(!m_macroName.empty())s<<"\n"<<m_macroName<<".json";
    if(m_mode==Mode::Idle)s<<"\n"<<m_message;
    return s.str();
}
std::string Session::status()const {
    static char const* labels[]={"Ожидание","Запись","Воспроизведение","Поиск"};
    std::ostringstream s;
    s<<(m_preparingSearch?"Анализ":m_verifying?"Проверка макроса":labels[int(m_mode)])<<" | попытка "<<m_attempt<<" | шаг "<<m_step;
    if(m_layer)s<<" | "<<std::fixed<<std::setprecision(1)<<m_layer->getCurrentPercent()<<"%";
    if(m_macro)s<<"\nМакрос: "<<m_macro->events.size()<<" событий, "<<(m_macro->completed?"полный":"неполный");
    else s<<"\nМакрос отсутствует";
    if(m_preparingSearch)s<<"\n"<<m_analyzer.status();
    else if(m_mode==Mode::Searching)s<<"\n"<<m_search.status()<<"\n"<<m_planner.status();
    else s<<"\n"<<m_message;
    if(quarantined())s<<"\nРекорды и награды заблокированы до выхода";
    return s.str();
}
std::filesystem::path Session::directory()const{return Mod::get()->getSaveDir()/"macros";}
std::vector<std::string> Session::macros(){requireThread();return storage().list();}
void Session::save(std::string const& name){
    requireThread();if(active())throw std::runtime_error("Сначала остановите запись или поиск");
    if(!m_macro)throw std::runtime_error("Нет макроса для сохранения");storage().save(name,*m_macro);m_macroName=name;m_message="Сохранён: "+name+".json";
}
void Session::load(std::string const& name){
    requireThread();if(active())throw std::runtime_error("Сначала остановите текущую сессию");
    auto macro=storage().load(name);if(synchronizeCurrentLevel())validateCompatibility(macro.meta,metadata());
    m_macro=std::move(macro);m_macroName=name;m_message="Загружен: "+name;
}
void Session::erase(std::string const& name){requireThread();storage().erase(name);m_message="Удалён: "+name;}
void Session::importFile(std::string const& name){
    requireThread();storage().importFrom(Mod::get()->getSaveDir()/"import.json",name);m_message="Импортирован: "+name;
}
void Session::exportFile(std::string const& name){
    requireThread();storage().exportTo(name,Mod::get()->getSaveDir()/"export.json");m_message="Экспортирован: export.json";
}
void Session::stopNow(){requireThread();start(Command::Stop);}
void Session::exitLevel(){
    requireThread();
    if(!synchronizeCurrentLevel())throw std::runtime_error("Уровень не открыт");
    start(Command::Stop);
    m_layer->onQuit();
}
void Session::openLevel(std::string const& id){
    requireThread();
    bool const opened=synchronizeCurrentLevel();
    if(id.empty()){if(!opened)throw std::runtime_error("Не найден запущенный уровень. Нажмите «Играть», затем откройте F6");m_message="Выбран текущий уровень";return;}
    if(id.size()>10||id.find_first_not_of("0123456789")!=std::string::npos||std::stoull(id)==0||std::stoull(id)>2147483647)
        throw std::runtime_error("ID должен быть положительным целым числом до 2147483647");
    if(opened)throw std::runtime_error("Для выбора по ID выйдите в главное меню. Пустое поле выбирает текущий уровень");
    auto search=GJSearchObject::create(SearchType::Search,id);
    if(!search)throw std::runtime_error("Не удалось создать игровой запрос уровня");
    auto scene=LevelBrowserLayer::scene(search);
    if(!scene)throw std::runtime_error("Не удалось открыть поиск уровня");
    CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(.5f,scene));
}
}
