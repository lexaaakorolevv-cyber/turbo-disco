#pragma once
#include <Geode/Geode.hpp>
#include "../core/Macro.hpp"
#include "../core/Recorder.hpp"
#include "../core/Playback.hpp"
#include "../core/Storage.hpp"
#include "../core/StepClock.hpp"
#include "../search/Search.hpp"
#include "../search/LocalPlanner.hpp"
#include "SceneAnalyzer.hpp"
#include <deque>
#include <optional>
#include <memory>
namespace gdm {
enum class Mode { Idle, Recording, Playback, Searching };
enum class Command { Record, Play, Search, Stop };
enum class SearchPreset { Quick, Balanced, Precise };
class Session final {
public:
    static Session& get();
    void attach(PlayLayer* layer);
    void detach(PlayLayer* layer);
    void request(Command command);
    void requestStop();
    void setSearchPreset(SearchPreset);
    SearchPreset searchPreset() const;
    std::string hudStatus() const;
    void beginFrame();
    void beforeCommands(GJBaseGameLayer* layer, float dt, bool halfTick);
    void pauseInputs();
    void afterUpdate();
    bool captureButton(GJBaseGameLayer*, bool down, int button, bool player2);
    void didReset();
    void died();
    void completed();
    bool controlled(GJBaseGameLayer*) const;
    bool automated() const;
    bool quarantined() const;
    bool blockedLevel(GJGameLevel*) const;
    bool active() const;
    bool preparingSearch() const;
    std::string macroName() const;
    bool injecting() const;
    cocos2d::CCDictionary* originalPendingCoins() const;
    std::string status() const;
    void save(std::string const& name);
    void load(std::string const& name);
    void erase(std::string const& name);
    void importFile(std::string const& name);
    void exportFile(std::string const& name);
    std::vector<std::string> macros();
    std::filesystem::path directory() const;
    void openLevel(std::string const& id);
    void exitLevel();
    void stopNow();
    double& accumulator();
    void fail(std::string const& message);
private:
    Session();
    Storage& storage();
    Metadata metadata() const;
    Sample snapshot() const;
    Observation observation();
    void start(Command);
    void reset();
    void apply(Event const&);
    void releaseAll();
    void finish(bool complete);
    void clearTransient();
    SearchConfig searchConfig() const;
    PlayLayer* m_layer = nullptr;
    Mode m_mode = Mode::Idle;
    bool m_quarantine=false, m_injecting=false, m_resetting=false, m_death=false;
    bool m_completed=false, m_resetRequested=false;
    uint64_t m_step=0;
    double m_accumulator=0;
    uint64_t m_attempt=0;
    std::optional<Command> m_pending;
    std::deque<Event> m_buttons;
    std::array<std::array<bool,3>,2> m_held{};
    std::string m_message="Готово";
    Recorder m_recorder;
    Playback m_playback;
    Search m_search;
    SceneAnalyzer m_analyzer;
    LocalPlanner m_planner;
    bool m_preparingSearch = false;
    uint64_t m_plannedStep = std::numeric_limits<uint64_t>::max();
    Input m_planned{};
    std::string m_macroName;
    std::optional<Macro> m_macro;
    std::unique_ptr<Storage> m_storage;
    GJGameLevel* m_original=nullptr;
    GJGameLevel* m_private=nullptr;
    bool m_verifying=false;
    StepClock m_clock;
    SearchPreset m_preset=SearchPreset::Balanced;
    bool m_advanced=false;
    bool m_pauseNoted=false;
    cocos2d::CCDictionary* m_originalPendingCoins=nullptr;
    cocos2d::CCDictionary* m_privatePendingCoins=nullptr;
};
}
