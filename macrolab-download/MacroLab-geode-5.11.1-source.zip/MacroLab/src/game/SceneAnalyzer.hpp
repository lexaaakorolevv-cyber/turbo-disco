#pragma once

#include <Geode/Geode.hpp>
#include "../search/Geometry.hpp"
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace gdm {

// Native objects never leave this game-thread adapter. The search sees value
// snapshots only; native collision/trigger processing remains the final oracle.
class SceneAnalyzer final {
public:
    void begin(GJBaseGameLayer*);
    bool advance(size_t objectBudget = 1024);
    bool ready() const;
    void resetMotion();
    void clear();
    float progress() const;
    size_t relevantObjects() const;
    std::array<PlayerScene, 2> sample(GJBaseGameLayer*, uint64_t step);
    std::string status() const;

private:
    struct Entry {
        geode::Ref<GameObject> object;
        FeatureKind kind;
        uint32_t mechanic;
        WorldRect initial;
    };
    struct Motion {
        PlayerObject* player = nullptr;
        uint32_t identity = 0;
        uint64_t step = 0;
        double x = 0, y = 0, previousX = 0, previousY = 0;
        double dx = 0, dy = 0;
        bool initialized = false, previousValid = false, valid = false;
        bool floorSeeded = false, floorTrusted = false;
        double floorY = 0;
        uint32_t floorMode = 0;
    };
    void requireThread();
    static std::optional<FeatureKind> classify(GameObject*);
    static std::optional<WorldRect> bounds(GameObject*);
    static uint32_t identity(PlayerObject*);
    void add(GameObject*);
    void updateMotion(Motion&, PlayerObject*, uint64_t, PlayerScene&);

    GJBaseGameLayer* m_layer = nullptr;
    geode::Ref<cocos2d::CCArray> m_source;
    size_t m_total = 0, m_scanned = 0, m_invalid = 0;
    std::vector<Entry> m_entries;
    std::unordered_map<GameObject*, size_t> m_lookup;
    std::unordered_map<int64_t, std::vector<size_t>> m_cells;
    std::vector<size_t> m_wide;
    std::array<Motion, 2> m_motion{};
    std::thread::id m_gameThread{};
};

} // namespace gdm
