#include "SceneAnalyzer.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <unordered_set>

namespace gdm {
namespace {
constexpr size_t MaxObjects = 2'000'000;
constexpr size_t MaxRelevant = 100'000;
constexpr size_t MaxCandidates = 4096;
constexpr size_t MaxFeatures = 96;
constexpr size_t MaxMoving = 1024;
constexpr double CellWidth = 120.0;

int64_t cell(double x) { return static_cast<int64_t>(std::floor(x / CellWidth)); }
bool overlaps(WorldRect const& a, WorldRect const& b) {
    return a.left <= b.right && a.right >= b.left && a.bottom <= b.top && a.top >= b.bottom;
}
bool supported(WorldRect const& player, WorldRect const& object, bool upsideDown) {
    if (object.right < player.left + 1 || object.left > player.right - 1) return false;
    double const foot = upsideDown ? player.top : player.bottom;
    double const surface = upsideDown ? object.bottom : object.top;
    return std::abs(foot - surface) <= 5.0;
}
double centerX(WorldRect const& r) { return (r.left + r.right) * .5; }
double centerY(WorldRect const& r) { return (r.bottom + r.top) * .5; }
bool noCollision(GameObject* object) {
    // m_isDisabled2 also means invisible, so it MUST NOT be used here.
    return object->m_isDisabled || object->m_isGroupDisabled || object->m_isGroupDisabledTemp
        || object->m_isNoTouch;
}
}

void SceneAnalyzer::requireThread() {
    auto const current = std::this_thread::get_id();
    if (m_gameThread == std::thread::id{}) m_gameThread = current;
    if (current != m_gameThread) throw std::runtime_error("Анализ уровня вызван вне игрового потока");
}

std::optional<FeatureKind> SceneAnalyzer::classify(GameObject* object) {
    if (!object) return std::nullopt;
    using T = GameObjectType;
    switch (object->m_objectType) {
        case T::Solid: case T::Breakable: return FeatureKind::Solid;
        case T::Slope: return object->m_slopeIsHazard ? FeatureKind::Hazard : FeatureKind::Slope;
        case T::Hazard: case T::AnimatedHazard: return FeatureKind::Hazard;
        case T::YellowJumpRing: case T::PinkJumpRing: case T::GravityRing:
        case T::GreenRing: case T::DropRing: case T::RedJumpRing: case T::CustomRing:
        case T::DashRing: case T::GravityDashRing: case T::SpiderOrb: case T::TeleportOrb:
            return FeatureKind::Orb;
        case T::YellowJumpPad: case T::PinkJumpPad: case T::GravityPad:
        case T::RedJumpPad: case T::SpiderPad: return FeatureKind::Pad;
        case T::InverseGravityPortal: case T::NormalGravityPortal: case T::GravityTogglePortal:
        case T::ShipPortal: case T::CubePortal: case T::BallPortal: case T::UfoPortal:
        case T::WavePortal: case T::RobotPortal: case T::SpiderPortal: case T::SwingPortal:
        case T::InverseMirrorPortal: case T::NormalMirrorPortal: case T::RegularSizePortal:
        case T::MiniSizePortal: case T::DualPortal: case T::SoloPortal: case T::TeleportPortal:
            return FeatureKind::Portal;
        default: break;
    }
    if (object->isSpeedObject()) return FeatureKind::Speed;
    return std::nullopt;
}

std::optional<WorldRect> SceneAnalyzer::bounds(GameObject* object) {
    if (!object) return std::nullopt;
    auto const r = object->getObjectRect(); // Native cache update on the game thread.
    WorldRect const result{r.getMinX(), r.getMinY(), r.getMaxX(), r.getMaxY()};
    if (!std::isfinite(result.left) || !std::isfinite(result.bottom)
        || !std::isfinite(result.right) || !std::isfinite(result.top)
        || result.left > result.right || result.bottom > result.top
        || std::abs(result.left) > 1e9 || std::abs(result.right) > 1e9
        || std::abs(result.bottom) > 1e9 || std::abs(result.top) > 1e9) return std::nullopt;
    return result;
}

uint32_t SceneAnalyzer::identity(PlayerObject* p) {
    uint32_t mode = 0;
    if (p->m_isShip) mode = 1;
    else if (p->m_isBall) mode = 2;
    else if (p->m_isBird) mode = 3;
    else if (p->m_isDart) mode = 4;
    else if (p->m_isRobot) mode = 5;
    else if (p->m_isSpider) mode = 6;
    else if (p->m_isSwing) mode = 7;
    return mode | (uint32_t(p->m_isUpsideDown) << 4) | (uint32_t(p->m_isSideways) << 5)
        | (uint32_t(p->m_isDashing) << 6) | (uint32_t(p->m_isPlatformer) << 7);
}

void SceneAnalyzer::clear() {
    requireThread();
    m_entries.clear(); m_lookup.clear(); m_cells.clear(); m_wide.clear();
    m_source = nullptr; m_layer = nullptr;
    m_total = m_scanned = m_invalid = 0; resetMotion();
}

void SceneAnalyzer::begin(GJBaseGameLayer* layer) {
    requireThread(); clear();
    if (!layer || !layer->m_objects) throw std::runtime_error("Не удалось прочитать объекты уровня");
    m_layer = layer; m_source = layer->m_objects; m_total = m_source->count();
    if (m_total > MaxObjects) {
        clear(); throw std::runtime_error("Уровень содержит более 2 000 000 объектов; автоматический анализ не поддерживается");
    }
    // Reserve only a modest amount: initialization itself must remain responsive.
    m_entries.reserve(std::min<size_t>(m_total, 4096));
}

void SceneAnalyzer::add(GameObject* object) {
    auto const kind = classify(object);
    if (!kind || m_lookup.contains(object)) return;
    auto const rect = bounds(object);
    if (!rect) { ++m_invalid; return; }
    if (m_entries.size() >= MaxRelevant)
        throw std::runtime_error("Уровень содержит более 100 000 игровых объектов; автоматический анализ не поддерживается");
    auto const index = m_entries.size();
    m_entries.push_back({geode::Ref<GameObject>(object), *kind, uint32_t(object->m_objectType), *rect});
    m_lookup.emplace(object, index);
    int64_t const left = cell(rect->left), right = cell(rect->right);
    if (right - left > 64) {
        m_wide.push_back(index);
    } else {
        for (auto x = left; x <= right; ++x) m_cells[x].push_back(index);
    }
}

bool SceneAnalyzer::advance(size_t objectBudget) {
    requireThread();
    if (!m_layer || !m_source) throw std::runtime_error("Анализ уровня не запущен");
    if (m_layer->m_objects != m_source.data() || m_source->count() != m_total)
        throw std::runtime_error("Объекты уровня изменились во время анализа; запустите поиск заново");
    size_t const count = std::min({objectBudget, size_t{8192}, m_total - m_scanned});
    size_t const end = m_scanned + count;
    for (; m_scanned < end; ++m_scanned)
        add(static_cast<GameObject*>(m_source->objectAtIndex(static_cast<unsigned int>(m_scanned))));
    return ready();
}

bool SceneAnalyzer::ready() const { return m_layer && m_source && m_scanned == m_total; }
float SceneAnalyzer::progress() const {
    return m_total ? float(100.0 * double(m_scanned) / double(m_total)) : (ready() ? 100.f : 0.f);
}
size_t SceneAnalyzer::relevantObjects() const { return m_entries.size(); }
void SceneAnalyzer::resetMotion() { requireThread(); m_motion = {}; }
std::string SceneAnalyzer::status() const {
    return "Анализ уровня: " + std::to_string(m_scanned) + "/" + std::to_string(m_total)
        + "; игровых объектов: " + std::to_string(m_entries.size())
        + (m_invalid ? "; некорректных hitbox: " + std::to_string(m_invalid) : "");
}

void SceneAnalyzer::updateMotion(Motion& motion, PlayerObject* player, uint64_t step, PlayerScene& scene) {
    auto const position = player->getPosition();
    auto const id = identity(player);
    bool const continuity = motion.initialized && motion.player == player && motion.identity == id
        && step >= motion.step && step - motion.step <= 1;
    if (!continuity) {
        motion.player = player; motion.identity = id; motion.step = step;
        motion.x = position.x; motion.y = position.y;
        motion.previousX = position.x; motion.previousY = position.y;
        motion.initialized = true; motion.previousValid = false; motion.valid = false;
        motion.dx = motion.dy = 0;
    } else {
        if (step > motion.step) {
            motion.previousX = motion.x; motion.previousY = motion.y;
            motion.previousValid = true; motion.step = step;
        }
        double const dx = double(position.x) - motion.previousX;
        double const dy = double(position.y) - motion.previousY;
        double const maxX = std::max(64.0, std::abs(motion.dx) * 12.0);
        double const maxY = std::max(64.0, std::abs(motion.dy) * 12.0);
        motion.x = position.x; motion.y = position.y;
        motion.valid = motion.previousValid && std::isfinite(dx) && std::isfinite(dy)
            && std::abs(dx) <= maxX && std::abs(dy) <= maxY;
        if (motion.valid) { motion.dx = dx; motion.dy = dy; }
        else {
            // A teleport/reverse/reset discontinuity is not a velocity estimate.
            motion.dx = motion.dy = 0; motion.previousValid = false;
            motion.previousX = motion.x; motion.previousY = motion.y;
        }
    }
    scene.dx = motion.dx; scene.dy = motion.dy; scene.motionValid = motion.valid;
    if (motion.floorSeeded && (id & 7u) != motion.floorMode) motion.floorTrusted = false;
}

std::array<PlayerScene, 2> SceneAnalyzer::sample(GJBaseGameLayer* layer, uint64_t step) {
    requireThread();
    if (!ready() || layer != m_layer) throw std::runtime_error("Геометрия уровня ещё не проанализирована");
    std::array<PlayerScene, 2> result;
    std::array<PlayerObject*, 2> const players{layer->m_player1, layer->m_player2};
    bool const dual = layer->m_gameState.m_isDualMode;
    for (size_t playerIndex = 0; playerIndex < players.size(); ++playerIndex) {
        auto player = players[playerIndex];
        if (!player || (playerIndex == 1 && !dual)) continue;
        auto const playerBounds = bounds(player);
        if (!playerBounds) throw std::runtime_error("Некорректное состояние hitbox игрока; поиск остановлен");
        auto& scene = result[playerIndex]; scene.player = *playerBounds;
        auto& motion = m_motion[playerIndex]; updateMotion(motion, player, step, scene);
        double const lookAhead = std::clamp(std::abs(scene.dx) * 180.0 + 180.0, 240.0, 720.0);
        // Include both horizontal directions for platformer/reverse and enough
        // vertical range for elevated platforms, flight corridors, and orbs.
        WorldRect const region{scene.player.left - lookAhead, scene.player.bottom - 420.0,
            scene.player.right + lookAhead, scene.player.top + 420.0};
        std::vector<GameObject*> candidates; candidates.reserve(512);
        std::unordered_set<GameObject*> seen; seen.reserve(512);
        auto append = [&](GameObject* object) {
            if (!object || !seen.insert(object).second) return;
            if (candidates.size() >= MaxCandidates) { scene.truncated = true; return; }
            candidates.push_back(object);
        };
        auto appendList = [&](cocos2d::CCArray* list, size_t limit) {
            if (!list) return;
            size_t const count = list->count();
            if (count > limit) scene.truncated = true;
            for (size_t i = 0; i < std::min(count, limit); ++i)
                append(static_cast<GameObject*>(list->objectAtIndex(static_cast<unsigned int>(i))));
        };
        // Prioritize currently touching orbs and native local broad phase.
        appendList(player->m_touchingRings, 64);
        auto appendNative = [&](gd::vector<GameObject*> const& list, int nativeCount) {
            size_t const count = std::min(list.size(), size_t(std::max(0, nativeCount)));
            if (count > 512) scene.truncated = true;
            for (size_t i = 0; i < std::min(count, size_t{512}); ++i) append(list[i]);
        };
        appendNative(layer->m_hazardCollisionObjects, layer->m_hazardCollisionObjectsCount);
        appendNative(layer->m_solidCollisionObjects, layer->m_solidCollisionObjectsCount);
        // A moving object may arrive from a different original cell. Native
        // moving entries are refreshed independently of the initial index.
        appendList(layer->m_objectsToMove, MaxMoving);
        for (auto index : m_wide) {
            append(m_entries[index].object.data());
            if (candidates.size() >= MaxCandidates) { scene.truncated = true; break; }
        }
        for (int64_t x = cell(region.left); x <= cell(region.right); ++x) {
            auto const found = m_cells.find(x);
            if (found == m_cells.end()) continue;
            for (auto index : found->second) {
                append(m_entries[index].object.data());
                if (candidates.size() >= MaxCandidates) { scene.truncated = true; break; }
            }
            if (candidates.size() >= MaxCandidates) break;
        }

        struct Ranked { SceneFeature feature; double rank; };
        std::vector<Ranked> features; features.reserve(candidates.size());
        bool hasFootSupport = false;
        double const playerX = centerX(scene.player), playerY = centerY(scene.player);
        for (auto object : candidates) {
            auto const kind = classify(object);
            if (!kind || noCollision(object)) continue;
            auto const rect = bounds(object);
            if (!rect || !overlaps(region, *rect)) continue;
            bool const solid = *kind == FeatureKind::Solid || *kind == FeatureKind::Slope;
            if (solid && supported(scene.player, *rect, player->m_isUpsideDown)) hasFootSupport = true;
            // Passable blocks are not unconditional barriers. Still count their
            // surface as support so they cannot manufacture an infinite floor.
            if (solid && object->m_isPassable) continue;
            if (*kind == FeatureKind::Orb && overlaps(scene.player, *rect)) scene.touchingOrb = true;
            double distance = std::hypot(centerX(*rect) - playerX, centerY(*rect) - playerY);
            if (*kind == FeatureKind::Orb) distance -= 120.0;
            else if (*kind == FeatureKind::Hazard || solid) distance -= 60.0;
            features.push_back({{*rect, *kind, uint32_t(object->m_objectType)}, distance});
        }
        std::stable_sort(features.begin(), features.end(), [](Ranked const& a, Ranked const& b) {
            return a.rank < b.rank;
        });
        if (features.size() > MaxFeatures) scene.truncated = true;
        scene.features.reserve(std::min(features.size(), MaxFeatures));
        for (size_t i = 0; i < std::min(features.size(), MaxFeatures); ++i)
            scene.features.push_back(features[i].feature);

        if (step == 0 && !motion.floorSeeded && player->m_isOnGround
            && !player->m_isUpsideDown && !player->m_isSideways && !scene.truncated && !hasFootSupport) {
            // Only native initial grounded contact without a level-object
            // support establishes the base plane. Elevated platforms do not.
            motion.floorSeeded = true; motion.floorTrusted = true;
            motion.floorY = scene.player.bottom; motion.floorMode = identity(player) & 7u;
        }
        scene.floorAvailable = motion.floorSeeded && motion.floorTrusted;
        scene.floorY = motion.floorY;
        // Absolute mode-dependent ceiling cannot be proved from these bindings.
        // Ceiling obstacles are represented by their actual solid hitboxes.
        scene.ceilingAvailable = false;
    }
    return result;
}

} // namespace gdm
