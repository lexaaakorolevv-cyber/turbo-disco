#include "Session.hpp"
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <cmath>
using namespace geode::prelude;
class $modify(MacroLabPhysics,GJBaseGameLayer){
    void update(float dt){
        auto& session=gdm::Session::get();
        if(!session.controlled(this)){GJBaseGameLayer::update(dt);return;}
        try{session.beginFrame();}catch(std::exception const& e){session.fail(e.what());}
        auto play=static_cast<PlayLayer*>(static_cast<GJBaseGameLayer*>(this));
        if(play->m_isPaused){session.pauseInputs();session.accumulator()=0;GJBaseGameLayer::update(dt);return;}
        if(!session.active()){GJBaseGameLayer::update(dt);return;}
        // Bounded work per rendered frame keeps the cocos scheduler / input responsive.
        // Never silently discard backlog: stop instead of producing an invalid macro.
        if(!std::isfinite(dt)||dt<0){session.fail("Некорректное время кадра");return;}
        session.accumulator()+=dt;
        if(session.accumulator()>.25){session.fail("Симуляция отстала более чем на 250 мс; сессия остановлена");return;}
        constexpr double tick=1.0/240.0;
        for(int i=0;i<8&&session.active()&&session.accumulator()+1e-9>=tick;++i){
            session.accumulator()-=tick;
            GJBaseGameLayer::update(float(tick));
            try{session.afterUpdate();}catch(std::exception const& e){session.fail(e.what());}
        }
    }
    void processCommands(float dt,bool halfTick,bool lastTick){
        auto& session=gdm::Session::get();
        GJBaseGameLayer::processCommands(dt,halfTick,lastTick);
        // Queue processing first captures manual events; inject on this same boundary.
        try{session.beforeCommands(this,dt,halfTick);}catch(std::exception const& e){session.fail(e.what());}
    }
    void handleButton(bool down,int button,bool player2){
        auto& session=gdm::Session::get();
        if(session.captureButton(this,down,button,player2))return;
        GJBaseGameLayer::handleButton(down,button,player2);
    }
};
class $modify(MacroLabPlay,PlayLayer){
    bool init(GJGameLevel* level,bool replay,bool dontCreate){
        if(!PlayLayer::init(level,replay,dontCreate))return false;
        gdm::Session::get().attach(this);return true;
    }
    void resetLevel(){
        auto& session=gdm::Session::get();
        if(session.controlled(this))session.didReset();
        PlayLayer::resetLevel();
    }
    void destroyPlayer(PlayerObject* player,GameObject* object){
        // The real collision handler always runs.
        PlayLayer::destroyPlayer(player,object);
        if(player->m_isDead&&gdm::Session::get().controlled(this))gdm::Session::get().died();
    }
    void levelComplete(){
        auto& session=gdm::Session::get();
        if(session.controlled(this)&&session.quarantined()){
            session.completed();
            // Actual engine end detection is the success signal. The native method
            // writes rewards/statistics and opens the ordinary completion UI.
            m_hasCompletedLevel=true;
            return;
        }
        PlayLayer::levelComplete();
    }
    void updateAttempts(){
        if(gdm::Session::get().controlled(this)&&gdm::Session::get().quarantined())return;
        PlayLayer::updateAttempts();
    }
    void commitJumps(){
        if(gdm::Session::get().controlled(this)&&gdm::Session::get().quarantined()){
            m_uncommittedJumps=0;return;
        }
        PlayLayer::commitJumps();
    }
    void onQuit(){
        auto& session=gdm::Session::get();
        if(session.controlled(this)){
            try{session.stopNow();}catch(std::exception const& e){session.fail(e.what());}
        }
        // Quarantine remains enabled throughout native onQuit and its statistics writes.
        PlayLayer::onQuit();
    }
    void onExit(){
        auto& session=gdm::Session::get();
        if(session.controlled(this)&&session.active()){
            try{session.stopNow();}catch(std::exception const& e){session.fail(e.what());}
        }
        PlayLayer::onExit();
        gdm::Session::get().detach(this);
    }
};
