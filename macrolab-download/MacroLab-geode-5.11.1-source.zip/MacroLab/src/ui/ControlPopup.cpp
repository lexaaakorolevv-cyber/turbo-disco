#include "ControlPopup.hpp"
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/binding/FLAlertLayer.hpp>
#include <Geode/binding/PauseLayer.hpp>
#include <Geode/cocos/text_input_node/CCIMEDispatcher.h>
#include <algorithm>
#include <stdexcept>

using namespace geode::prelude;

namespace gdm::ui {
namespace {

bool containsAlert(CCNode* node) {
    if (!node || !node->isVisible()) return false;
    if (typeinfo_cast<FLAlertLayer*>(node)) return true;
    if (auto children = node->getChildren()) {
        for (auto child : CCArrayExt<CCNode*>(children)) {
            if (containsAlert(child)) return true;
        }
    }
    return false;
}

CCLabelBMFont* label(char const* text, float x, float y, float scale, float width = 0.f) {
    auto path = fontPath();
    auto node = width > 0.f
        ? CCLabelBMFont::create(text, path.c_str(), width / scale, kCCTextAlignmentCenter)
        : CCLabelBMFont::create(text, path.c_str());
    if (!node) throw std::runtime_error("UI font could not be loaded");
    node->setScale(scale);
    node->setPosition({x, y});
    return node;
}

template <class Action>
void guarded(Action&& action) {
    try { action(); }
    catch (std::exception const& error) { showError(error.what()); }
}

}

std::string fontPath() {
    // A full filename avoids collisions with fonts belonging to other mods.
    return (Mod::get()->getResourcesDir() / "ui-font.fnt").string();
}

void showError(std::string const& message) {
    // Native alert labels do not contain Russian glyphs; retain its normal OK
    // button and touch/key handling, and draw the body with our bundled font.
    auto alert = FLAlertLayer::create(nullptr, "Macro Lab", " ", "OK", nullptr,
                                      410.f, false, 190.f, .8f);
    if (!alert) return;
    auto size = CCDirector::get()->getWinSize();
    auto path = fontPath();
    auto text = CCLabelBMFont::create(message.c_str(), path.c_str(), 760.f,
                                     kCCTextAlignmentCenter);
    if (text) {
        float scale = .46f;
        auto height = text->getContentSize().height;
        if (height * scale > 110.f) scale = 110.f / height;
        text->setScale(scale);
        text->setPosition(size / 2.f + CCPoint{0.f, 5.f});
        alert->m_mainLayer->addChild(text, 10);
    }
    alert->show();
}

bool hasModalInput() {
    return CCIMEDispatcher::sharedDispatcher()->hasDelegate()
        || containsAlert(CCDirector::get()->getRunningScene());
}

void showControls(PauseLayer* pause) {
    guarded([pause] {
        if (hasModalInput()) return;
        auto popup = ControlPopup::create(pause);
        if (!popup) throw std::runtime_error("Unable to create Macro Lab menu");
        popup->show();
    });
}

ControlPopup* ControlPopup::create(PauseLayer* pause) {
    auto popup = new ControlPopup();
    try {
        if (popup->init(pause)) {
            popup->autorelease();
            return popup;
        }
    } catch (...) {
        delete popup;
        throw;
    }
    delete popup;
    return nullptr;
}

bool ControlPopup::init(PauseLayer* pause) {
    if (!Popup::init(480.f, 358.f)) return false;
    m_pause = pause;
    m_noElasticity = true;
    auto path = fontPath();
    setTitle("Лаборатория макросов", path.c_str(), .63f, 17.f);

    auto version = label("GD 2.2081 | Geode 5.11.1 | 240 шагов/с", 240.f, 317.f, .32f);
    version->setColor({170, 200, 220});
    m_mainLayer->addChild(version);

    m_status = label("", 240.f, 286.f, .32f, 450.f);
    m_status->setColor({190, 230, 255});
    m_mainLayer->addChild(m_status);

    m_levelId = TextInput::create(200.f, "ID (пусто = текущий)", path);
    if (!m_levelId) return false;
    m_levelId->setCommonFilter(CommonFilter::Uint);
    m_levelId->setMaxCharCount(10);
    m_levelId->setPosition({125.f, 243.f});
    m_mainLayer->addChild(m_levelId);

    m_name = TextInput::create(430.f, "Имя макроса", path);
    if (!m_name) return false;
    m_name->setFilter("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-");
    m_name->setMaxCharCount(48);
    m_name->setString("macro");
    m_name->setPosition({240.f, 208.f});
    m_mainLayer->addChild(m_name);

    auto button = [this, &path](char const* caption, float x, float y,
                                int width, SEL_MenuHandler callback) {
        auto sprite = ButtonSprite::create(caption, width, true, path.c_str(),
                                           "GJ_button_04.png", 29.f, .44f);
        if (!sprite) throw std::runtime_error("Unable to create a menu button");
        auto item = CCMenuItemSpriteExtra::create(sprite, this, callback);
        if (!item) throw std::runtime_error("Unable to create a menu item");
        item->setPosition({x, y});
        m_buttonMenu->addChild(item);
        return item;
    };

    button("Выбрать уровень", 355.f, 243.f, 210, menu_selector(ControlPopup::onLevel));
    button("Записать", 86.f, 156.f, 137, menu_selector(ControlPopup::onRecord));
    button("Воспроизвести", 240.f, 156.f, 145, menu_selector(ControlPopup::onPlay));
    button("Остановить", 394.f, 156.f, 137, menu_selector(ControlPopup::onStop));
    button("Найти прохождение", 125.f, 120.f, 210, menu_selector(ControlPopup::onSearch));
    m_presetButton = button("Поиск: обычный", 355.f, 120.f, 210,
                            menu_selector(ControlPopup::onPreset));
    m_presetSprite = static_cast<ButtonSprite*>(m_presetButton->getNormalImage());
    button("Сохранить", 86.f, 84.f, 137, menu_selector(ControlPopup::onSave));
    button("Загрузить", 240.f, 84.f, 145, menu_selector(ControlPopup::onLoad));
    button("Удалить", 394.f, 84.f, 137, menu_selector(ControlPopup::onErase));
    button("Импорт", 86.f, 48.f, 137, menu_selector(ControlPopup::onImport));
    button("Экспорт", 240.f, 48.f, 145, menu_selector(ControlPopup::onExport));
    button("Выйти из уровня", 394.f, 48.f, 137, menu_selector(ControlPopup::onExit));

    m_names = label("", 240.f, 24.f, .28f, 450.f);
    m_names->setColor({200, 210, 220});
    m_mainLayer->addChild(m_names);
    m_notice = label("Выберите уровень или откройте его в игре", 240.f, 182.f, .28f, 450.f);
    m_notice->setColor({210, 230, 195});
    m_mainLayer->addChild(m_notice);
    auto hotkeys = label("F6 меню | F7 запись | F8 повтор | F9 стоп | F10 поиск", 240.f, 8.f, .28f);
    m_mainLayer->addChild(hotkeys);

    // Retain the full layout on short/wide screens while keeping all controls
    // inside the window. Popup::init centres m_mainLayer in the window.
    auto size = CCDirector::get()->getWinSize();
    m_mainLayer->setScale(std::min({1.f, (size.width - 20.f) / 480.f,
                                    (size.height - 14.f) / 358.f}));

    refresh(0.f);
    refreshNames();
    schedule(schedule_selector(ControlPopup::refresh), .25f);
    return true;
}

void ControlPopup::refresh(float) {
    // Cocos scheduling runs on the game thread, including when PauseLayer is open.
    guarded([this] {
        m_status->setString(Session::get().status().c_str());
        auto height = m_status->getContentSize().height;
        m_status->setScale(height > 0.f ? std::min(.32f, 47.f / height) : .32f);
        char const* preset = "Поиск: обычный";
        switch (Session::get().searchPreset()) {
            case SearchPreset::Quick: preset = "Поиск: быстрый"; break;
            case SearchPreset::Balanced: break;
            case SearchPreset::Precise: preset = "Поиск: точный"; break;
        }
        m_presetSprite->setString(preset);
        m_presetButton->updateSprite();
        bool enabled = !Session::get().active();
        m_presetButton->setEnabled(enabled);
        m_presetSprite->setColor(enabled ? ccColor3B{255, 255, 255} : ccColor3B{150, 150, 150});
    });
}

void ControlPopup::refreshNames() {
    auto names = Session::get().macros();
    std::string text = "Сохранённые: ";
    if (names.empty()) text += "нет";
    // Keep this summary on one line; loading by name remains available for all
    // files. Long summaries otherwise collide with the last row of buttons.
    size_t count = std::min(names.size(), size_t{2});
    for (size_t index = 0; index < count; ++index) {
        if (index) text += ", ";
        auto const& name = names[index];
        text += name.size() > 20 ? name.substr(0, 17) + "..." : name;
    }
    if (names.size() > count) text += " (+" + std::to_string(names.size() - count) + ")";
    m_names->setString(text.c_str());
}

void ControlPopup::onClose(CCObject* sender) {
    if (m_closed) return;
    m_closed = true;
    if (m_levelId) m_levelId->defocus();
    if (m_name) m_name->defocus();
    Popup::onClose(sender);
}

void ControlPopup::keyDown(enumKeyCodes key, double timestamp) {
    if (key == KEY_F6 && !CCIMEDispatcher::sharedDispatcher()->hasDelegate()) {
        onClose(nullptr);
        return;
    }
    Popup::keyDown(key, timestamp);
}

void ControlPopup::closeAndResume() {
    // Keep both nodes alive across removeFromParent and the native resume call.
    Ref<ControlPopup> alive(this);
    auto pause = m_pause.lock();
    onClose(nullptr);
    if (pause && pause->getParent()) pause->onResume(nullptr);
}

void ControlPopup::queue(Command command) {
    guarded([this, command] {
        Session::get().request(command);
        closeAndResume();
    });
}

void ControlPopup::onLevel(CCObject*) {
    guarded([this] {
        auto id = m_levelId->getString();
        if (id.empty()) {
            Session::get().openLevel(id);
            m_notice->setString("Выбран текущий открытый уровень");
            return;
        }
        // The actual level lookup is the game's standard online browser; it
        // supplies its normal download/error UI. The user then opens PlayLayer.
        Ref<ControlPopup> alive(this);
        Session::get().openLevel(id);
        onClose(nullptr);
    });
}

void ControlPopup::onSearch(CCObject*) { queue(Command::Search); }
void ControlPopup::onPreset(CCObject*) {
    guarded([this] {
        auto current = Session::get().searchPreset();
        auto next = current == SearchPreset::Quick ? SearchPreset::Balanced
                  : current == SearchPreset::Balanced ? SearchPreset::Precise
                  : SearchPreset::Quick;
        Session::get().setSearchPreset(next);
        m_notice->setString("Профиль поиска изменён");
        refresh(0.f);
    });
}
void ControlPopup::onRecord(CCObject*) { queue(Command::Record); }
void ControlPopup::onPlay(CCObject*) { queue(Command::Play); }
void ControlPopup::onStop(CCObject*) {
    guarded([this] {
        Session::get().requestStop();
        m_notice->setString("Остановлено; макрос можно сохранить");
        refresh(0.f);
    });
}

void ControlPopup::onSave(CCObject*) {
    guarded([this] {
        Session::get().save(m_name->getString());
        refreshNames();
        m_notice->setString("Макрос сохранён в JSON");
        refresh(0.f);
    });
}

void ControlPopup::onLoad(CCObject*) {
    guarded([this] {
        Session::get().load(m_name->getString());
        m_notice->setString("Макрос загружен; нажмите «Воспроизвести»");
        refresh(0.f);
    });
}

void ControlPopup::onErase(CCObject*) {
    guarded([this] {
        Session::get().erase(m_name->getString());
        refreshNames();
        m_notice->setString("Файл макроса удалён");
    });
}

void ControlPopup::onImport(CCObject*) {
    guarded([this] {
        Session::get().importFile(m_name->getString());
        refreshNames();
        m_notice->setString("Импортирован import.json из папки сохранений мода");
        refresh(0.f);
    });
}

void ControlPopup::onExport(CCObject*) {
    guarded([this] {
        Session::get().exportFile(m_name->getString());
        m_notice->setString("Экспорт: export.json в папке сохранений мода");
    });
}

void ControlPopup::onExit(CCObject*) {
    guarded([this] {
        Ref<ControlPopup> alive(this);
        // A quarantined completion has no native end screen or pause menu.
        // Exit through PlayLayer's normal quit path without resuming a pause
        // layer that is about to be removed together with the game scene.
        onClose(nullptr);
        Session::get().exitLevel();
    });
}

}
