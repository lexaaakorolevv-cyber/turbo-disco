#pragma once

#include <Geode/Geode.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>
#include "../game/Session.hpp"

namespace gdm::ui {

// These functions are called exclusively by Cocos callbacks on the game thread.
std::string fontPath();
void showError(std::string const& message);
bool hasModalInput();
void showControls(PauseLayer* pause = nullptr);

class ControlPopup final : public geode::Popup {
public:
    static ControlPopup* create(PauseLayer* pause = nullptr);

protected:
    bool init(PauseLayer*);
    void keyDown(cocos2d::enumKeyCodes, double timestamp) override;
    void onClose(cocos2d::CCObject*) override;

private:
    geode::WeakRef<PauseLayer> m_pause;
    geode::TextInput* m_levelId = nullptr;
    geode::TextInput* m_name = nullptr;
    cocos2d::CCLabelBMFont* m_status = nullptr;
    cocos2d::CCLabelBMFont* m_names = nullptr;
    cocos2d::CCLabelBMFont* m_notice = nullptr;
    ButtonSprite* m_presetSprite = nullptr;
    CCMenuItemSpriteExtra* m_presetButton = nullptr;
    bool m_closed = false;

    void refresh(float);
    void refreshNames();
    void closeAndResume();
    void queue(Command);
    void onLevel(cocos2d::CCObject*);
    void onSearch(cocos2d::CCObject*);
    void onPreset(cocos2d::CCObject*);
    void onRecord(cocos2d::CCObject*);
    void onPlay(cocos2d::CCObject*);
    void onStop(cocos2d::CCObject*);
    void onSave(cocos2d::CCObject*);
    void onLoad(cocos2d::CCObject*);
    void onErase(cocos2d::CCObject*);
    void onImport(cocos2d::CCObject*);
    void onExport(cocos2d::CCObject*);
    void onExit(cocos2d::CCObject*);
};

}
