#include "ControlPopup.hpp"
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/UILayer.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <algorithm>
#include <optional>

using namespace geode::prelude;

namespace {
// Keys and signatures below match the pinned Geometry Dash 2.2081 bindings.
std::optional<gdm::Command> commandFor(enumKeyCodes key) {
    switch (key) {
        case KEY_F7: return gdm::Command::Record;
        case KEY_F8: return gdm::Command::Play;
        case KEY_F10: return gdm::Command::Search;
        default: return std::nullopt;
    }
}

CCMenuItemSpriteExtra* menuButton(CCObject* target, SEL_MenuHandler callback) {
    try {
        auto path = gdm::ui::fontPath();
        auto sprite = ButtonSprite::create("Автомакрос", 92, true, path.c_str(),
                                           "GJ_button_04.png", 28.f, .46f);
        if (!sprite) return nullptr;
        return CCMenuItemSpriteExtra::create(sprite, target, callback);
    } catch (std::exception const& error) {
        log::error("Macro Lab menu: {}", error.what());
        // F6 still opens the error dialog after the scene is initialized.
        return nullptr;
    }
}
}

// The dispatcher sees F9 before a modal or text input receives its event.
// Only this stop key is intercepted globally: other hotkeys retain their normal
// focus rules. The real GD 2.2081 export takes a timestamp as its fourth argument.
class $modify(MacroLabKeyboard, CCKeyboardDispatcher) {
    bool dispatchKeyboardMSG(enumKeyCodes key, bool down, bool repeat, double timestamp) {
        if (key == KEY_F9) {
            if (down && !repeat) {
                try { gdm::Session::get().requestStop(); }
                catch (std::exception const& error) { gdm::ui::showError(error.what()); }
            }
            return true;
        }
        return CCKeyboardDispatcher::dispatchKeyboardMSG(key, down, repeat, timestamp);
    }
};

class $modify(MacroLabMenu, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        if (auto button = menuButton(this, menu_selector(MacroLabMenu::onMacros))) {
            auto size = CCDirector::get()->getWinSize();
            button->setPosition({size.width - 61.f, size.height - 28.f});
            menu->addChild(button);
            addChild(menu, 100);
        }
        return true;
    }

    void keyDown(enumKeyCodes key, double timestamp) {
        if (key == KEY_F6 && !gdm::ui::hasModalInput()) {
            gdm::ui::showControls();
            return;
        }
        MenuLayer::keyDown(key, timestamp);
    }

    void onMacros(CCObject*) { gdm::ui::showControls(); }
};

class $modify(MacroLabPause, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        gdm::Session::get().pauseInputs();
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        if (auto button = menuButton(this, menu_selector(MacroLabPause::onMacros))) {
            auto size = CCDirector::get()->getWinSize();
            button->setPosition({size.width - 64.f, size.height - 28.f});
            menu->addChild(button);
            addChild(menu, 100);
        }
    }

    void keyDown(enumKeyCodes key, double timestamp) {
        if (key == KEY_F6 && !gdm::ui::hasModalInput()) {
            gdm::ui::showControls(this);
            return;
        }
        PauseLayer::keyDown(key, timestamp);
    }

    void onMacros(CCObject*) { gdm::ui::showControls(this); }
};

class $modify(MacroLabUI, UILayer) {
    struct Fields {
        CCLabelBMFont* status = nullptr;
    };

    bool init(GJBaseGameLayer* layer) {
        if (!UILayer::init(layer)) return false;
        std::string path;
        try { path = gdm::ui::fontPath(); }
        catch (std::exception const& error) {
            log::error("Macro Lab HUD: {}", error.what());
            return true;
        }
        auto size = CCDirector::get()->getWinSize();
        auto width = std::min(400.f, size.width - 30.f);
        auto status = CCLabelBMFont::create("", path.c_str(),
                                           width / .32f,
                                           kCCTextAlignmentLeft);
        if (status) {
            status->setAnchorPoint({0.f, 1.f});
            status->setPosition({15.f, size.height - 36.f});
            status->setScale(.32f);
            status->setColor({180, 225, 255});
            addChild(status, 100);
            m_fields->status = status;
            schedule(schedule_selector(MacroLabUI::refreshStatus), .25f);
        }
        return true;
    }

    void refreshStatus(float) {
        if (!m_fields->status) return;
        try {
            m_fields->status->setString(gdm::Session::get().hudStatus().c_str());
            // Analysis/search adds phase and best-progress lines. Keep the
            // overlay within its original compact area on smaller screens.
            auto height = m_fields->status->getContentSize().height;
            m_fields->status->setScale(height > 0.f ? std::min(.32f, 84.f / height) : .32f);
        } catch (std::exception const& error) {
            unschedule(schedule_selector(MacroLabUI::refreshStatus));
            gdm::ui::showError(error.what());
        }
    }

    void keyDown(enumKeyCodes key, double timestamp) {
        // Text entry and modal windows retain their own key handling.
        if (!gdm::ui::hasModalInput()) {
            if (key == KEY_F6) {
                gdm::ui::showControls();
                return;
            }
            if (auto command = commandFor(key)) {
                try { gdm::Session::get().request(*command); }
                catch (std::exception const& error) { gdm::ui::showError(error.what()); }
                return;
            }
        }
        UILayer::keyDown(key, timestamp);
    }
};
