#pragma once

#include "Macro.hpp"

#include <optional>

namespace gdm {

class Playback {
public:
    void start(Macro const& macro, Metadata const& current);
    std::vector<Event> eventsAt(std::uint64_t step);
    std::vector<Event> terminalEvents(Sample const& actual, double tolerance = 0.25);
    std::optional<std::string> check(Sample const& actual, double tolerance = 0.25);
    bool ended(std::uint64_t step) const noexcept;
    void stop() noexcept;
    bool active() const noexcept { return m_active; }

private:
    Macro m_macro;
    std::size_t m_eventIndex = 0;
    std::size_t m_sampleIndex = 0;
    std::optional<std::uint64_t> m_lastInputStep;
    std::optional<std::uint64_t> m_lastCheckStep;
    bool m_active = false;
};

} // namespace gdm
