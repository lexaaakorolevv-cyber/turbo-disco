#pragma once
#include <span>

namespace gdm {

// The game adapter supplies identities only after finding nodes in the active
// scene. This policy never dereferences a token or accesses a game object.
struct LevelCandidate {
    void const* token = nullptr;
    bool live = false;
    bool ready = false;
};

enum class BindingAction { Unavailable, Keep, Attach };

struct BindingDecision {
    BindingAction action = BindingAction::Unavailable;
    void const* token = nullptr;
};

inline BindingDecision resolveLevelBinding(
    void const* bound,
    void const* exiting,
    bool quarantined,
    std::span<LevelCandidate const> candidates,
    void const* preferred = nullptr
) {
    auto eligible = [exiting](LevelCandidate const& candidate) {
        return candidate.token && candidate.token != exiting
            && candidate.live && candidate.ready;
    };
    auto matching = [&](void const* token) -> void const* {
        if (!token) return nullptr;
        for (auto const& candidate : candidates)
            if (candidate.token == token && eligible(candidate)) return token;
        return nullptr;
    };

    auto selected = matching(preferred);
    if (!selected) selected = matching(bound);
    if (!selected) {
        for (auto const& candidate : candidates) {
            if (!eligible(candidate)) continue;
            selected = candidate.token;
            break;
        }
    }
    if (!selected) return {};
    // A repeated observation must preserve queued commands and active sessions.
    if (selected == bound) return {BindingAction::Keep, selected};
    // Old native onExit must restore isolated statistics before a new binding.
    if (quarantined) return {};
    return {BindingAction::Attach, selected};
}

} // namespace gdm
