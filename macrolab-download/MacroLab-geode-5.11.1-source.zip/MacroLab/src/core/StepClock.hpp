#pragma once
#include <cmath>
#include <cstdint>
#include <optional>
#include <stdexcept>

namespace gdm {
enum class TickBoundary { HalfTick, Resume, Duplicate, Advance };

// GD 2.2081 can split input processing into half ticks. Only full boundaries
// advance the macro. Observed half ticks may explain a native command-ID gap.
// This is an adapter policy, not a model of the game's hidden physics.
class StepClock {
public:
    void reset() noexcept { m_seen.reset(); m_full.reset(); m_half = false; }
    TickBoundary accept(uint64_t command, float dt, bool halfTick) {
        if (!std::isfinite(dt) || dt < 0) throw std::runtime_error("Invalid simulation delta");
        if (m_seen && command < *m_seen) throw std::runtime_error("Native command counter moved backwards");
        m_seen = command;
        if (halfTick) { m_half = true; return TickBoundary::HalfTick; }
        if (dt == 0) { m_half = true; return TickBoundary::Resume; }
        if (m_full && command == *m_full) return TickBoundary::Duplicate;
        if (m_full && command != *m_full + 1 && !m_half)
            throw std::runtime_error("Native full simulation step was skipped");
        m_full = command;
        m_half = false;
        return TickBoundary::Advance;
    }
private:
    std::optional<uint64_t> m_seen, m_full;
    bool m_half = false;
};
}
