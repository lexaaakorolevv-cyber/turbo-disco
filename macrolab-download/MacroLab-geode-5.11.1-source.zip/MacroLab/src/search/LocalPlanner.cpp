#include "LocalPlanner.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <sstream>
#include <utility>
#include <vector>

namespace gdm {
namespace {
constexpr double infinity = std::numeric_limits<double>::infinity();
constexpr size_t maximumFeatures = 256;

bool valid(WorldRect const& r) {
    return std::isfinite(r.left) && std::isfinite(r.right) &&
        std::isfinite(r.bottom) && std::isfinite(r.top) &&
        r.left < r.right && r.bottom < r.top;
}
bool blocking(FeatureKind kind) {
    return kind == FeatureKind::Solid || kind == FeatureKind::Hazard || kind == FeatureKind::Slope;
}
bool overlaps(double lo1, double hi1, double lo2, double hi2) {
    return lo1 < hi2 - 0.05 && hi1 > lo2 + 0.05;
}

struct View {
    WorldRect player;
    double up = 1, dx = 0, dy = 0, speed = 0, center = 0, foot = 0, head = 0;
    double lower = -infinity, upper = infinity;
    bool movingRight = true;

    double low(WorldRect const& r) const { return up > 0 ? r.bottom : -r.top; }
    double high(WorldRect const& r) const { return up > 0 ? r.top : -r.bottom; }
    double distance(WorldRect const& r) const {
        return movingRight ? r.left - player.right : player.left - r.right;
    }
    double farDistance(WorldRect const& r) const {
        return movingRight ? r.right - player.left : player.right - r.left;
    }
};

View view(PlayerScene const& scene, bool inverted, bool platformer) {
    View v;
    v.player = scene.player;
    v.up = inverted ? -1 : 1;
    // Startup prediction is deliberately approximate until the adapter has
    // measured a real full-tick displacement. Native velocity has other units.
    v.dx = scene.motionValid && std::isfinite(scene.dx) ? scene.dx : 1.4;
    v.dy = scene.motionValid && std::isfinite(scene.dy) ? scene.dy * v.up : 0;
    if (std::abs(v.dx) < 0.05 && platformer) v.dx = 1.0;
    v.movingRight = v.dx >= 0;
    v.speed = std::max(0.05, std::abs(v.dx));
    v.foot = v.low(v.player); v.head = v.high(v.player);
    v.center = (v.foot + v.head) * 0.5;
    if (!inverted) {
        if (scene.floorAvailable) v.lower = scene.floorY;
        if (scene.ceilingAvailable) v.upper = scene.ceilingY;
    } else {
        if (scene.ceilingAvailable) v.lower = -scene.ceilingY;
        if (scene.floorAvailable) v.upper = -scene.floorY;
    }
    return v;
}

bool clearCeiling(PlayerScene const& scene, View const& v, double impulse, double gravity) {
    // Check ceilings during the actual forward arc. A low ceiling already
    // passed must not forbid the jump after it. Ground surfaces are not ceilings.
    unsigned const horizon = unsigned(std::clamp(2 * impulse / gravity, 1.0, 120.0));
    double const halfHeight = (v.head - v.foot) * 0.5;
    size_t const count = std::min(scene.features.size(), maximumFeatures);
    for (unsigned t = 1; t <= horizon; ++t) {
        double const rise = impulse * t - 0.5 * gravity * double(t) * t;
        if (rise <= 0) break;
        double const head = v.head + rise;
        if (head > v.upper - 0.5) return false;
        double const left = v.player.left + v.dx * t, right = v.player.right + v.dx * t;
        for (size_t i = 0; i < count; ++i) {
            auto const& feature = scene.features[i];
            if (!blocking(feature.kind) || !valid(feature.bounds)) continue;
            double const lower = v.low(feature.bounds);
            if (lower < v.head - 0.5) continue;
            if (overlaps(left, right, feature.bounds.left, feature.bounds.right) &&
                head > lower + 0.5 && head - 2 * halfHeight < v.high(feature.bounds)) return false;
        }
    }
    return true;
}

bool imminentObstacle(PlayerScene const& scene, View const& v, double impulse, double gravity) {
    double earliest = infinity, required = 0;
    size_t const count = std::min(scene.features.size(), maximumFeatures);
    for (size_t i = 0; i < count; ++i) {
        auto const& feature = scene.features[i];
        if (!blocking(feature.kind) || !valid(feature.bounds)) continue;
        double const distance = v.distance(feature.bounds);
        if (distance < -(v.player.right - v.player.left) || distance > v.speed * 120) continue;
        // Objects wholly overhead, and solids flush with the feet, do not
        // obstruct walking. Hazard AABBs intentionally err on the safe side.
        double const top = v.high(feature.bounds), bottom = v.low(feature.bounds);
        if (top <= v.foot + 0.5 || bottom >= v.head - 0.5) continue;
        if (distance < earliest) {
            earliest = distance;
            required = std::max(0.0, top - v.foot + 3.0);
        }
    }
    if (!std::isfinite(earliest)) return false;
    double const discriminant = impulse * impulse - 2 * gravity * required;
    if (discriminant <= 0) return earliest <= v.speed * 12;
    double const riseTicks = (impulse - std::sqrt(discriminant)) / gravity;
    return earliest / v.speed <= riseTicks + 4.0;
}

bool imminentGap(PlayerScene const& scene, View const& v, double impulse, double gravity) {
    if (std::isfinite(v.lower) && std::abs(v.foot - v.lower) <= 3) return false;
    std::vector<std::pair<double, double>> intervals;
    intervals.reserve(std::min(scene.features.size(), maximumFeatures));
    size_t const count = std::min(scene.features.size(), maximumFeatures);
    for (size_t i = 0; i < count; ++i) {
        auto const& feature = scene.features[i];
        if ((feature.kind != FeatureKind::Solid && feature.kind != FeatureKind::Slope) ||
            !valid(feature.bounds) || std::abs(v.high(feature.bounds) - v.foot) > 4) continue;
        intervals.emplace_back(feature.bounds.left, feature.bounds.right);
    }
    if (intervals.empty()) return false;
    std::sort(intervals.begin(), intervals.end());
    std::vector<std::pair<double, double>> merged;
    for (auto const& interval : intervals) {
        if (!merged.empty() && interval.first <= merged.back().second + 0.5)
            merged.back().second = std::max(merged.back().second, interval.second);
        else merged.push_back(interval);
    }
    double const centerX = (v.player.left + v.player.right) * 0.5;
    for (size_t i = 0; i < merged.size(); ++i) {
        if (centerX < merged[i].first || centerX > merged[i].second) continue;
        double const edge = v.movingRight ? merged[i].second : merged[i].first;
        double const lead = v.movingRight ? edge - v.player.right : v.player.left - edge;
        if (lead > std::max(8.0, v.speed * 8)) return false;
        double gap = infinity;
        if (v.movingRight && i + 1 < merged.size()) gap = merged[i + 1].first - edge;
        if (!v.movingRight && i > 0) gap = edge - merged[i - 1].second;
        // Do not advertise arbitrary route finding. Only a visible landing
        // surface within the approximate jump range is chosen proactively.
        double const range = v.speed * 2 * impulse / gravity;
        return gap > 0.5 && gap < range - (v.player.right - v.player.left) * 0.5;
    }
    return false;
}

double corridorTarget(PlayerScene const& scene, View const& v, double anchor, uint32_t mode) {
    double const halfHeight = (v.head - v.foot) * 0.5;
    double const lower = std::isfinite(v.lower) ? v.lower + halfHeight + 2 : anchor - 180;
    double const upper = std::isfinite(v.upper) ? v.upper - halfHeight - 2 : anchor + 180;
    if (lower >= upper) return v.center;
    std::vector<std::pair<double, double>> forbidden;
    size_t const count = std::min(scene.features.size(), maximumFeatures);
    for (size_t i = 0; i < count; ++i) {
        auto const& feature = scene.features[i];
        if (!blocking(feature.kind) || !valid(feature.bounds)) continue;
        double const distance = v.distance(feature.bounds);
        // A ship needs time to accelerate and brake; a wave changes slope
        // immediately and can use a shorter local lookahead.
        double const lookahead = mode == 1 ? 48 : 24;
        if (distance > v.speed * lookahead || v.farDistance(feature.bounds) < 0) continue;
        double const lo = std::max(lower, v.low(feature.bounds) - halfHeight - 3);
        double const hi = std::min(upper, v.high(feature.bounds) + halfHeight + 3);
        if (lo < hi) forbidden.emplace_back(lo, hi);
    }
    std::sort(forbidden.begin(), forbidden.end());
    double best = v.center, bestCost = infinity, cursor = lower;
    auto consider = [&](double lo, double hi) {
        if (hi - lo < 2) return;
        // Stay near the established altitude in open space; when there are
        // blockers, the centre of their free interval adds useful clearance.
        double const target = forbidden.empty() ? std::clamp(anchor, lo, hi) : (lo + hi) * 0.5;
        double const cost = std::abs(target - v.center);
        if (cost < bestCost) { best = target; bestCost = cost; }
    };
    for (auto const& interval : forbidden) {
        consider(cursor, interval.first);
        cursor = std::max(cursor, interval.second);
    }
    consider(cursor, upper);
    return best;
}

double flightCost(PlayerScene const& scene, View const& v, bool press, uint32_t mode,
    double target, double gravity) {
    unsigned const horizon = mode == 1 ? 32 : 16;
    double center = v.center, velocity = v.dy, cost = 0;
    double const halfHeight = (v.head - v.foot) * 0.5;
    size_t const count = std::min(scene.features.size(), maximumFeatures);
    for (unsigned t = 1; t <= horizon; ++t) {
        if (mode == 4) velocity = (press ? 1 : -1) *
            std::max(v.speed, std::abs(v.dy));
        else velocity = std::clamp(velocity + (press ? 0.055 : -gravity * 0.65), -5.0, 5.0);
        center += velocity;
        double const left = v.player.left + v.dx * t, right = v.player.right + v.dx * t;
        double const low = center - halfHeight, high = center + halfHeight;
        bool collision = low < v.lower + 0.5 || high > v.upper - 0.5;
        for (size_t i = 0; i < count; ++i) {
            auto const& feature = scene.features[i];
            if (!blocking(feature.kind) || !valid(feature.bounds)) continue;
            if (overlaps(left, right, feature.bounds.left, feature.bounds.right) &&
                overlaps(low, high, v.low(feature.bounds), v.high(feature.bounds))) collision = true;
        }
        if (collision) cost += 10000.0 * (horizon + 1 - t);
    }
    return cost + std::abs(center - target) + (mode == 1 ? std::abs(velocity) * 2 : 0);
}
} // namespace

Input LocalPlanner::plan(Observation const& observation, std::array<PlayerScene, 2> const& scenes,
    bool platformer) {
    Input input{};
    m_features = 0; m_truncated = false;
    m_pending = {};
    unsigned const players = observation.dual ? 2 : 1;
    for (unsigned p = 0; p < players; ++p) {
        auto const& scene = scenes[p];
        auto& memory = m_players[p];
        bool const grounded = p ? observation.grounded2 : observation.grounded1;
        bool const inverted = p ? observation.upsideDown2 : observation.upsideDown1;
        uint32_t const mode = p ? observation.mode2 : observation.mode1;
        m_features += unsigned(std::min(scene.features.size(), maximumFeatures));
        m_truncated |= scene.truncated || scene.features.size() > maximumFeatures;
        if (platformer) input[p][2] = true;
        if (!valid(scene.player) || mode > 7) continue;
        m_pending[p] = {true, grounded, scene.touchingOrb, mode};
        View const v = view(scene, inverted, platformer);
        if (!memory.initialized || memory.mode != mode || memory.inverted != inverted) {
            memory = {};
            memory.initialized = true; memory.mode = mode; memory.inverted = inverted;
            memory.anchor = v.center; memory.previousGrounded = grounded;
        }
        if (scene.motionValid && mode == 0) {
            if (memory.previousGrounded && !grounded && v.dy > 0.4)
                memory.impulse = std::clamp(v.dy + memory.gravity * 0.5, 0.8, 8.0);
            if (!grounded && !memory.previousGrounded) {
                double const acceleration = memory.previousDy - v.dy;
                if (acceleration > 0.002 && acceleration < 0.2)
                    memory.gravity = memory.gravity * 0.85 + acceleration * 0.15;
            }
        }
        if (!grounded) memory.leftGround = true;
        if (grounded && memory.leftGround) {
            memory.groundJumpLatched = false; memory.leftGround = false;
        }
        if (memory.cooldown) --memory.cooldown;
        if (!scene.touchingOrb) memory.orbConsumed = false;
        bool press = false;
        if (scene.touchingOrb && !memory.orbConsumed && !memory.previousPressed) {
            // All orb variants receive a genuine rising edge. Their gravity,
            // dash and teleport effects are resolved exclusively by the game.
            press = true;
        } else if (scene.touchingOrb) {
            press = false;
        } else if (mode == 1 || mode == 4) {
            double const target = corridorTarget(scene, v, memory.anchor, mode);
            double const held = flightCost(scene, v, true, mode, target, memory.gravity);
            double const released = flightCost(scene, v, false, mode, target, memory.gravity);
            press = held < released || (std::abs(held - released) < 0.001 && v.dy < 0);
        } else if (mode == 0 || mode == 5) {
            if (mode == 5 && !grounded && memory.robotHold) {
                press = true;
            } else if (grounded && !memory.groundJumpLatched && !memory.previousPressed) {
                bool const needed = imminentObstacle(scene, v, memory.impulse, memory.gravity) ||
                    imminentGap(scene, v, memory.impulse, memory.gravity);
                press = needed && clearCeiling(scene, v, memory.impulse, memory.gravity);
            }
        } else if ((mode == 2 || mode == 6) && grounded && !memory.previousPressed && !memory.cooldown) {
            // A local obstacle/gap orders a gravity-flip edge; finding distant
            // alternating surfaces still relies on the bounded retry search.
            press = imminentObstacle(scene, v, 2.8, 0.06) || imminentGap(scene, v, 2.8, 0.06);
        } else if (mode == 3 && !memory.previousPressed && !memory.cooldown) {
            double const target = corridorTarget(scene, v, memory.anchor, mode);
            double const future = v.center + v.dy * 10 - memory.gravity * 50;
            press = (future < target - 10 || future - (v.head - v.foot) * 0.5 < v.lower + 5) &&
                v.head + 20 < v.upper;
        } else if (mode == 7 && !memory.previousPressed && !memory.cooldown) {
            double const target = corridorTarget(scene, v, memory.anchor, mode);
            press = (v.center - target) * v.dy > 0 && std::abs(v.center - target) > 18;
        }
        input[p][0] = press;
        memory.previousGrounded = grounded; memory.previousDy = v.dy;
    }
    return input;
}

void LocalPlanner::applied(Input const& actual) {
    for (unsigned p = 0; p < m_players.size(); ++p) {
        auto& pending = m_pending[p];
        if (!pending.ready) continue;
        auto& memory = m_players[p];
        bool const press = actual[p][0];
        bool const edge = press && !memory.previousPressed;
        if (pending.touchingOrb && edge) { memory.orbConsumed = true; memory.cooldown = 5; }
        if ((pending.mode == 0 || pending.mode == 5) && pending.grounded && press) {
            memory.groundJumpLatched = true;
            if (pending.mode == 5 && edge) memory.robotHold = 16;
        } else if (pending.mode == 5 && !pending.grounded && memory.robotHold) {
            if (press) --memory.robotHold;
            else memory.robotHold = 0;
        }
        if (edge && !pending.touchingOrb) {
            if (pending.mode == 2 || pending.mode == 6) memory.cooldown = 12;
            if (pending.mode == 3) memory.cooldown = 8;
            if (pending.mode == 7) memory.cooldown = 10;
        }
        memory.previousPressed = press;
        pending.ready = false;
    }
}

void LocalPlanner::reset() { m_players = {}; m_pending = {}; m_features = 0; m_truncated = false; }
std::string LocalPlanner::status() const {
    std::ostringstream result;
    result << "Локальный прогноз: " << m_features << " объектов; приближённая физика";
    if (m_truncated) result << "; геометрия ограничена";
    return result.str();
}
} // namespace gdm
