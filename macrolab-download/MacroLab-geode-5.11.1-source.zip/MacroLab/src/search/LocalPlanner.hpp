#pragma once

#include "Geometry.hpp"
#include "Search.hpp"

#include <array>
#include <string>

namespace gdm {

// Conservative local prediction orders real engine inputs. Its physics model
// is approximate; search and native replay, rather than this model, certify a run.
class LocalPlanner final {
public:
    Input plan(Observation const& observation, std::array<PlayerScene, 2> const& scenes,
        bool platformer);
    // Search can override recommendations while replaying a learned prefix.
    // Commit only the input actually passed to the native simulator.
    void applied(Input const& actual);
    void reset();
    std::string status() const;

private:
    struct PlayerMemory {
        bool initialized = false, previousGrounded = true, previousPressed = false;
        bool groundJumpLatched = false, leftGround = false, orbConsumed = false;
        bool inverted = false;
        uint32_t mode = 0;
        unsigned cooldown = 0, robotHold = 0;
        double anchor = 0, previousDy = 0, impulse = 2.8, gravity = 0.06;
    };
    std::array<PlayerMemory, 2> m_players{};
    struct PendingPlayer {
        bool ready = false, grounded = false, touchingOrb = false;
        uint32_t mode = 0;
    };
    std::array<PendingPlayer, 2> m_pending{};
    unsigned m_features = 0;
    bool m_truncated = false;
};

} // namespace gdm
