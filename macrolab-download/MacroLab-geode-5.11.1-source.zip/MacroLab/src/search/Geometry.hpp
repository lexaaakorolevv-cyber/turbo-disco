#pragma once

#include <cstdint>
#include <vector>

namespace gdm {

struct WorldRect {
    double left = 0, bottom = 0, right = 0, top = 0;
};

enum class FeatureKind { Solid, Hazard, Slope, Orb, Pad, Portal, Speed };

struct SceneFeature {
    WorldRect bounds;
    FeatureKind kind = FeatureKind::Solid;
    uint32_t mechanic = 0; // Audited native GameObjectType value, never an object ID.
};

// Temporary local geometry: not stored at every search boundary or in macros.
// Positions and displacement are in world units / actual full simulation tick.
struct PlayerScene {
    WorldRect player;
    std::vector<SceneFeature> features;
    double dx = 0, dy = 0;
    bool motionValid = false;
    bool floorAvailable = false, ceilingAvailable = false;
    double floorY = 0, ceilingY = 0;
    bool touchingOrb = false;
    bool truncated = false;
};

} // namespace gdm
