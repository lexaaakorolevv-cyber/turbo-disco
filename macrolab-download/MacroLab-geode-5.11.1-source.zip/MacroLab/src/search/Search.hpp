#pragma once

#include <array>
#include <cstdint>
#include <deque>
#include <limits>
#include <string>
#include <unordered_set>
#include <vector>

namespace gdm {

// [player 0..1][button 0..2]; buttons are jump, left, right respectively.
using Input = std::array<std::array<bool, 3>, 2>;

struct Observation {
    double x1 = 0, y1 = 0, vx1 = 0, vy1 = 0;
    double x2 = 0, y2 = 0, vx2 = 0, vy2 = 0;
    bool dead = false, grounded1 = false, grounded2 = false;
    // 0 cube, 1 ship, 2 ball, 3 UFO, 4 wave, 5 robot, 6 spider, 7 swing.
    uint32_t mode1 = 0, mode2 = 0;
    bool dual = false;
    float progress = 0;
    double nearestHazardX = std::numeric_limits<double>::infinity();
    double nearestHazardY = std::numeric_limits<double>::infinity();
    // Independently selected for P2; absent hints never borrow P1 geometry.
    double nearestHazardX2 = std::numeric_limits<double>::infinity();
    double nearestHazardY2 = std::numeric_limits<double>::infinity();
    bool upsideDown1 = false, upsideDown2 = false;
    // Validated game-thread scene analysis supplies independent preferred inputs.
    Input planned{};
    std::array<bool, 2> analyzed{};
};

struct SearchConfig {
    uint32_t maxAttempts = 128;
    uint64_t maxSteps = 240 * 180;
    uint32_t segmentSteps = 12;
    uint32_t beamWidth = 8;
    uint64_t seed = 0x47444d4143524full;
    uint64_t maxTotalSteps = 240 * 600;
};

enum class SearchOutcome {
    Idle, Searching, Found, Cancelled, Exhausted, AttemptLimit, StepLimit,
    Unsupported, InvalidConfiguration, ReplayMismatch, TotalStepLimit
};

// Incremental controller, with no engine objects, threads, state restores, or waits.
// Every candidate must run in the actual game from its normal level reset.
class Search final {
public:
    void start(bool platformer, bool dual, SearchConfig config = {});
    Input desired(uint64_t step, Observation const& observation);
    // step is the number of already simulated steps: desired(0), observe(1).
    void observe(uint64_t step, Observation const& observation);
    // Only the engine's real level-completion callback may pass completed=true.
    void finishAttempt(bool completed);
    bool needsRestart() const;
    void beginAttempt();
    bool running() const;
    void stop();

    uint32_t attempt() const;
    float bestProgress() const;
    SearchOutcome outcome() const;
    std::string status() const;
    // Full per-step input trace of the successful attempt; empty before success.
    std::vector<Input> const& solution() const;

private:
    struct Node {
        // Exact per-tick prefix: local prediction can include one-tick pulses.
        std::vector<Input> prefix;
        Observation end;
        double score = 0;
        uint64_t serial = 0;
        uint8_t rewindRange = 0;
    };
    struct Boundary { uint64_t step = 0; Observation observation; };
    std::vector<Input> actions(Observation const& observation) const;
    void expand(std::vector<Node> const& parents);
    void closeAttempt(bool survived);
    void pruneSurvivors();
    void advance();
    void terminate(SearchOutcome outcome);
    bool supported(Observation const& observation);
    double score(Observation const& observation, uint64_t steps) const;

    SearchConfig m_config{};
    SearchOutcome m_outcome = SearchOutcome::Idle;
    bool m_platformer = false, m_dual = false, m_attemptActive = false;
    bool m_budgetBlocked = false;
    uint32_t m_attempts = 0;
    uint64_t m_executed = 0, m_serial = 0, m_totalSteps = 0;
    float m_bestProgress = 0;
    std::deque<Node> m_pending;
    std::vector<Node> m_survivors;
    Node m_current;
    Observation m_last{};
    Input m_tailInput{};
    std::vector<Input> m_trace;
    std::vector<Input> m_solution;
    std::vector<Boundary> m_boundaries;
    std::unordered_set<std::string> m_visited;
};

} // namespace gdm
