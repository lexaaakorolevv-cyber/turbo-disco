#include "Search.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace gdm {
namespace {
using PlayerInput = std::array<bool, 3>;

uint64_t tieKey(uint64_t value) {
    // Deterministic tie-breaking lets the seed diversify equally scored beams.
    value += 0x9e3779b97f4a7c15ull;
    value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ull;
    value = (value ^ (value >> 27)) * 0x94d049bb133111ebull;
    return value ^ (value >> 31);
}

std::string prefixKey(std::vector<Input> const& prefix) {
    std::string key;
    key.reserve(prefix.size());
    for (auto const& input : prefix) {
        unsigned bits = 0;
        for (unsigned p = 0; p != 2; ++p)
            for (unsigned b = 0; b != 3; ++b)
                bits |= unsigned(input[p][b]) << (p * 3 + b);
        key.push_back(char(bits));
    }
    return key;
}

bool finitePlayer(double x, double y, double vx, double vy) {
    return std::isfinite(x) && std::isfinite(y) && std::isfinite(vx) && std::isfinite(vy);
}

bool nearHazard(Observation const& o, bool second) {
    double x = second ? o.x2 : o.x1, y = second ? o.y2 : o.y1;
    double hazardX = second ? o.nearestHazardX2 : o.nearestHazardX;
    double hazardY = second ? o.nearestHazardY2 : o.nearestHazardY;
    double const dx = hazardX - x;
    return dx >= -20 && dx <= 100 && std::abs(hazardY - y) <= 100;
}

bool preferJump(Observation const& o, bool second) {
    bool grounded = second ? o.grounded2 : o.grounded1;
    uint32_t mode = second ? o.mode2 : o.mode1;
    double vy = second ? o.vy2 : o.vy1;
    bool upsideDown = second ? o.upsideDown2 : o.upsideDown1;
    if (mode == 1 || mode == 3 || mode == 4 || mode == 7) {
        // Positive motion/distance along gravity means falling or a hazard
        // below the player. Holding has the opposite preference when inverted.
        double const gravityDirection = upsideDown ? 1.0 : -1.0;
        if (nearHazard(o, second)) {
            double hazardY = second ? o.nearestHazardY2 : o.nearestHazardY;
            double y = second ? o.y2 : o.y1;
            double const distanceAlongGravity = (hazardY - y) * gravityDirection;
            if (distanceAlongGravity > 2) return true;
            if (distanceAlongGravity < -2) return false;
        }
        return vy * gravityDirection > 1;
    }
    return grounded && nearHazard(o, second);
}

std::vector<PlayerInput> playerActions(bool platformer, Observation const& o, bool second) {
    // A preference only: all release/hold alternatives remain in the finite set.
    unsigned const player = second ? 1 : 0;
    bool const jumpFirst = o.analyzed[player] ? o.planned[player][0] : preferJump(o, second);
    PlayerInput idle{false, false, false}, jump{true, false, false};
    if (!platformer) return jumpFirst ? std::vector<PlayerInput>{jump, idle}
                                      : std::vector<PlayerInput>{idle, jump};
    PlayerInput right{false, false, true}, rightJump{true, false, true};
    PlayerInput left{false, true, false}, leftJump{true, true, false};
    std::vector<PlayerInput> result = jumpFirst ?
        std::vector<PlayerInput>{rightJump, right, leftJump, left, jump, idle} :
        std::vector<PlayerInput>{right, rightJump, left, leftJump, idle, jump};
    if (o.analyzed[player]) {
        auto const preferred = o.planned[player];
        if (!(preferred[1] && preferred[2])) {
            auto found = std::find(result.begin(), result.end(), preferred);
            if (found != result.end()) std::rotate(result.begin(), found, found + 1);
        }
    }
    return result;
}
} // namespace

void Search::start(bool platformer, bool dual, SearchConfig config) {
    m_config = config;
    m_platformer = platformer;
    m_dual = dual;
    m_outcome = SearchOutcome::Searching;
    m_attemptActive = false;
    m_budgetBlocked = false;
    m_attempts = 0;
    m_executed = m_serial = m_totalSteps = 0;
    m_bestProgress = 0;
    m_pending.clear();
    m_survivors.clear();
    m_current = {};
    m_last = {};
    m_tailInput = {};
    m_trace.clear();
    m_solution.clear();
    m_boundaries.clear();
    m_visited.clear();
    // Bounds also limit memory and work done at a single attempt boundary.
    if (config.maxAttempts == 0 || config.maxAttempts > 4096 ||
        config.maxSteps == 0 || config.maxSteps > 240ull * 600 ||
        config.segmentSteps == 0 || config.segmentSteps > 240 ||
        config.beamWidth == 0 || config.beamWidth > 32 ||
        config.maxTotalSteps == 0 || config.maxTotalSteps > 240ull * 3600) {
        terminate(SearchOutcome::InvalidConfiguration);
        return;
    }
    // First try a full baseline rollout; an empty/easy level takes one attempt.
    m_pending.push_back(Node{});
    m_visited.insert(std::string{});
}

std::vector<Input> Search::actions(Observation const& observation) const {
    auto first = playerActions(m_platformer, observation, false);
    auto second = playerActions(m_platformer, observation, true);
    if (!(m_dual || observation.dual)) second = {PlayerInput{}};
    std::vector<Input> result;
    result.reserve(first.size() * second.size());
    // Pair independently: neither player's button is copied into the other.
    for (auto const& a : first)
        for (auto const& b : second) result.push_back(Input{a, b});
    return result;
}

void Search::expand(std::vector<Node> const& parents) {
    m_budgetBlocked = false;
    // Round-robin branching gives each beam parent its preferred action before
    // one parent can consume the remaining attempt budget with all alternatives.
    std::vector<std::vector<Input>> choices;
    choices.reserve(parents.size());
    size_t count = 0;
    for (auto const& parent : parents) {
        choices.push_back(actions(parent.end));
        count = std::max(count, choices.back().size());
    }
    uint64_t const remainingSteps = m_config.maxTotalSteps - m_totalSteps;
    uint64_t reservedSteps = 0;
    uint32_t const remainingAttempts = m_config.maxAttempts - m_attempts;
    for (size_t branch = 0; branch < count; ++branch) {
        for (size_t i = 0; i < parents.size(); ++i) {
            if (m_pending.size() >= remainingAttempts) return;
            if (branch >= choices[i].size()) continue;
            // A candidate must replay the prefix and execute its new input.
            // Do not retain deep copies for work that cannot fit the budget.
            uint64_t const minimumSteps =
                uint64_t(parents[i].prefix.size()) + 1;
            if (minimumSteps > remainingSteps - reservedSteps) {
                m_budgetBlocked = true;
                continue;
            }
            Node candidate = parents[i];
            candidate.prefix.insert(candidate.prefix.end(), m_config.segmentSteps, choices[i][branch]);
            if (!m_visited.insert(prefixKey(candidate.prefix)).second) continue;
            reservedSteps += minimumSteps;
            candidate.serial = tieKey(m_serial++ ^ m_config.seed);
            m_pending.push_back(std::move(candidate));
        }
    }
}

void Search::beginAttempt() {
    if (!running() || m_attemptActive) return;
    if (m_attempts >= m_config.maxAttempts) {
        terminate(SearchOutcome::AttemptLimit);
        return;
    }
    if (m_pending.empty()) advance();
    if (!running() || m_pending.empty()) return;
    m_current = std::move(m_pending.front());
    m_pending.pop_front();
    ++m_attempts;
    m_attemptActive = true;
    m_executed = 0;
    m_last = {};
    m_tailInput = {};
    m_trace.clear();
    m_boundaries.clear();
}

bool Search::supported(Observation const& o) {
    if (o.mode1 > 7 || (o.dual && o.mode2 > 7)) {
        terminate(SearchOutcome::Unsupported);
        return false;
    }
    if (!std::isfinite(o.progress) || !finitePlayer(o.x1, o.y1, o.vx1, o.vy1) ||
        (o.dual && !finitePlayer(o.x2, o.y2, o.vx2, o.vy2))) {
        terminate(SearchOutcome::Unsupported);
        return false;
    }
    // A dual portal changes branching for later segments, even if start(false).
    if (o.dual) m_dual = true;
    return true;
}

Input Search::desired(uint64_t step, Observation const& observation) {
    if (!running() || !m_attemptActive || !supported(observation)) return {};
    if (m_totalSteps >= m_config.maxTotalSteps) {
        terminate(SearchOutcome::TotalStepLimit);
        return {};
    }
    // Repeating/skipping a step would produce a trace the game did not execute.
    if (step != m_trace.size() || step != m_executed || step >= m_config.maxSteps) {
        terminate(SearchOutcome::ReplayMismatch);
        return {};
    }
    if (step == 0) m_boundaries.push_back({0, observation});
    Input input{};
    if (step < m_current.prefix.size()) input = m_current.prefix[size_t(step)];
    else {
        if (step % m_config.segmentSteps == 0) {
            m_tailInput = {};
            unsigned const players = (m_dual || observation.dual) ? 2 : 1;
            for (unsigned p = 0; p != players; ++p) {
                if (m_platformer) m_tailInput[p][2] = true;
                uint32_t const mode = p ? observation.mode2 : observation.mode1;
                // Ship and wave respond to held input. UFO/swing need presses
                // with different semantics, so retain their release baseline.
                if (mode == 1 || mode == 4)
                    m_tailInput[p][0] = preferJump(observation, p != 0);
            }
        }
        input = m_tailInput;
        unsigned const players = (m_dual || observation.dual) ? 2 : 1;
        for (unsigned p = 0; p < players; ++p)
            if (observation.analyzed[p]) input[p] = observation.planned[p];
    }
    m_trace.push_back(input);
    ++m_totalSteps;
    return input;
}

double Search::score(Observation const& o, uint64_t steps) const {
    // Percent is the main objective, with x and survival breaking close ties.
    // Platformer maps that require backtracking can defeat this heuristic.
    double progress = std::clamp(double(o.progress), 0.0, 100.0);
    double x = o.dual ? std::min(o.x1, o.x2) : o.x1;
    return progress * 1000000 + std::clamp(x, -100000.0, 100000.0) * 10 +
        double(steps) * 0.001;
}

void Search::observe(uint64_t step, Observation const& observation) {
    if (!running() || !m_attemptActive || !supported(observation)) return;
    if (step != m_trace.size() || step != m_executed + 1) {
        terminate(SearchOutcome::ReplayMismatch);
        return;
    }
    m_executed = step;
    m_last = observation;
    m_bestProgress = std::max(m_bestProgress, std::clamp(observation.progress, 0.f, 100.f));
    if (!observation.dead && step % m_config.segmentSteps == 0)
        m_boundaries.push_back({step, observation});
    if (observation.dead) closeAttempt(false);
    else if (step >= m_config.maxSteps) terminate(SearchOutcome::StepLimit);
    if (running() && m_totalSteps >= m_config.maxTotalSteps)
        terminate(SearchOutcome::TotalStepLimit);
}

void Search::finishAttempt(bool completed) {
    if (!running() || !m_attemptActive) return;
    if (completed) {
        m_solution = m_trace;
        m_bestProgress = 100;
        terminate(SearchOutcome::Found);
    } else closeAttempt(false);
}

void Search::closeAttempt(bool survived) {
    if (!m_attemptActive) return;
    m_attemptActive = false;
    (void)survived;
    // Refine several lead times: a necessary action can be far before death.
    // These are observations and input history only; the game never restores them.
    uint64_t const whole = m_executed ? (m_executed - 1) / m_config.segmentSteps : 0;
    // Fine timing must not shrink the whole lookback to only 8/16 ticks.
    std::array<uint64_t, 6> const rewinds{
        1, 2, 4, 8,
        (24ull + m_config.segmentSteps - 1) / m_config.segmentSteps,
        (48ull + m_config.segmentSteps - 1) / m_config.segmentSteps
    };
    for (size_t range = 0; range < rewinds.size(); ++range) {
        uint64_t const rewind = rewinds[range];
        uint64_t const depth = whole > rewind ? whole - rewind : 0;
        if (depth >= m_boundaries.size()) continue;
        Node safe;
        safe.end = m_boundaries[size_t(depth)].observation;
        safe.score = score(safe.end, depth * m_config.segmentSteps);
        safe.serial = tieKey(m_serial++ ^ m_config.seed);
        safe.rewindRange = uint8_t(range);
        size_t const prefixTicks = size_t(depth * m_config.segmentSteps);
        safe.prefix.assign(m_trace.begin(), m_trace.begin() + prefixTicks);
        auto duplicate = std::find_if(m_survivors.begin(), m_survivors.end(), [&](Node const& n) {
            return n.prefix == safe.prefix;
        });
        if (duplicate == m_survivors.end()) m_survivors.push_back(std::move(safe));
    }
    pruneSurvivors();
    if (m_totalSteps >= m_config.maxTotalSteps) {
        terminate(SearchOutcome::TotalStepLimit);
        return;
    }
    if (m_attempts >= m_config.maxAttempts) {
        terminate(SearchOutcome::AttemptLimit);
        return;
    }
    if (m_pending.empty()) advance();
}

void Search::pruneSurvivors() {
    auto better = [](Node const& a, Node const& b) {
        if (a.score != b.score) return a.score > b.score;
        return a.serial < b.serial;
    };
    std::stable_sort(m_survivors.begin(), m_survivors.end(), better);
    if (m_survivors.size() <= m_config.beamWidth) return;
    // Keep one best history from each lead-time range before filling the beam
    // by score. Otherwise slightly higher progress erases every early action.
    std::vector<bool> selected(m_survivors.size(), false);
    std::vector<Node> retained;
    retained.reserve(m_config.beamWidth);
    // With a small beam preserve near actions plus the 48/24-tick lookbacks.
    constexpr std::array<uint8_t, 6> priorities{0, 1, 5, 4, 2, 3};
    for (uint8_t range : priorities) {
        if (retained.size() >= m_config.beamWidth) break;
        for (size_t i = 0; i < m_survivors.size(); ++i) {
            if (m_survivors[i].rewindRange != range) continue;
            selected[i] = true;
            retained.push_back(std::move(m_survivors[i]));
            break;
        }
    }
    for (size_t i = 0; i < m_survivors.size() && retained.size() < m_config.beamWidth; ++i) {
        if (!selected[i]) retained.push_back(std::move(m_survivors[i]));
    }
    std::stable_sort(retained.begin(), retained.end(), better);
    m_survivors = std::move(retained);
}

void Search::advance() {
    if (!running()) return;
    if (m_survivors.empty()) {
        terminate(SearchOutcome::Exhausted);
        return;
    }
    if (m_survivors.front().prefix.size() >= m_config.maxSteps) {
        terminate(SearchOutcome::StepLimit);
        return;
    }
    auto parents = std::move(m_survivors);
    m_survivors.clear();
    expand(parents);
    if (m_pending.empty())
        terminate(m_budgetBlocked ? SearchOutcome::TotalStepLimit : SearchOutcome::Exhausted);
}

void Search::terminate(SearchOutcome outcome) {
    m_outcome = outcome;
    m_attemptActive = false;
    m_pending.clear();
    m_survivors.clear();
    m_current = {};
    m_trace.clear();
    m_boundaries.clear();
    m_visited.clear();
}

void Search::stop() {
    if (running()) terminate(SearchOutcome::Cancelled);
}
bool Search::running() const { return m_outcome == SearchOutcome::Searching; }
bool Search::needsRestart() const { return running() && !m_attemptActive; }
uint32_t Search::attempt() const { return m_attempts; }
float Search::bestProgress() const { return m_bestProgress; }
SearchOutcome Search::outcome() const { return m_outcome; }
std::vector<Input> const& Search::solution() const { return m_solution; }

std::string Search::status() const {
    std::ostringstream result;
    switch (m_outcome) {
        case SearchOutcome::Idle: return "Поиск не запущен";
        case SearchOutcome::Found: return "Игра подтвердила завершение; требуется проверка воспроизведения";
        case SearchOutcome::Cancelled: return "Поиск остановлен пользователем";
        case SearchOutcome::Exhausted: return "Решение не найдено: исчерпаны сохранённые ветви поиска";
        case SearchOutcome::AttemptLimit: return "Решение не найдено: исчерпан лимит попыток";
        case SearchOutcome::StepLimit: return "Решение не найдено: исчерпан лимит длины попытки";
        case SearchOutcome::Unsupported: return "Поиск остановлен: неизвестный режим движения или некорректное состояние";
        case SearchOutcome::InvalidConfiguration: return "Поиск не запущен: недопустимые ограничения";
        case SearchOutcome::ReplayMismatch: return "Поиск остановлен: нарушен порядок шагов симуляции";
        case SearchOutcome::TotalStepLimit: return "Решение не найдено: исчерпан общий бюджет шагов поиска";
        case SearchOutcome::Searching: break;
    }
    result << "Попытка " << m_attempts << "/" << m_config.maxAttempts
           << "; лучший прогресс " << std::fixed << std::setprecision(1) << m_bestProgress
           << "%; глубина " << m_current.prefix.size() << " шагов";
    return result.str();
}

} // namespace gdm
