#include "core/StepClock.hpp"
#include <cassert>
#include <limits>
#include <iostream>
using namespace gdm;
int main() {
    int checks=0;
    auto check=[&](bool value){++checks;if(!value)throw std::runtime_error("clock regression");};
    auto rejected=[&](auto fn){bool failed=false;try{fn();}catch(std::runtime_error const&){failed=true;}check(failed);};
    StepClock c;
    check(c.accept(0,0,false)==TickBoundary::Resume);
    check(c.accept(0,1.f/240,true)==TickBoundary::HalfTick);
    check(c.accept(0,1.f/240,false)==TickBoundary::Advance);
    check(c.accept(0,1.f/240,false)==TickBoundary::Duplicate);
    check(c.accept(1,1.f/240,false)==TickBoundary::Advance);
    // Timestamped native input can split an otherwise ordinary full tick.
    check(c.accept(2,1.f/480,true)==TickBoundary::HalfTick);
    check(c.accept(3,1.f/240,false)==TickBoundary::Advance);
    check(c.accept(4,1.f/240,false)==TickBoundary::Advance);
    rejected([&]{c.accept(6,1.f/240,false);});
    c.reset();check(c.accept(0,1.f/240,false)==TickBoundary::Advance);
    rejected([&]{c.accept(0,-1,false);});
    rejected([&]{c.accept(0,std::numeric_limits<float>::quiet_NaN(),false);});
    c.reset();check(c.accept(40,1.f/240,false)==TickBoundary::Advance);
    rejected([&]{c.accept(39,1.f/240,true);});
    // Empty/resume updates do not consume an input step.
    c.reset();check(c.accept(5,0,false)==TickBoundary::Resume);
    check(c.accept(5,1.f/240,false)==TickBoundary::Advance);
    check(c.accept(6,0,false)==TickBoundary::Resume);
    check(c.accept(7,1.f/240,false)==TickBoundary::Advance);
    std::cout<<"step clock: "<<checks<<" checks passed\n";
}
