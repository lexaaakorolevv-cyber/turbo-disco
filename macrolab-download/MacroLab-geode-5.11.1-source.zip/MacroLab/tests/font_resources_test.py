#!/usr/bin/env python3
"""Verify the font and the Windows path regression without third-party modules.

Run from any directory with Python 3.9+: python tests/font_resources_test.py
Add --package path/to/local.macrolab.geode to verify the built archive as well.
This checks packaged data and the resource resolver contract, not game rendering.
"""

import argparse
import json
from pathlib import Path
import re
import shlex
import struct
import sys
import zipfile
import zlib


ROOT = Path(__file__).resolve().parents[1]
FNT_NAME = "ui-font-v021.fnt"
PNG_NAME = "ui-font-v021.png"
MOD_ID = "local.macrolab"


class VerificationError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise VerificationError(message)


def cocos_relative_file(page, font_path):
    """Match cocos CCFileUtils::fullPathFromRelativeFile's slash-only parent.

    The native implementation looks for '/', not the Windows '\\' separator.
    It prefixes the page with the supplied font filename's directory.
    """
    slash = font_path.rfind("/")
    return font_path[: slash + 1] + page if slash >= 0 else page


def check_source_path():
    source = (ROOT / "src/ui/ControlPopup.cpp").read_text(encoding="utf-8")
    function = re.search(r"\bstd::string\s+fontPath\s*\(\s*\)\s*\{(.*?)^\}",
                         source, flags=re.DOTALL | re.MULTILINE)
    require(function is not None, "Cannot locate fontPath() to verify its resource path")
    body = re.sub(r"//[^\n]*|/\*.*?\*/", "", function.group(1), flags=re.DOTALL)
    require("getResourcesDir" not in body and ".string()" not in body,
            "fontPath() must use a namespaced resource path, not a Windows filesystem string")
    returned = re.search(r'\breturn\s+"([^"\\]+)"\s*(_spr)?\s*;', body)
    if returned is not None:
        literal, suffix = returned.groups()
    else:
        candidates = re.findall(
            r'\b(?:std::string|auto)\s+(\w+)\s*=\s*"([^"\\]+)"\s*(_spr)?\s*;', body)
        returned_candidates = [(literal, suffix) for name, literal, suffix in candidates
                               if re.search(r"\breturn\s+" + re.escape(name) + r"\s*;", body)]
        require(len(returned_candidates) == 1,
                "fontPath() must return a namespaced literal or a variable initialized from it")
        literal, suffix = returned_candidates[0]
    path = MOD_ID + "/" + literal if suffix else literal
    require(path == MOD_ID + "/" + FNT_NAME,
            "fontPath() does not resolve to the versioned namespaced font")

    # Reproduce the old failure and prove the corrected path retains the atlas
    # namespace through the exact slash-only directory operation.
    old_path = "C:\\GeometryDash\\geode\\unzipped\\" + MOD_ID + "\\" + FNT_NAME
    require(cocos_relative_file(PNG_NAME, old_path) == PNG_NAME,
            "Windows path regression fixture no longer reproduces the lost directory")
    require(cocos_relative_file(PNG_NAME, path) == MOD_ID + "/" + PNG_NAME,
            "Corrected font path loses the atlas namespace in the cocos resolver")


def fields(line):
    return dict(token.split("=", 1) for token in shlex.split(line)[1:] if "=" in token)


def parse_font(data):
    lines = data.decode("utf-8").splitlines()
    common = None
    pages = {}
    glyphs = {}
    declared_count = None
    for line in lines:
        if line.startswith("common "):
            require(common is None, "Duplicate common font record")
            common = fields(line)
        elif line.startswith("page "):
            record = fields(line)
            page_id = int(record["id"])
            require(page_id not in pages, "Duplicate font page")
            pages[page_id] = record["file"]
        elif line.startswith("chars "):
            require(declared_count is None, "Duplicate glyph count")
            declared_count = int(fields(line)["count"])
        elif line.startswith("char "):
            record = {key: int(value) for key, value in fields(line).items()}
            char_id = record["id"]
            require(char_id not in glyphs, "Duplicate glyph ID: " + str(char_id))
            glyphs[char_id] = record
    require(common is not None, "Font has no common metrics")
    require(int(common["pages"]) == 1 and pages == {0: PNG_NAME},
            "Font page must reference the exact versioned sibling PNG")
    require(declared_count == len(glyphs), "Font glyph count does not match its records")
    width, height = int(common["scaleW"]), int(common["scaleH"])
    require(width > 0 and height > 0 and int(common["lineHeight"]) > 0,
            "Invalid font dimensions or line height")
    for char_id, record in glyphs.items():
        x, y, w, h = (record[key] for key in ("x", "y", "width", "height"))
        require(0 <= char_id <= 0x10FFFF and record["page"] == 0,
                "Invalid glyph ID or page: " + str(char_id))
        require(x >= 0 and y >= 0 and w >= 0 and h >= 0
                and x + w <= width and y + h <= height,
                "Glyph exceeds atlas bounds: U+%04X" % char_id)
    return glyphs, (width, height)


def source_literal_codepoints():
    # Tokenize comments together with literals so quotation marks in comments
    # cannot make comments look like actual runtime text. Raw strings are
    # supported as well as ordinary strings and C++ Unicode escape sequences.
    token = re.compile(
        r'//[^\n]*|/\*.*?\*/|'
        r'(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\t\r\n]{0,16})\((?P<raw>.*?)\)(?P=delimiter)"|'
        r'(?:u8|u|U|L)?"(?:\\.|[^"\\])*"|'
        r"(?:u8|u|U|L)?'(?:\\.|[^'\\])*'",
        re.DOTALL,
    )
    needed = set()
    for path in sorted((ROOT / "src").rglob("*")):
        if path.suffix not in (".cpp", ".hpp", ".h"):
            continue
        for match in token.finditer(path.read_text(encoding="utf-8")):
            literal = match.group()
            if literal.startswith(("//", "/*")):
                continue
            raw = match.group("raw")
            needed.update(ord(char) for char in (raw if raw is not None else literal)
                          if ord(char) > 127)
            if raw is None:
                for escaped in re.findall(r"\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{8})", literal):
                    needed.add(int(escaped[0] or escaped[1], 16))
    return needed


def check_png(data, expected_size):
    require(data[:8] == b"\x89PNG\r\n\x1a\n", "Invalid PNG signature")
    offset = 8
    chunk_index = 0
    ended = False
    while offset < len(data):
        require(offset + 12 <= len(data), "Truncated PNG chunk header")
        length = struct.unpack_from(">I", data, offset)[0]
        chunk_type = data[offset + 4: offset + 8]
        end = offset + 8 + length
        require(end + 4 <= len(data), "Truncated PNG chunk data")
        content = data[offset + 8: end]
        checksum = struct.unpack_from(">I", data, end)[0]
        require(zlib.crc32(chunk_type + content) & 0xFFFFFFFF == checksum,
                "Invalid PNG chunk checksum: " + repr(chunk_type))
        if chunk_index == 0:
            require(chunk_type == b"IHDR" and length == 13, "PNG must begin with IHDR")
            width, height, depth, colour, compression, filtering, interlace = struct.unpack(
                ">IIBBBBB", content)
            require((width, height) == expected_size, "PNG size does not match FNT metrics")
            require(depth == 8 and colour == 6 and compression == 0 and filtering == 0
                    and interlace in (0, 1), "Font atlas must be an RGBA8 PNG")
        elif chunk_type == b"IHDR":
            raise VerificationError("Duplicate PNG IHDR")
        offset = end + 4
        chunk_index += 1
        if chunk_type == b"IEND":
            require(length == 0 and offset == len(data), "Invalid PNG end or trailing data")
            ended = True
            break
    require(ended, "PNG has no IEND chunk")


def check_metadata(metadata):
    require(metadata["id"] == MOD_ID, "Unexpected mod ID")
    require(metadata["version"] == "v0.3.0", "Automatic analysis package must be v0.3.0")
    require(metadata["geode"] == "5.11.1" and metadata["gd"]["win"] == "2.2081",
            "Unexpected Geode or Geometry Dash target")


def check_package(path, font_data, png_data):
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "Package ZIP CRC verification failed")
        require(len(archive.namelist()) == len(set(archive.namelist())),
                "Package contains duplicate entry names")
        check_metadata(json.loads(archive.read("mod.json")))
        prefix = "resources/" + MOD_ID + "/"
        require(archive.read(prefix + FNT_NAME) == font_data,
                "Packaged FNT does not match the checked source resource")
        require(archive.read(prefix + PNG_NAME) == png_data,
                "Packaged PNG does not match the checked source resource")
        dll = archive.read(MOD_ID + ".dll")
        require(len(dll) >= 64 and dll[:2] == b"MZ", "Package has no valid Windows DLL")
        pe_offset = struct.unpack_from("<I", dll, 60)[0]
        require(pe_offset >= 64 and pe_offset + 24 <= len(dll)
                and dll[pe_offset: pe_offset + 4] == b"PE\0\0",
                "Windows DLL has an invalid PE header")
        require(struct.unpack_from("<H", dll, pe_offset + 4)[0] == 0x8664,
                "Windows DLL must target x64")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, help="Also verify an installable .geode archive")
    args = parser.parse_args()
    check_source_path()
    metadata = json.loads((ROOT / "mod.json").read_text(encoding="utf-8"))
    check_metadata(metadata)
    resources = metadata["resources"]["files"]
    require("resources/" + FNT_NAME in resources and "resources/" + PNG_NAME in resources,
            "Both versioned font resources must appear in mod.json")
    font_data = (ROOT / "resources" / FNT_NAME).read_bytes()
    png_data = (ROOT / "resources" / PNG_NAME).read_bytes()
    glyphs, size = parse_font(font_data)
    required = set(range(32, 127)) | set(range(0x410, 0x450)) | {0x401, 0x451}
    source_points = source_literal_codepoints()
    required.update(source_points)
    missing = sorted(required.difference(glyphs))
    require(not missing, "Font is missing characters: " + ", ".join("U+%04X" % c for c in missing))
    check_png(png_data, size)
    print("Font resources PASS: %d glyphs; %d source non-ASCII characters; "
          "Windows path regression; %dx%d RGBA8 PNG" %
          (len(glyphs), len(source_points), size[0], size[1]))
    if args.package:
        check_package(args.package, font_data, png_data)
        print("Package PASS: ZIP CRC, v0.3.0, Geode 5.11.1, GD 2.2081, x64 DLL, matching font resources")


if __name__ == "__main__":
    try:
        main()
    except (VerificationError, OSError, ValueError, KeyError, zipfile.BadZipFile, struct.error) as error:
        print("Font verification FAILED: " + str(error), file=sys.stderr)
        sys.exit(1)
