#include "core/LevelBinding.hpp"
#include <array>
#include <iostream>
#include <stdexcept>

using namespace gdm;

int main() {
    // Opaque identities model policy inputs, never Geometry Dash classes.
    int identities[3]{};
    void const* const a = &identities[0];
    void const* const b = &identities[1];
    void const* const stale = &identities[2];
    int checks = 0;
    auto expect = [&](BindingDecision decision, BindingAction action, void const* token) {
        ++checks;
        if (decision.action != action || decision.token != token)
            throw std::runtime_error("level binding regression at check " + std::to_string(checks));
    };
    std::array const liveA{LevelCandidate{a, true, true}};
    std::array const liveB{LevelCandidate{b, true, true}};
    std::array const liveBoth{LevelCandidate{a, true, true}, LevelCandidate{b, true, true}};
    std::array<LevelCandidate, 0> const empty{};

    // A missed init hook can be recovered from the actual running scene.
    expect(resolveLevelBinding(nullptr, nullptr, false, liveA, a), BindingAction::Attach, a);
    expect(resolveLevelBinding(nullptr, nullptr, false, liveA), BindingAction::Attach, a);
    // Same-layer observations explicitly request no reset, including quarantine.
    expect(resolveLevelBinding(a, nullptr, false, liveA, a), BindingAction::Keep, a);
    expect(resolveLevelBinding(a, nullptr, true, liveA, a), BindingAction::Keep, a);
    expect(resolveLevelBinding(a, nullptr, true, liveA, a), BindingAction::Keep, a);
    // A paused layer remains live: pausing must not prevent starting a command.
    expect(resolveLevelBinding(nullptr, nullptr, false, liveA), BindingAction::Attach, a);

    std::array const incomplete{LevelCandidate{a, true, false}};
    std::array const offscene{LevelCandidate{a, false, true}};
    std::array const nullCandidate{LevelCandidate{nullptr, true, true}};
    expect(resolveLevelBinding(nullptr, nullptr, false, incomplete, a), BindingAction::Unavailable, nullptr);
    // An initialized impostor referenced by GameManager is not a running level.
    expect(resolveLevelBinding(nullptr, nullptr, false, offscene, a), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(a, nullptr, false, offscene, a), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(nullptr, nullptr, false, nullCandidate), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(nullptr, nullptr, false, empty, stale), BindingAction::Unavailable, nullptr);

    // Outgoing nodes stay running during fade, but are explicitly disallowed.
    expect(resolveLevelBinding(a, a, false, liveA, a), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(a, a, true, liveBoth, a), BindingAction::Unavailable, nullptr);
    // A stale singleton cannot override the live owner supplied by the scene.
    expect(resolveLevelBinding(nullptr, nullptr, false, liveB, stale), BindingAction::Attach, b);
    expect(resolveLevelBinding(b, nullptr, false, liveB, stale), BindingAction::Keep, b);
    // Known live UI owner takes priority over an eligible older binding.
    expect(resolveLevelBinding(a, nullptr, false, liveBoth, b), BindingAction::Attach, b);
    expect(resolveLevelBinding(a, nullptr, false, liveBoth, stale), BindingAction::Keep, a);

    // Isolated pending statistics must be restored by old onExit first.
    expect(resolveLevelBinding(a, nullptr, true, liveB, b), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(a, nullptr, true, liveBoth, b), BindingAction::Unavailable, nullptr);
    expect(resolveLevelBinding(nullptr, nullptr, false, liveB, b), BindingAction::Attach, b);
    // A late observation/exit of A cannot select A after B becomes current.
    expect(resolveLevelBinding(b, a, true, liveBoth, a), BindingAction::Keep, b);
    expect(resolveLevelBinding(b, a, false, liveBoth, a), BindingAction::Keep, b);
    // An editor UI contributes no PlayLayer candidate.
    expect(resolveLevelBinding(nullptr, nullptr, false, empty), BindingAction::Unavailable, nullptr);

    std::array const mixed{
        LevelCandidate{a, true, false}, LevelCandidate{stale, false, true},
        LevelCandidate{b, true, true}
    };
    expect(resolveLevelBinding(nullptr, nullptr, false, mixed, a), BindingAction::Attach, b);
    // Missing preferred candidate falls back to a valid current layer even if
    // a different eligible node occurs first in the adapter's scene traversal.
    expect(resolveLevelBinding(b, nullptr, false, liveBoth, stale), BindingAction::Keep, b);

    std::cout << "level binding: " << checks << " checks passed\n";
}
