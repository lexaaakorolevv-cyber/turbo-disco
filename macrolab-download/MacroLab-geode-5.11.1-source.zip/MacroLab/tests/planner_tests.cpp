#include "search/LocalPlanner.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool condition, char const* message) {
    if (!condition) throw std::runtime_error(message);
}
bool intersect(gdm::WorldRect const& a, gdm::WorldRect const& b) {
    return a.left < b.right - 0.05 && a.right > b.left + 0.05 &&
        a.bottom < b.top - 0.05 && a.top > b.bottom + 0.05;
}
gdm::Input planned(gdm::LocalPlanner& planner, gdm::Observation const& o,
    std::array<gdm::PlayerScene, 2> const& scenes, bool platformer) {
    auto const input = planner.plan(o, scenes, platformer);
    planner.applied(input);
    return input;
}

// Independent discrete physics: planner never modifies this world, receives
// only hitboxes and measured displacement, and cannot mark it completed.
struct CubeWorld {
    double x = 0, foot = 0, vy = 0, previousDy = 0;
    bool grounded = true, inverted = false, withGap = false, ceiling = false, dead = false;
    unsigned presses = 0;

    gdm::WorldRect reflect(gdm::WorldRect r) const {
        if (inverted) { double old = r.bottom; r.bottom = -r.top; r.top = -old; }
        return r;
    }
    gdm::WorldRect player() const { return reflect({x - 15, foot, x + 15, foot + 30}); }
    std::array<gdm::PlayerScene, 2> scenes() const {
        std::array<gdm::PlayerScene, 2> result;
        auto& scene = result[0];
        scene.player = player(); scene.dx = 1.4;
        scene.dy = inverted ? -previousDy : previousDy; scene.motionValid = true;
        if (withGap) {
            scene.features.push_back({reflect({-100, -30, 100, 0}), gdm::FeatureKind::Solid});
            scene.features.push_back({reflect({190, -30, 500, 0}), gdm::FeatureKind::Solid});
        } else {
            if (inverted) { scene.ceilingAvailable = true; scene.ceilingY = 0; }
            else { scene.floorAvailable = true; scene.floorY = 0; }
            scene.features.push_back({reflect({180, 0, 210, 30}), gdm::FeatureKind::Hazard});
        }
        if (ceiling) scene.features.push_back({reflect({-100, 60, 110, 90}), gdm::FeatureKind::Solid});
        return result;
    }
    gdm::Observation observation() const {
        gdm::Observation o;
        o.x1 = x; o.y1 = inverted ? -foot - 15 : foot + 15;
        o.grounded1 = grounded; o.upsideDown1 = inverted;
        o.vy1 = vy; o.vx1 = 5000; // deliberately unrelated native units
        return o;
    }
    void simulate(gdm::Input const& input) {
        if (grounded && input[0][0]) { vy = 2.8; grounded = false; ++presses; }
        double const before = foot;
        if (!grounded) { foot += vy; vy -= 0.06; }
        x += 1.4;
        bool const support = !withGap || x <= 100 || x >= 190;
        if (foot <= 0 && support) { foot = 0; vy = 0; grounded = true; }
        else if (grounded && !support) { grounded = false; vy = -0.06; }
        previousDy = foot - before;
        if (foot < -35) dead = true;
        auto const geometry = scenes();
        for (auto const& f : geometry[0].features)
            if (f.kind == gdm::FeatureKind::Hazard && intersect(player(), f.bounds)) dead = true;
        if (ceiling && intersect(player(), reflect({-100, 60, 110, 90}))) dead = true;
    }
};

void proactiveCubeClearance(bool inverted, bool ceiling) {
    gdm::LocalPlanner planner;
    CubeWorld world; world.inverted = inverted; world.ceiling = ceiling;
    double firstJump = -1;
    for (unsigned t = 0; t < 230; ++t) {
        auto const input = planned(planner, world.observation(), world.scenes(), false);
        if (input[0][0] && firstJump < 0) firstJump = world.x;
        world.simulate(input);
        require(!world.dead, "proactive cube hit a spike or ceiling before a retry");
    }
    require(world.x > 300 && world.presses == 1, "cube did not clear and land with one proactive jump");
    require(firstJump > 110 && firstJump < 170, "cube jump was not scheduled from upcoming geometry");
}

void visibleGapIsJumped() {
    gdm::LocalPlanner planner;
    CubeWorld world; world.withGap = true;
    bool airborneOverGap = false;
    for (unsigned t = 0; t < 210; ++t) {
        auto const input = planned(planner, world.observation(), world.scenes(), false);
        world.simulate(input);
        airborneOverGap |= world.x > 100 && world.x < 190 && world.foot > 0;
        require(!world.dead, "planner fell through a visible jumpable gap");
    }
    require(airborneOverGap && world.grounded && world.presses == 1,
        "gap plan did not jump and land on the actual next platform");
}

void unsafeCeilingIsRespected() {
    gdm::LocalPlanner planner;
    gdm::Observation o; o.grounded1 = true;
    std::array<gdm::PlayerScene, 2> scenes;
    auto& scene = scenes[0];
    scene.player = {50, 0, 80, 30}; scene.dx = 1.4; scene.motionValid = true;
    scene.floorAvailable = true;
    scene.features.push_back({{90, 0, 120, 30}, gdm::FeatureKind::Hazard});
    scene.features.push_back({{40, 40, 160, 70}, gdm::FeatureKind::Solid});
    require(!planned(planner, o, scenes, false)[0][0], "planner knowingly jumped into an overhead solid");
}

void waveUsesForwardCorridorAndGravity() {
    for (bool inverted : {false, true}) {
        gdm::LocalPlanner planner;
        double y = 60, dy = -1.4;
        for (unsigned t = 0; t < 180; ++t) {
            gdm::Observation o; o.mode1 = 4; o.upsideDown1 = inverted;
            std::array<gdm::PlayerScene, 2> scenes;
            auto& scene = scenes[0];
            double const worldY = inverted ? -y : y;
            scene.player = {double(t) * 1.4 - 5, worldY - 5, double(t) * 1.4 + 5, worldY + 5};
            scene.dx = 1.4; scene.dy = inverted ? -dy : dy; scene.motionValid = true;
            scene.floorAvailable = scene.ceilingAvailable = true;
            scene.floorY = inverted ? -120 : 0; scene.ceilingY = inverted ? 0 : 120;
            // The corridor narrows upward after x=90. A purely altitude-damping
            // controller would hit this obstacle at y=60.
            auto rect = gdm::WorldRect{90, 0, 250, 65};
            if (inverted) rect = {90, -65, 250, 0};
            scene.features.push_back({rect, gdm::FeatureKind::Hazard});
            auto const input = planned(planner, o, scenes, false);
            dy = input[0][0] ? 1.4 : -1.4;
            y += dy;
            require(y > 5 && y < 115, "wave escaped actual corridor boundaries");
            if (double(t + 1) * 1.4 + 5 > 90 && double(t + 1) * 1.4 - 5 < 250)
                require(y - 5 >= 65, "wave ignored a future floor obstacle");
        }
    }
}

void orbProducesOneEdgeAndRearms() {
    gdm::LocalPlanner planner;
    gdm::Observation o; o.grounded1 = false;
    std::array<gdm::PlayerScene, 2> scenes;
    scenes[0].player = {0, 0, 30, 30}; scenes[0].touchingOrb = true;
    require(planned(planner, o, scenes, false)[0][0], "orb did not receive a real press");
    for (unsigned t = 0; t < 20; ++t)
        require(!planned(planner, o, scenes, false)[0][0], "orb received an indefinite held jump");
    scenes[0].touchingOrb = false; planned(planner, o, scenes, false);
    scenes[0].touchingOrb = true;
    require(planned(planner, o, scenes, false)[0][0], "leaving an orb did not rearm its edge");
}

void shipAccountsForAccelerationAndBraking() {
    gdm::LocalPlanner planner;
    double x = 0, y = 60, dy = 0;
    for (unsigned t = 0; t < 220; ++t) {
        gdm::Observation o; o.mode1 = 1;
        std::array<gdm::PlayerScene, 2> scenes;
        auto& scene = scenes[0];
        scene.player = {x - 5, y - 5, x + 5, y + 5};
        scene.dx = 1.4; scene.dy = dy; scene.motionValid = true;
        scene.floorAvailable = scene.ceilingAvailable = true;
        scene.ceilingY = 120;
        scene.features.push_back({{90, 0, 250, 65}, gdm::FeatureKind::Hazard});
        auto const input = planned(planner, o, scenes, false);
        // Independent acceleration differs from the planner's approximate
        // constants: successful steering must use observed motion feedback.
        dy = std::clamp(dy + (input[0][0] ? 0.045 : -0.035), -3.0, 3.0);
        y += dy; x += 1.4;
        require(y > 5 && y < 115, "ship failed to brake within corridor boundaries");
        if (x + 5 > 90 && x - 5 < 250)
            require(y - 5 >= 65, "ship detected a future obstacle too late to accelerate");
    }
}

void dualGeometryStaysIndependentAndResetRearms() {
    gdm::LocalPlanner planner;
    gdm::Observation o; o.dual = true; o.grounded1 = o.grounded2 = true;
    std::array<gdm::PlayerScene, 2> scenes;
    for (auto& scene : scenes) {
        scene.player = {0, 0, 30, 30}; scene.floorAvailable = true;
        scene.motionValid = true; scene.dx = 1.4;
    }
    scenes[1].features.push_back({{45, 0, 75, 30}, gdm::FeatureKind::Hazard});
    auto input = planned(planner, o, scenes, true);
    require(!input[0][0] && input[1][0], "P2 borrowed P1 geometry or was not planned");
    require(input[0][2] && input[1][2] && !input[0][1], "platformer did not receive real right inputs");
    require(!planned(planner, o, scenes, true)[1][0], "cube jump did not release after its edge");
    planner.reset();
    require(planned(planner, o, scenes, true)[1][0], "normal retry did not reset planner input state");
}

void overriddenRecommendationDoesNotLatchPhantomActions() {
    gdm::LocalPlanner planner;
    gdm::Observation o; o.grounded1 = true;
    std::array<gdm::PlayerScene, 2> scenes;
    auto& scene = scenes[0];
    scene.player = {0, 0, 30, 30}; scene.dx = 1.4; scene.motionValid = true;
    scene.floorAvailable = true;
    scene.features.push_back({{45, 0, 75, 30}, gdm::FeatureKind::Hazard});
    require(planner.plan(o, scenes, false)[0][0], "overridden jump setup did not recommend jumping");
    planner.applied({}); // a learned prefix really released; no jump happened
    require(planner.plan(o, scenes, false)[0][0], "ignored recommendation latched a nonexistent jump");
    planner.applied({});
    scene.touchingOrb = true;
    require(planner.plan(o, scenes, false)[0][0], "overridden orb setup did not recommend an edge");
    planner.applied({});
    require(planner.plan(o, scenes, false)[0][0], "ignored orb recommendation consumed its activation");
    auto const actual = planner.plan(o, scenes, false);
    planner.applied(actual);
    require(!planned(planner, o, scenes, false)[0][0], "actual orb action was not committed");
}
} // namespace

int main() {
    try {
        proactiveCubeClearance(false, false);
        proactiveCubeClearance(false, true);
        proactiveCubeClearance(true, false);
        visibleGapIsJumped();
        unsafeCeilingIsRespected();
        waveUsesForwardCorridorAndGravity();
        shipAccountsForAccelerationAndBraking();
        orbProducesOneEdgeAndRearms();
        dualGeometryStaysIndependentAndResetRearms();
        overriddenRecommendationDoesNotLatchPhantomActions();
        std::cout << "planner tests passed\n";
        return EXIT_SUCCESS;
    } catch (std::exception const& error) {
        std::cerr << "planner test failure: " << error.what() << '\n';
        return EXIT_FAILURE;
    }
}
