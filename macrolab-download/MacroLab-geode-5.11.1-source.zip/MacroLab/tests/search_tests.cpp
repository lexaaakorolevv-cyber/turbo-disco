#include "search/Search.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, char const* message) {
    if (!condition) throw std::runtime_error(message);
}

gdm::SearchConfig smallConfig() {
    gdm::SearchConfig config;
    config.maxAttempts = 128;
    config.maxSteps = 30;
    config.segmentSteps = 2;
    config.beamWidth = 8;
    config.maxTotalSteps = 2000;
    return config;
}

// Deliberately unlike a button-driven mock of the implementation: this is a
// tiny physical world with a low ceiling followed by a floor obstacle.
// Jumping immediately kills the cube; jumping after the ceiling clears it.
struct CubeWorld {
    unsigned x = 0;
    unsigned jump[2]{};
    bool dual = false, dynamicDual = false, dead = false;
    bool impossible = false;
    unsigned resets = 0;

    void reset() { x = 0; jump[0] = jump[1] = 0; dead = false; ++resets; }
    bool dualActive() const { return dual || (dynamicDual && x >= 2); }
    gdm::Observation observation() const {
        gdm::Observation o;
        o.x1 = o.x2 = x;
        o.y1 = jump[0]; o.y2 = jump[1];
        o.vx1 = o.vx2 = 1;
        o.grounded1 = !jump[0]; o.grounded2 = !jump[1];
        o.dead = dead; o.dual = dualActive();
        o.progress = float(x) / 10 * 100;
        o.nearestHazardX = 5; o.nearestHazardY = 0;
        o.nearestHazardX2 = 7; o.nearestHazardY2 = 0;
        return o;
    }
    void simulate(gdm::Input const& input) {
        for (unsigned p = 0; p != 2; ++p) {
            if (input[p][0] && jump[p] == 0) jump[p] = 4;
            if (jump[p]) --jump[p];
        }
        ++x;
        if (x == 2 && jump[0]) dead = true;
        if (x == 5 && !jump[0]) dead = true;
        if (dualActive() && x == 3 && jump[1]) dead = true;
        if (dualActive() && x == 7 && !jump[1]) dead = true;
        if (impossible && x == 1) dead = true;
    }
    bool completed() const { return x == 10 && !dead; }
};

void run(gdm::Search& search, CubeWorld& world) {
    uint64_t step = 0;
    unsigned watchdog = 0;
    while (search.running()) {
        require(++watchdog < 10000, "search loop did not terminate");
        if (search.needsRestart()) {
            world.reset();
            search.beginAttempt();
            step = 0;
            if (!search.running()) break;
        }
        auto input = search.desired(step, world.observation());
        if (!search.running()) break;
        world.simulate(input);
        ++step;
        if (world.completed()) search.finishAttempt(true);
        else search.observe(step, world.observation());
    }
}

void delayedJumpIsFoundAndReplayed() {
    gdm::Search search;
    CubeWorld world;
    search.start(false, false, smallConfig());
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Found, "did not solve ceiling/obstacle world");
    require(world.resets > 1, "search must retry real reset rather than restore state");
    require(search.solution().size() == 10, "successful input trace has wrong length");
    require(!search.solution()[0][0][0], "solution jumped into low ceiling");
    bool jumped = false;
    world.reset();
    for (auto const& input : search.solution()) {
        jumped |= input[0][0];
        world.simulate(input);
        require(!world.dead, "successful input trace does not replay");
    }
    require(jumped && world.completed(), "replay did not actually clear obstacle and finish");
}

void bothPlayersHaveIndependentBranches(bool dynamicDual) {
    gdm::Search search;
    CubeWorld world;
    world.dual = !dynamicDual;
    world.dynamicDual = dynamicDual;
    auto config = smallConfig();
    config.maxAttempts = 512;
    config.maxTotalSteps = 10000;
    search.start(false, world.dual, config);
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Found, "dual world was not solved");
    bool differs = false, secondJumped = false;
    world.reset();
    for (auto const& input : search.solution()) {
        differs |= input[0][0] != input[1][0];
        secondJumped |= input[1][0];
        world.simulate(input);
        require(!world.dead, "dual solution did not replay");
    }
    require(differs && secondJumped && world.completed(), "second-player independent branches missing");
}

void failureCancellationAndLimits() {
    gdm::Search search;
    CubeWorld world;
    world.impossible = true;
    search.start(false, false, smallConfig());
    run(search, world);
    require(search.outcome() == gdm::SearchOutcome::Exhausted, "impossible world did not exhaust");
    require(search.solution().empty(), "failure exposed a solution");
    search.start(false, false, smallConfig());
    search.beginAttempt();
    search.stop();
    require(!search.running() && !search.needsRestart(), "cancel left search running");
    require(search.outcome() == gdm::SearchOutcome::Cancelled, "cancel reason lost");

    auto config = smallConfig(); config.maxAttempts = 1;
    world.impossible = false;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::AttemptLimit, "attempt limit ignored");
    config = smallConfig(); config.maxTotalSteps = 1;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::TotalStepLimit, "total duration limit ignored");
    config = smallConfig(); config.maxSteps = 2;
    search.start(false, false, config); run(search, world);
    require(search.outcome() == gdm::SearchOutcome::StepLimit, "attempt length limit ignored");
    config = smallConfig(); config.segmentSteps = 0;
    search.start(false, false, config);
    require(search.outcome() == gdm::SearchOutcome::InvalidConfiguration, "bad config accepted");
}

void unknownModesAndStepOrderAreRejected() {
    gdm::Search search;
    search.start(false, false, smallConfig()); search.beginAttempt();
    gdm::Observation observation; observation.mode1 = 42;
    search.desired(0, observation);
    require(search.outcome() == gdm::SearchOutcome::Unsupported, "unknown mode accepted");
    search.start(false, false, smallConfig()); search.beginAttempt();
    search.desired(1, {});
    require(search.outcome() == gdm::SearchOutcome::ReplayMismatch, "skipped simulation step accepted");
}

// A platformer must actually press right; no hidden automatic x movement.
void platformerMovementIsEnumerated() {
    gdm::Search search;
    auto config = smallConfig();
    search.start(true, false, config);
    uint64_t step = 0;
    double x = 0;
    while (search.running()) {
        if (search.needsRestart()) { x = 0; step = 0; search.beginAttempt(); }
        gdm::Observation o; o.x1 = x; o.grounded1 = true; o.progress = float(x * 10);
        auto input = search.desired(step, o);
        if (!search.running()) break;
        x += int(input[0][2]) - int(input[0][1]);
        ++step;
        if (x >= 4) search.finishAttempt(true);
        else { o.x1 = x; o.progress = float(x * 10); search.observe(step, o); }
    }
    require(search.outcome() == gdm::SearchOutcome::Found, "platformer right movement not searched");
    for (auto const& input : search.solution())
        require(!(input[0][1] && input[0][2]), "search generated conflicting directional holds");
}

// A complete ten-second corridor must not consume a retry for every twelve
// simulation ticks. A late obstacle must be refined near the actual collision.
void longRolloutsAndLateObstacle() {
    for (uint32_t segmentSteps : {1u, 2u, 6u, 12u}) {
        for (bool obstacle : {false, true}) {
            gdm::Search search;
            auto config = gdm::SearchConfig{};
            config.segmentSteps = segmentSteps;
            search.start(false, false, config);
            uint64_t step = 0;
            unsigned x = 0, jumping = 0, resets = 0;
            bool dead = false;
            unsigned watchdog = 0;
            while (search.running()) {
                require(++watchdog < 20000, "long rollout did not terminate");
                if (search.needsRestart()) {
                    x = jumping = 0; dead = false; step = 0; ++resets;
                    search.beginAttempt();
                }
                gdm::Observation o;
                o.x1 = x; o.y1 = jumping; o.vx1 = 1; o.grounded1 = !jumping;
                o.progress = float(x) / 2400 * 100;
                if (obstacle) { o.nearestHazardX = 1001; o.nearestHazardY = 0; }
                auto input = search.desired(step, o);
                if (!search.running()) break;
                if (input[0][0] && !jumping) jumping = 40;
                if (jumping) --jumping;
                ++x; ++step;
                dead = obstacle && x == 1001 && !jumping;
                if (x == 2400 && !dead) search.finishAttempt(true);
                else {
                    o.x1 = x; o.y1 = jumping; o.grounded1 = !jumping;
                    o.progress = float(x) / 2400 * 100; o.dead = dead;
                    search.observe(step, o);
                }
            }
            require(search.outcome() == gdm::SearchOutcome::Found, "late/empty ten-second level failed");
            require(search.solution().size() == 2400, "long solution trace truncated");
            require(resets <= (obstacle ? 8u : 1u), "search still retries every segment of empty corridor");
            require(search.bestProgress() == 100, "completion progress not reported");
            if (obstacle) {
                x = jumping = 0;
                for (auto const& input : search.solution()) {
                    if (input[0][0] && !jumping) jumping = 40;
                    if (jumping) --jumping;
                    ++x;
                    require(x != 1001 || jumping, "late-obstacle solution did not replay");
                }
                require(x == 2400, "late-obstacle replay did not reach actual end");
            }
        }
    }
}

// The earlier 1/2-segment refinement cannot clear this obstacle. A physical
// jump needs at least 48 ticks to rise high enough, but the preceding ceiling
// forbids a jump in the first 60 ticks. Holding later cannot move the player
// into place; each candidate has to reset and use an earlier real button press.
struct HighObstacleWorld {
    unsigned x = 0, age = 0, resets = 0;
    int y = 0, vy = 0;
    bool dead = false;

    void reset() { x = age = 0; y = vy = 0; dead = false; ++resets; }
    gdm::Observation observation() const {
        gdm::Observation o;
        o.x1 = x; o.y1 = y; o.vx1 = 1; o.vy1 = vy;
        o.grounded1 = y == 0;
        o.progress = float(x) / 140 * 100;
        o.nearestHazardX = 120; o.nearestHazardY = 0;
        o.dead = dead;
        return o;
    }
    void simulate(gdm::Input const& input) {
        if (input[0][0] && y == 0) { vy = 1; age = 0; }
        y += vy;
        if (vy && ++age == 60) vy = -1;
        if (y <= 0) { y = 0; vy = 0; }
        ++x;
        if (x <= 60 && y > 0) dead = true;
        if (x == 120 && y < 48) dead = true;
    }
    bool completed() const { return x == 140 && !dead; }
};

void longLeadActionsSurviveBeamPruning() {
    for (uint32_t segmentSteps : {1u, 2u, 6u, 12u}) {
        gdm::Search search;
        HighObstacleWorld world;
        auto config = smallConfig();
        config.maxSteps = 160;
        config.maxTotalSteps = 5000;
        config.segmentSteps = segmentSteps;
        config.beamWidth = 4;
        config.maxAttempts = 16;
        // Four close/long parents must get their first branch before a parent's
        // second branch consumes the entire remaining budget.
        if (segmentSteps == 2 || segmentSteps == 6) config.maxAttempts = 5;
        search.start(false, false, config);
        uint64_t step = 0;
        unsigned watchdog = 0;
        while (search.running()) {
            require(++watchdog < 5000, "long-lead search did not terminate");
            if (search.needsRestart()) {
                world.reset(); step = 0; search.beginAttempt();
            }
            auto input = search.desired(step, world.observation());
            if (!search.running()) break;
            world.simulate(input); ++step;
            if (world.completed()) search.finishAttempt(true);
            else search.observe(step, world.observation());
        }
        require(search.outcome() == gdm::SearchOutcome::Found,
                "beam discarded the action needed over 24 ticks before death");
        require(world.resets > 1, "long-lead solution did not use real retries");
        require(search.solution().size() == 140, "long-lead trace has incorrect length");
        world.reset();
        uint64_t firstJump = 140;
        for (uint64_t i = 0; i < search.solution().size(); ++i) {
            auto const& input = search.solution()[size_t(i)];
            if (input[0][0] && firstJump == 140) firstJump = i;
            if (i % segmentSteps) {
                require(input == search.solution()[size_t(i - 1)],
                        "reconstructing a prefix changed input within a segment");
            }
            world.simulate(input);
            require(!world.dead, "long-lead sequence does not replay");
        }
        require(firstJump >= 60 && firstJump <= 72,
                "high obstacle was not solved by an early, legal jump");
        require(world.completed(), "long-lead replay did not finish");
    }
}

// Directly inspect the first failure-directed branch. Neither player gets the
// other player's hazard hint; these hints only order alternatives.
gdm::Input firstBranch(gdm::Observation observation) {
    gdm::Search search;
    search.start(false, observation.dual, smallConfig());
    search.beginAttempt();
    search.desired(0, observation);
    auto after = observation; after.dead = true;
    search.observe(1, after);
    require(search.needsRestart(), "branch ordering test did not create candidates");
    search.beginAttempt();
    auto input = search.desired(0, observation);
    search.stop();
    return input;
}

void eachPlayerUsesOwnHazard() {
    gdm::Observation o;
    o.dual = true;
    o.grounded1 = o.grounded2 = true;
    o.x2 = 300000;
    o.nearestHazardX = 10000; o.nearestHazardY = 0;
    o.nearestHazardX2 = 300003; o.nearestHazardY2 = 0;
    auto input = firstBranch(o);
    require(!input[0][0] && input[1][0], "P2 did not use its independent hazard");
    o.x2 = 2;
    o.nearestHazardX = 5;
    o.nearestHazardX2 = o.nearestHazardY2 = std::numeric_limits<double>::infinity();
    input = firstBranch(o);
    require(input[0][0] && !input[1][0], "missing P2 hint incorrectly borrowed P1 geometry");
}

void flyingOrderRespectsGravityAndHazardSide() {
    for (uint32_t mode : {1u, 3u, 4u, 7u}) {
        for (bool inverted : {false, true}) {
            gdm::Observation o;
            o.mode1 = mode; o.upsideDown1 = inverted;
            o.vy1 = inverted ? 4 : -4;
            require(firstBranch(o)[0][0], "falling inverted player got release preference");
            o.vy1 = -o.vy1;
            require(!firstBranch(o)[0][0], "rising player got hold preference");
            // A local hazard on the gravity side orders the hold first, and a
            // hazard on the opposite side orders release even with falling vy.
            o.nearestHazardX = 20;
            o.nearestHazardY = inverted ? 20 : -20;
            require(firstBranch(o)[0][0], "hazard ordering ignored gravity direction");
            o.nearestHazardY = -o.nearestHazardY;
            o.vy1 = inverted ? 4 : -4;
            require(!firstBranch(o)[0][0], "ceiling hazard incorrectly preferred a hold");
        }
    }
    gdm::Observation dual;
    dual.dual = true;
    dual.mode1 = dual.mode2 = 1;
    dual.vy1 = dual.vy2 = 4;
    dual.upsideDown2 = true;
    auto input = firstBranch(dual);
    require(!input[0][0] && input[1][0], "dual players borrowed each other's gravity");
}

// An independent, bounded wave corridor checks the baseline's held-button
// feedback and fixed segment length; this is not Geometry Dash physics.
void waveRolloutUsesStateFeedback() {
    for (bool inverted : {false, true}) {
        gdm::Search search;
        auto config = smallConfig();
        config.segmentSteps = 6; config.maxSteps = 120; config.maxTotalSteps = 240;
        search.start(false, false, config);
        search.beginAttempt();
        double y = 0, vy = inverted ? 2 : -2;
        for (uint64_t step = 0; step < 120; ++step) {
            gdm::Observation o;
            o.x1 = double(step); o.y1 = y; o.vx1 = 1; o.vy1 = vy;
            o.mode1 = 4; o.upsideDown1 = inverted;
            o.progress = float(step) / 120 * 100;
            auto input = search.desired(step, o);
            require(search.running(), "wave feedback search stopped unexpectedly");
            vy = (inverted ? 2 : -2) * (input[0][0] ? -1 : 1);
            y += vy;
            require(std::abs(y) <= 12, "wave baseline continued falling out of corridor");
            o.x1 += 1; o.y1 = y; o.vy1 = vy;
            if (step == 119) search.finishAttempt(true);
            else search.observe(step + 1, o);
        }
        require(search.outcome() == gdm::SearchOutcome::Found && search.attempt() == 1,
                "empty wave corridor unnecessarily retried");
        y = 0;
        for (uint64_t step = 0; step < search.solution().size(); ++step) {
            auto const& input = search.solution()[size_t(step)];
            if (step % 6) require(input == search.solution()[size_t(step - 1)],
                                 "feedback changed a button inside the segment");
            y += (inverted ? 2 : -2) * (input[0][0] ? -1 : 1);
            require(std::abs(y) <= 12, "wave sequence did not replay");
        }
    }
}

void fineTimingAndExhaustedReplayBudgets() {
    gdm::Search search;
    // Fine presets must accept the same three-minute limit as coarse presets.
    for (uint32_t segmentSteps : {1u, 2u, 6u}) {
        auto config = gdm::SearchConfig{}; config.segmentSteps = segmentSteps;
        search.start(false, false, config);
        require(search.running(), "valid fine-timing preset rejected as too many segments");
        search.beginAttempt(); search.stop();
        require(search.outcome() == gdm::SearchOutcome::Cancelled && search.solution().empty(),
                "fine-timing cancellation retained a solution");
    }
    // Baseline survives to tick 120, but no prefix can be replayed inside the
    // remaining 30 ticks. Queueing them must report the total budget reason.
    auto config = smallConfig();
    config.segmentSteps = 6; config.maxSteps = 160;
    config.maxTotalSteps = 150;
    search.start(false, false, config);
    search.beginAttempt();
    HighObstacleWorld world; world.reset();
    for (uint64_t step = 0; step < 120; ++step) {
        auto input = search.desired(step, world.observation());
        require(search.running(), "replay-budget baseline stopped too soon");
        world.simulate(input); search.observe(step + 1, world.observation());
    }
    require(search.outcome() == gdm::SearchOutcome::TotalStepLimit,
            "unable-to-replay budget reported exhausted search branches");
    require(search.solution().empty(), "budget failure exposed a solution");
    // Death exactly on the budget boundary also takes the total-budget reason.
    config.maxTotalSteps = 120;
    search.start(false, false, config); search.beginAttempt(); world.reset();
    for (uint64_t step = 0; step < 120; ++step) {
        auto input = search.desired(step, world.observation());
        world.simulate(input); search.observe(step + 1, world.observation());
    }
    require(search.outcome() == gdm::SearchOutcome::TotalStepLimit,
            "death on total budget boundary lost the correct reason");
    search.start(false, false, smallConfig()); search.beginAttempt();
    search.desired(0, {});
    search.desired(1, {});
    require(search.outcome() == gdm::SearchOutcome::ReplayMismatch,
            "missing post-step observation was accepted");
    search.start(false, false, smallConfig()); search.beginAttempt();
    search.desired(0, {}); search.observe(1, {}); search.observe(1, {});
    require(search.outcome() == gdm::SearchOutcome::ReplayMismatch,
            "duplicate post-step observation was accepted");
}

// A geometry planner may produce short orb/UFO edges inside a six-tick branch.
// The first two required pulses are deliberately not at segment boundaries.
// A later obstacle needs a retry, so learned history must replay byte-for-byte.
void analyzedPrefixesPreserveIndividualTicks() {
    gdm::Search search;
    auto config = smallConfig();
    config.segmentSteps = 6; config.maxSteps = 40; config.maxAttempts = 64;
    search.start(false, false, config);
    unsigned x = 0, remaining = 0, resets = 0;
    bool dead = false;
    while (search.running()) {
        if (search.needsRestart()) {
            x = remaining = 0; dead = false; ++resets; search.beginAttempt();
        }
        gdm::Observation o;
        o.x1 = x; o.progress = float(x) * 4; o.grounded1 = true;
        o.analyzed[0] = true; o.planned[0][0] = x == 1 || x == 3;
        auto input = search.desired(x, o);
        if (!search.running()) break;
        if (x < 5 && input[0][0] != (x == 1 || x == 3)) dead = true;
        if (input[0][0]) remaining = 12;
        if (remaining) --remaining;
        if (x == 16 && !remaining) dead = true;
        ++x;
        o.x1 = x; o.progress = float(x) * 4; o.dead = dead;
        if (x == 25 && !dead) search.finishAttempt(true);
        else search.observe(x, o);
    }
    require(search.outcome() == gdm::SearchOutcome::Found,
        "exact per-tick learned prefixes were not preserved during retry");
    require(resets > 1, "prefix regression did not exercise an actual retry");
    require(search.solution().size() == 25, "analyzed trace has incorrect end step");
    for (unsigned step = 0; step < 5; ++step)
        require(search.solution()[step][0][0] == (step == 1 || step == 3),
            "a learned one-tick pulse was expanded into a held segment");
}

} // namespace

int main() {
    try {
        delayedJumpIsFoundAndReplayed();
        bothPlayersHaveIndependentBranches(false);
        bothPlayersHaveIndependentBranches(true);
        failureCancellationAndLimits();
        unknownModesAndStepOrderAreRejected();
        platformerMovementIsEnumerated();
        longRolloutsAndLateObstacle();
        longLeadActionsSurviveBeamPruning();
        eachPlayerUsesOwnHazard();
        flyingOrderRespectsGravityAndHazardSide();
        waveRolloutUsesStateFeedback();
        fineTimingAndExhaustedReplayBudgets();
        analyzedPrefixesPreserveIndividualTicks();
        std::cout << "search tests passed\n";
        return EXIT_SUCCESS;
    } catch (std::exception const& e) {
        std::cerr << "search test failure: " << e.what() << '\n';
        return EXIT_FAILURE;
    }
}
