#include "core/Playback.hpp"
#include "core/Recorder.hpp"
#include "core/Storage.hpp"
#include "search/LocalPlanner.hpp"

#include <chrono>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool value, char const* message) {
    if (!value) throw std::runtime_error(message);
}

// A separate physical fixture, not the GD engine: two solid-size floor
// hazards, actual parabolic jumps, collision death, and a positional finish.
struct World {
    double x = 0, foot = 0, velocity = 0, dy = 0;
    bool grounded = true, dead = false;
    gdm::WorldRect player() const { return {x - 15, foot, x + 15, foot + 30}; }
    std::array<gdm::PlayerScene, 2> scenes() const {
        std::array<gdm::PlayerScene, 2> result;
        auto& s = result[0];
        s.player = player(); s.dx = 1.4; s.dy = dy; s.motionValid = true;
        s.floorAvailable = true; s.floorY = 0;
        s.features = {{{160, 0, 190, 30}, gdm::FeatureKind::Hazard},
                      {{390, 0, 420, 30}, gdm::FeatureKind::Hazard}};
        return result;
    }
    gdm::Observation observation() const {
        gdm::Observation o;
        o.x1 = x; o.y1 = foot + 15; o.vx1 = 1.4; o.vy1 = velocity;
        o.grounded1 = grounded; o.dead = dead; o.progress = float(x / 550 * 100);
        return o;
    }
    gdm::Sample sample(uint64_t step) const {
        gdm::Sample s;
        s.step = step;
        s.players[0] = {x, foot + 15, 1.4, velocity,
            uint32_t(grounded ? 32 : 0) | uint32_t(dead ? 64 : 0)};
        return s;
    }
    void simulate(gdm::Input const& input) {
        if (grounded && input[0][0]) { velocity = 2.8; grounded = false; }
        double const before = foot;
        if (!grounded) { foot += velocity; velocity -= 0.06; }
        x += 1.4;
        if (foot <= 0) { foot = 0; velocity = 0; grounded = true; }
        dy = foot - before;
        auto const p = player();
        for (auto const& f : scenes()[0].features) {
            auto const& r = f.bounds;
            if (p.left < r.right - .05 && p.right > r.left + .05 &&
                p.bottom < r.top - .05 && p.top > r.bottom + .05) dead = true;
        }
    }
    bool completed() const { return !dead && x >= 550; }
};

struct TempDirectory {
    std::filesystem::path path = std::filesystem::temp_directory_path() /
        ("macrolab-auto-test-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    TempDirectory() { require(!std::filesystem::exists(path), "temporary test directory already exists"); }
    ~TempDirectory() { std::error_code error; std::filesystem::remove_all(path, error); }
};

void automaticallyFindRecordSaveAndReplay() {
    gdm::Metadata meta;
    meta.levelId = 0; // Unsaved/local levels use the same macro representation.
    meta.levelHash = gdm::levelContentHash("independent-two-obstacle-test-world");
    meta.environment = "portable-physics-fixture;not-Geometry-Dash";
    gdm::Search search;
    gdm::SearchConfig config;
    config.maxAttempts = 16; config.maxSteps = 500; config.maxTotalSteps = 5000;
    config.segmentSteps = 6; config.beamWidth = 4;
    search.start(false, false, config);
    gdm::LocalPlanner planner;
    gdm::Recorder recorder;
    World world;
    gdm::Input held{};
    uint64_t step = 0;
    unsigned watchdog = 0;
    while (search.running()) {
        require(++watchdog < 5000, "automatic pipeline did not terminate within its budget");
        if (search.needsRestart()) {
            world = {}; step = 0; held = {}; planner.reset(); search.beginAttempt(); recorder.start(meta);
        }
        auto o = world.observation();
        o.planned = planner.plan(o, world.scenes(), false); o.analyzed[0] = true;
        auto input = search.desired(step, o);
        if (!search.running()) break;
        planner.applied(input);
        if (step % 60 == 0) recorder.sample(world.sample(step));
        for (unsigned p = 0; p < 2; ++p) for (unsigned b = 0; b < 3; ++b) {
            if (input[p][b] != held[p][b])
                recorder.input(step, uint8_t(p + 1), uint8_t(b + 1), input[p][b]);
        }
        held = input; world.simulate(input); ++step;
        if (world.completed()) {
            search.finishAttempt(true); recorder.sample(world.sample(step)); recorder.finish(step, true);
        } else search.observe(step, world.observation());
    }
    require(search.outcome() == gdm::SearchOutcome::Found, "automatic analysis did not find the physical finish");
    require(recorder.macro().completed && recorder.macro().events.size() >= 4,
        "successful search did not create jump/release macro events");
    TempDirectory temporary;
    gdm::Storage storage(temporary.path);
    auto const name = "solution-0-" + meta.levelHash.substr(0, 8);
    storage.save(name, recorder.macro());
    auto const macro = storage.load(name);
    require(macro.completed && macro.endStep == search.solution().size(), "JSON roundtrip lost the solution");
    gdm::Playback playback; playback.start(macro, meta);
    world = {}; held = {};
    for (uint64_t t = 0; t < macro.endStep; ++t) {
        require(!playback.check(world.sample(t), .000001), "saved macro checkpoint did not replay");
        for (auto const& e : playback.eventsAt(t)) held[e.player - 1][e.button - 1] = e.down;
        world.simulate(held);
        require(!world.dead, "saved automatic macro died during replay");
    }
    for (auto const& e : playback.terminalEvents(world.sample(macro.endStep), .000001))
        held[e.player - 1][e.button - 1] = e.down;
    require(world.completed() && !held[0][0], "saved macro did not finish and release input");
}
} // namespace

int main() {
    try {
        automaticallyFindRecordSaveAndReplay();
        std::cout << "automatic search -> record -> JSON -> verified replay passed; no GD runtime\n";
        return 0;
    } catch (std::exception const& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
