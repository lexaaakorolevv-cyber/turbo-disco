#include "core/Recorder.hpp"
#include "core/Playback.hpp"
#include <iostream>
#include <stdexcept>
int main(){
    using namespace gdm;
    Metadata meta;meta.levelHash=levelContentHash("endpoint-level");
    Recorder recorder;recorder.start(meta);
    Sample initial;initial.step=0;recorder.sample(initial);
    recorder.input(0,1,1,true);
    Sample terminal=initial;terminal.step=1;terminal.players[0].vy=8;terminal.players[0].flags=128;
    recorder.sample(terminal);auto macro=recorder.finish(1,false);
    Playback playback;playback.start(macro,meta);
    if(playback.check(initial))throw std::runtime_error("start failed");
    playback.eventsAt(0);
    auto releases=playback.terminalEvents(terminal);
    if(releases.size()!=1||releases[0].down)throw std::runtime_error("missing safety release");
    // The real engine may end dash/robot hold on release; that state belongs
    // outside the already-verified endpoint and must not cause a false desync.
    auto after=terminal;after.players[0].vy=0;after.players[0].flags=0;
    if(!playback.ended(1))throw std::runtime_error("endpoint was not consumed");
    playback.start(macro,meta);playback.check(initial);playback.eventsAt(0);
    bool rejected=false;try{playback.terminalEvents(after);}catch(std::runtime_error const&){rejected=true;}
    if(!rejected)throw std::runtime_error("real endpoint mismatch accepted");
    playback.start(macro,meta);playback.check(initial);playback.eventsAt(0);
    rejected=false;try{auto wrong=terminal;wrong.step=2;playback.terminalEvents(wrong);}catch(std::runtime_error const&){rejected=true;}
    if(!rejected)throw std::runtime_error("extra physics step accepted");
    std::cout<<"endpoint release/checkpoint regression passed\n";
}
