# 0.2.0

- Geode 5.11.1 / GD 2.2081 / Windows x64.
- Real v5 Popup/keyboard and 3-argument processCommands hooks.
- Full-tick input quantization, tested native clock policy, failure-safe reset/injection flags.
- Initial/final replay checkpoints required; endpoint compared before safety releases.
- Synchronous F9/Stop in modal UI and pause; state cleared between levels.
- Dual search initialized after reset; independent P2 hazard and gravity hints.
- Quick/Balanced/Precise search presets; 24/48-step temporal rewind diversity; fine-segment support.
- New addressed saveNewScore/markLevelAsCompletedAndClaimed guards.
- Compact HUD, SDK version in the menu, bundled third-party notices.
- CTest 4/4, core assertions 81, actual SDK API syntax 10/10. Real GD runtime validation pending.
