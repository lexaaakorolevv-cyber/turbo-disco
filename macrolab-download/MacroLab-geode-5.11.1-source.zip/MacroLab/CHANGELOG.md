# 0.3.0

- One-click «Сделать макрос»: whole-level preparation, proactive planning, real retries, verification, automatic JSON save.
- New game-thread SceneAnalyzer with bounded spatial index, native live hitboxes, moving objects, measured per-tick displacement, independent P2.
- New LocalPlanner for upcoming obstacles/ceilings/visible gaps, ship/wave corridor control, orb/edge mechanics; actual-input feedback prevents phantom presses during retry prefixes.
- Exact per-tick search prefixes preserve short pulses; Precise branching uses one tick.
- solution-ID-contentHash naming, phase/status/name shown in UI; repaired Russian font retained.
- Seven portable tests including physical automatic search→JSON→verified replay; twelve real-SDK syntax units. Geometry Dash runtime still untested.

# 0.2.1

- Fix text rendering on Windows: Geode namespaced font IDs preserve the FNT-to-PNG directory instead of native backslash paths.
- Verify the font files and atlas on the game thread before drawing; keep F6 usable and show an ASCII recovery message if resources are missing.
- New font resource names avoid old font/texture cache entries.
- Add source and installable-package font regression validation.

# 0.2.0

- Geode 5.11.1 / GD 2.2081 / Windows x64.
- Real v5 Popup/keyboard and 3-argument processCommands hooks.
- Full-tick input quantization, tested native clock policy, failure-safe reset/injection flags.
- Initial/final replay checkpoints required; endpoint compared before safety releases.
- Synchronous F9/Stop in modal UI and pause; state cleared between levels.
- Dual search initialized after reset; independent P2 hazard and gravity hints.
- Quick/Balanced/Precise search presets; 24/48-step temporal rewind diversity; fine-segment support.
- New addressed saveNewScore/markLevelAsCompletedAndClaimed guards.
- Compact HUD, SDK version in the menu, bundled third-party notices.
- CTest 4/4, core assertions 81, actual SDK API syntax 10/10. Real GD runtime validation pending.
