# Geode 5.11.1 API validation environment

Target: GD 2.2081 / Geode 5.11.1 / Win64 bindings.
SDK tag v5.11.1, commit 413ac9b3936373e0983b3ebb8a056a3d39e8541c.
Bindings commit f8aec5d1f3df76d840dfd2609f02cef30dc6efdf.
SDK5.11.1/CMakeLists.txt sets GD 2.2081 (comparable 22081) and requires C++23.

Codegen SHA256: bd4d5582969f48c36d95996190b2d158e7515d6770b090b29d034fc4df9b4419.
Codegen command:
`/workspace/work/build-check/Codegen Win64 /workspace/work/bindings/bindings/2.2081 /workspace/work/build-check-v5/generated --sdk-version 5.11.1`

The syntax checker uses actual SDK loader headers and generated selected-version
bindings, Clang19.1.7, and MinGW GCC14 C++/system headers. Dependencies follow SDK
CMake pins: result1.4.1, json3.3.1, fmt5ac44cd1282f12947d25f439b59c5e55944cdb04,
nontype_functional6d1d08c, asp2ecea33b, arc1.5.11, TulipHook3.1.15.

A Linux case-sensitive lookup adaptation is needed for SDK glew.h's
`<gl/GLU.h>` include: compat-casing/gl/GLU.h is a symlink to actual MinGW
GL/glu.h. No API declarations or SDK methods were stubbed or replaced.

This syntax checker does not link Geode.lib or create an ABI-compatible Windows
DLL. MinGW ABI differs from the MSVC ABI used by Geometry Dash and Geode.
MSVC release build and .geode packaging must be checked separately. Neither a
syntax check nor a successful MSVC build proves in-game replay/search correctness.

Final results are recorded in project-syntax-results.json and include SDK,
bindings, compiler, per-source SHA256, and pre/post source/header stability.
