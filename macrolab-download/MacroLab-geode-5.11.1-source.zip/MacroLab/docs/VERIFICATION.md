# Geode 5.11.1 API validation environment

Target: GD 2.2081 / Geode 5.11.1 / Win64 bindings.
SDK tag v5.11.1, commit 413ac9b3936373e0983b3ebb8a056a3d39e8541c.
Bindings commit f8aec5d1f3df76d840dfd2609f02cef30dc6efdf.
SDK5.11.1/CMakeLists.txt sets GD 2.2081 (comparable 22081) and requires C++23.

Codegen SHA256: bd4d5582969f48c36d95996190b2d158e7515d6770b090b29d034fc4df9b4419.
Codegen command:
`/workspace/work/build-check/Codegen Win64 /workspace/work/bindings/bindings/2.2081 /workspace/work/build-check-v5/generated --sdk-version 5.11.1`

The syntax checker uses actual SDK loader headers and generated selected-version
bindings, Clang19.1.7, and MinGW GCC14 C++/system headers. Dependencies follow SDK
CMake pins: result1.4.1, json3.3.1, fmt5ac44cd1282f12947d25f439b59c5e55944cdb04,
nontype_functional6d1d08c, asp2ecea33b, arc1.5.11, TulipHook3.1.15.

A Linux case-sensitive lookup adaptation is needed for SDK glew.h's
`<gl/GLU.h>` include: compat-casing/gl/GLU.h is a symlink to actual MinGW
GL/glu.h. No API declarations or SDK methods were stubbed or replaced.

This syntax checker does not link Geode.lib or create an ABI-compatible Windows
DLL. MinGW ABI differs from the MSVC ABI used by Geometry Dash and Geode.
MSVC release build and .geode packaging must be checked separately. Neither a
syntax check nor a successful MSVC build proves in-game replay/search correctness.

Final results are recorded in project-syntax-results.json and include SDK,
bindings, compiler, per-source SHA256, and pre/post source/header stability.

## Font repair 0.2.1

The Windows font path uses Geode namespaced forward-slash resource IDs instead of native filesystem strings. Cocos resolves an FNT page relative to its last `/`. The cached font configuration explicitly points at the namespaced PNG. Resources have fresh v021 filenames. On the game thread the adapter checks FNT/PNG existence and the 1024x1024 atlas before creating text. Font resource failures use a stock-font ASCII message; F6 remains accessible.

`tests/font_resources_test.py` reproduces the old slash-only resolver failure, validates all ASCII/Russian/source-literal glyphs, FNT cell bounds, RGBA8 PNG/CRC and declared resources. `--package` additionally checks ZIP CRC, metadata v0.2.1, native x64 DLL and exact packaged/source font bytes.

Local checks for 0.2.1: 10/10 SDK syntax units; 5/5 CTests; 81 core assertions. These checks do not execute Geometry Dash.

## Автоматический анализ 0.3.0

Проверены 12/12 реальных SDK/bindings translation units и стабильность итоговых исходников/заголовков/tests/CMake/mod.json. GCC14 Release с Wall/Wextra/Wpedantic/Werror: 7/7 CTest, 81 проверка ядра. Планировщик и поиск дополнительно прошли ASAN/UBSAN. Тест automatic_macro_pipeline не использует Geometry Dash: независимая физическая модель двух препятствий доводится до настоящего окончания модели, Recorder/Storage сохраняют JSON, Playback проверяет состояния и физический повтор до того же окончания.

Проверки не запускали игру, поэтому native reset timing, реальные порталы/орбы/dual/триггеры и неизменность обычных сохранений требуют smoke-проверки в GD 2.2081 с Geode 5.11.1. Ошибка шага/снимка/смерть останавливает replay; native finish — единственный положительный сигнал для игрового адаптера.
