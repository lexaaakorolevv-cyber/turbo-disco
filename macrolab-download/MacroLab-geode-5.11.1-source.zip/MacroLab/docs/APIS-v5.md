# Аудит адаптера Geode 5.11.1

Целевая комбинация: **Windows x64, Geometry Dash 2.2081, Geode SDK 5.11.1**.
Сигнатуры и поля проверены по официальным исходникам. Этот документ не утверждает,
что DLL проверена в запущенной игре.

## Фиксированные первичные источники

- [SDK tag v5.11.1](https://github.com/geode-sdk/geode/tree/413ac9b3936373e0983b3ebb8a056a3d39e8541c), commit `413ac9b3936373e0983b3ebb8a056a3d39e8541c`.
  [VERSION](https://github.com/geode-sdk/geode/blob/413ac9b3936373e0983b3ebb8a056a3d39e8541c/VERSION) содержит `5.11.1`.
  [CMakeLists.txt:210](https://github.com/geode-sdk/geode/blob/413ac9b3936373e0983b3ebb8a056a3d39e8541c/CMakeLists.txt#L210)
  задаёт `GEODE_GD_VERSION 2.2081`, строка 211 — `GEODE_COMP_GD_VERSION 22081`.
- [Bindings](https://github.com/geode-sdk/bindings/tree/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf), commit `f8aec5d1f3df76d840dfd2609f02cef30dc6efdf`.
  Проверялся [bindings/2.2081/GeometryDash.bro](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/2.2081/GeometryDash.bro).
  Сам SDK по умолчанию получает движущийся `main`; для воспроизводимой сборки следует
  фиксировать указанный commit bindings.
- [Loader.hpp](https://github.com/geode-sdk/geode/blob/413ac9b3936373e0983b3ebb8a056a3d39e8541c/loader/include/Geode/loader/Loader.hpp)
  сохраняет `Loader::getVersion()` и `Loader::getGameVersion()`; версия Geode доступна
  через `VersionInfo::toNonVString()`.

## Изменения относительно GD 2.2074 / Geode 4.10.0

1. `processCommands(float)` заменён на `processCommands(float, bool isHalfTick, bool isLastTick)`.
   Оба флага необходимо передавать в нативный метод без изменения.
2. `getModifiedDelta(float)` возвращает `double`, раньше возвращал `float`.
3. Нативный счётчик команд — `m_gameState.m_commandIndex` (`unsigned int`), ранее
   поле называлось `m_unkUint2` (`int`). `m_currentProgress` — другое поле.
   Подтверждение использования счётчика: inline `activateObject` / `updateState` /
   `setAreaOpacity` в официальном [GJBaseGameLayer.cpp](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/2.2081/inline/GJBaseGameLayer.cpp).
4. `queueButton` принимает дополнительный `double timestamp`; структура
   `PlayerButtonCommand` содержит `m_button`, `m_isPush`, `m_isPlayer2`, `m_step`, `m_timestamp`.
5. `GJGameLevel::saveNewScore` теперь адресуемый метод с семью аргументами,
   поэтому его можно перехватить до прямых изменений времени/очков.
6. У GameStatsManager появились `m_playerStatsRandMap` и `m_playerStatsSeedMap`;
   словари `m_playerStats` и `m_pendingUserCoins` остаются `CCDictionary*`.
   Нельзя подменять их контейнерами из другой версии или копировать только один
   словарь при попытке полной замены глобальной статистики.

## Адресуемые API

Все адреса — относительные Windows адреса из `.bro`, а не вручную используемые
смещения в коде мода. Geode генерирует вызывающие обёртки и хуки.

### GameLevelManager

| Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- |
| `void saveLevel(GJGameLevel* level)` | `0x148d80` | 5582 |
| `void updateUserScore()` | `0x155c60` | 5619 |
| `void uploadLevel(GJGameLevel* level)` | `0x14c7c0` | 5623 |

### GameStatsManager

| Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- |
| `void awardCurrencyForLevel(GJGameLevel* level)` | `0x1e0960` | 6790 |
| `void awardDiamondsForLevel(GJGameLevel* level)` | `0x1e1140` | 6791 |
| `bool awardSecretKey()` | `0x1f19f0` | 6793 |
| `void checkAchievement(char const* statKey)` | `0x1d5440` | 6795 |
| `void checkCoinAchievement(GJGameLevel* level)` | `0x1dd800` | 6796 |
| `GJRewardItem* completedDailyLevel(GJGameLevel* level)` | `0x1e2de0` | 6802 |
| `void completedDemonLevel(GJGameLevel* level)` | `0x1de500` | 6803 |
| `void completedLevel(GJGameLevel* level)` | `0x1de3b0` | 6804 |
| `void completedMapPack(GJMapPack* pack)` | `0x1dee00` | 6805 |
| `void completedStarLevel(GJGameLevel* level)` | `0x1de770` | 6806 |
| `void encodeDataTo(DS_Dictionary* dict)` | `0x1f21a0` | 6815 |
| `void incrementChallenge(GJChallengeType type, int amount)` | `0x1e20c0` | 6877 |
| `void incrementStat(char const* key, int amount)` | `0x1d44d0` | 6879 |
| `void markLevelAsCompletedAndClaimed(GJGameLevel* level)` | `0x1de910` | 6895 |
| `void registerRewardsFromItem(GJRewardItem* item)` | `0x1f1500` | 6904 |
| `void setStat(char const* key, int value)` | `0x1d52d0` | 6917 |
| `void storeSecretCoin(char const* key)` | `0x1dfff0` | 6931 |
| `void storeUserCoin(char const* key)` | `0x1dfda0` | 6932 |

### GJBaseGameLayer

| Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- |
| `virtual void update(float dt)` | `0x237850` | 7373 |
| `double getModifiedDelta(float dt)` | `0x2377b0` | 7546 |
| `void handleButton(bool down, int button, bool isPlayer1)` | `0x2338e0` | 7571 |
| `void processCommands(float dt, bool isHalfTick, bool isLastTick)` | `0x239c60` | 7634 |

### GJGameLevel

| Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- |
| `virtual void encodeWithCoder(DS_Dictionary* dict)` | `0x16ef00` | 8716 |
| `void dataLoaded(DS_Dictionary* dict)` | `0x16dec0` | 8722 |
| `void saveNewScore(int value, int type, int ticks, int clicks, int coins, gd::string inputs, bool save)` | `0x16d230` | 8737 |
| `void savePercentage(int percent, bool isPracticeMode, int clicks, int attempts, bool isChkValid)` | `0x16c8b0` | 8738 |
| `void storeNewLocalScore(int value, int type)` | `0x16d400` | 8759 |

### PlayLayer

| Сигнатура | Windows | Строка `.bro` |
| --- | --- | --- |
| `virtual void onExit()` | `0x3bafc0` | 15014 |
| `virtual void destroyPlayer(PlayerObject* player, GameObject* object)` | `0x3b39d0` | 15026 |
| `virtual void removeAllCheckpoints()` | `0x3b8040` | 15042 |
| `virtual void resetLevel()` | `0x3b8eb0` | 15045 |
| `void commitJumps()` | `0x3b9de0` | 15058 |
| `float getCurrentPercent()` | `0x3b3950` | 15065 |
| `bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects)` | `0x3a5b00` | 15074 |
| `void levelComplete()` | `0x3a7a80` | 15076 |
| `void onQuit()` | `0x3babb0` | 15083 |
| `void resetLevelFromStart()` | `0x3b8d10` | 15098 |
| `void updateAttempts()` | `0x3b9ba0` | 15132 |

## Ввод и проверенные поля

Номер кнопки определён официальным [Enums.hpp](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/include/Geode/Enums.hpp#L192):
`Jump = 1`, `Left = 2`, `Right = 3`.

Bindings называют третий параметр `handleButton` `isPlayer1`. В официальном
[EditorUI.cpp:112–124](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/2.2081/inline/EditorUI.cpp#L112)
`queueButton(..., true, timestamp)` применяется для touch ID второго игрока,
`false` — первого; inline queueButton сохраняет этот флаг в `m_isPlayer2`.
В старом inline updateReplay GD 2.208 этот же `m_isPlayer2` передавался прямо в
handleButton. Поэтому адаптер сохраняет прежнее соглашение `false = P1`, `true = P2`.
В GD 2.2081 тело inline updateReplay пустое: оно само по себе уже не служит
полным доказательством нативного обработчика. Игровая проверка dual и two-player
обязательна, особенно при других модах, меняющих управление.

Поля Session подтверждены в выбранных bindings:

- GJBaseGameLayer: `m_player1`, `m_player2`, `m_level`, `m_levelSettings`,
  `m_isPlatformer`, `m_isPracticeMode`, `m_startPosObject`, `m_useReplay`,
  `m_isTestMode`, `m_gameState`, `m_queuedButtons`, `m_queuedRecordedButtons`,
  `m_queuedReplayButtons`, `m_levelEndAnimationStarted`,
  `m_hazardCollisionObjectsCount`, `m_hazardCollisionObjects`.
- PlayLayer: `m_isPaused`, `m_isIgnoreDamageEnabled`, `m_hasCompletedLevel`,
  `m_uncommittedJumps`.
- GJGameState: `m_commandIndex`, `m_isDualMode`, `m_timeWarp`.
- PlayerObject: `m_yVelocity` (double), `m_isShip`, `m_isBall`, `m_isBird`,
  `m_isDart`, `m_isRobot`, `m_isSpider`, `m_isSwing`, `m_isUpsideDown`,
  `m_isOnGround`, `m_isDead`, `m_isDashing`, `m_isSideways`.
- LevelSettingsObject: `m_level`, `m_twoPlayerMode`.
- GJGameLevel: `m_levelID` (SeedValueRSV), `m_levelString` (gd::string),
  `m_lowDetailModeToggled`, `m_dontSave`.

`PlayerObject::getCurrentXVelocity()` — проверенный Windows inline метод:
возвращает `m_platformerXVelocity` в platformer, иначе
`m_playerSpeed * m_speedMultiplier`. Он не учитывает все возможные сторонние
изменения физики.

## Копия уровня и владение

Официальный [GJGameLevel.cpp:85–100](https://github.com/geode-sdk/bindings/blob/f8aec5d1f3df76d840dfd2609f02cef30dc6efdf/bindings/2.2081/inline/GJGameLevel.cpp#L85)
реализует `create()` через `new`, `init()`, `autorelease()`, а `createWithCoder()`
через `create()` и `dataLoaded(dict)`. Поэтому временный уровень требует своего
`retain()` на срок сессии и ровно одного соответствующего `release()` при выходе.
Оригинальный native retain уровня нельзя освобождать при подстановке копии;
перед уничтожением PlayLayer нужно вернуть исходный `m_level` и ссылку
`m_levelSettings->m_level`. Это отдельная копия статистики уровня, а не snapshot
физического состояния игрока.

На Windows `storePendingUserCoin(char const*)` остаётся inline, без адресуемого
входа. Его проверенное тело пишет в `m_pendingUserCoins`, поэтому изоляция
временной копией словаря нужна дополнительно к блокировке адресуемых reward API.
`CCDictionary::copy()` возвращает владеющую копию; ей нужен `release()` после
восстановления исходного словаря. Перехват `encodeDataTo` во время карантина
должен сериализовать исходный словарь ожидающих монет.

Одноаргументный `incrementStat` тоже Windows inline: он вызывает адресуемый
двухаргументный `incrementStat(key, 1)`. Адресуемый перехват двух аргументов
покрывает эту проверенную цепочку вызовов.

## Шаг симуляции и границы проверки

Библиотека bindings задаёт сигнатуру `processCommands`, но не содержит нативную
реализацию `update`, `getModifiedDelta` или `processCommands`. По именам флагов
нельзя доказать порядок half-ticks, число вызовов на render frame или точную
границу применения ввода. Нельзя переносить алгоритм timewarp из старого SDK
или объявлять каждый callback отдельным шагом только по имени метода.

Адаптер должен ограничивать работу на кадр, пропускать дубли native command index,
останавливать сессию при неожиданном скачке счётчика и проверять записанное
решение повторным воспроизведением. Правила и fingerprint симуляции новой версии
должны отличаться от макросов GD 2.2074; автоматическая конвертация старых макросов
без проверки физики не подтверждена.

Этот аудит подтверждает существование API/полей и их Windows адреса. Он не
подтверждает загрузку DLL в настоящем GD, работу всех механик, отсутствие прямых
записей глобальной статистики вне перехваченных API или взаимодействие с другими
модами. Для этих утверждений нужны игровые smoke tests и сравнение сохранений.
